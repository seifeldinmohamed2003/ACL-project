# Backend Testing Commands

## Quick Test Commands

### Test with Baseline Only (No LLM)
```bash
python test_questions_script.py baseline false
```

### Test with Semantic Only (No LLM)
```bash
python test_questions_script.py semantic false
```

### Test with Both Methods (No LLM)
```bash
python test_questions_script.py both false
```

### Test with Baseline + LLM
```bash
python test_questions_script.py baseline true
```

### Test with Both Methods + LLM
```bash
python test_questions_script.py both true
```

---

## Test Individual Questions

### Using Python directly:

```python
from backend.pipeline import process_query

# Test a single question
result = process_query(
    "What is the status of flight 42?",
    retrieval_method="both",
    llm_model=None,
    use_llm=False
)

print(f"Intent: {result.get('intent')}")
print(f"Baseline rows: {result.get('num_baseline_rows', 0)}")
print(f"Semantic rows: {result.get('num_semantic_rows', 0)}")
print(f"Total rows: {result.get('num_rows', 0)}")
```

### Using command line:

```bash
python -c "from backend.pipeline import process_query; result = process_query('What is the status of flight 42?', retrieval_method='both', llm_model=None, use_llm=False); print(f'Baseline: {result.get(\"num_baseline_rows\", 0)}, Semantic: {result.get(\"num_semantic_rows\", 0)}, Total: {result.get(\"num_rows\", 0)}')"
```

---

## Test with LLM

### Test with specific LLM model:

```python
from backend.pipeline import process_query
from backend.llm.model_client import LLMModel

result = process_query(
    "What is the status of flight 42?",
    retrieval_method="both",
    llm_model=LLMModel.OPENAI_GPT4O_MINI,
    use_llm=True
)

if 'llm_response' in result:
    llm_resp = result['llm_response']
    if 'error' not in llm_resp:
        print(f"LLM Answer: {llm_resp.get('text', '')}")
    else:
        print(f"LLM Error: {llm_resp.get('error')}")
```

---

## Recommended Test Sequence

1. **Quick baseline test:**
   ```bash
   python test_questions_script.py baseline false
   ```

2. **Test semantic search:**
   ```bash
   python test_questions_script.py semantic false
   ```

3. **Test both methods:**
   ```bash
   python test_questions_script.py both false
   ```

4. **Test with LLM (if you want):**
   ```bash
   python test_questions_script.py both true
   ```

---


python run_streamlit.py

## Test Specific Categories

You can modify `test_questions_script.py` to test only specific categories by editing the `TEST_QUESTIONS` dictionary.

---

## Notes

- Results are **NOT saved** to JSON files (disabled)
- All output goes to console/terminal
- Use `Ctrl+C` to stop if needed
- Each test shows: intent, baseline rows, semantic rows, total rows
