"""
Quick test script to run multiple questions programmatically.
Useful for batch testing and verification.
"""

from backend.pipeline import process_query
from backend.llm.model_client import LLMModel, get_available_models
import json

# Test questions organized by category
# Comprehensive test suite covering all intents, entities, edge cases, and retrieval methods
TEST_QUESTIONS = {
    "FLIGHT_STATUS": [
        # Basic flight status queries
        "What is the status of flight 2411?",
        "Show me information about flight 2411",
        "What flights go from CAI to LHR?",
        # Flights with journey data
        "What is the status of flight 42?",
        "Show me information about flight 19",
        "Flight 86 status",
        "What is the status of flight 27?",
        # Route queries with real airports
        "What flights go from LAX to IAX?",
        "Show flights from ABX to ACX",
        "What flights go from ALX to AMX?",
        # Route queries with missing airports (safe template)
        "What flights go from JFK to DXB?",
        "Show flights from XXX to YYY",
        # Edge cases
        "What is the status of flight 0?",
        "Show me flight 99999",
        "What flights go from invalid to code?",
    ],
    "PASSENGER_SATISFACTION": [
        # General satisfaction
        "What are poorly rated flights?",
        "Find journeys with low food satisfaction scores",
        "What is satisfaction for flight 2411?",
        # Flight-specific with data
        "What is satisfaction for flight 42?",
        "Show satisfaction scores for flight 19",
        "Passenger satisfaction for flight 86",
        # Flight-specific without data
        "What is satisfaction for flight 99999?",
        # High satisfaction
        "Find journeys with high satisfaction",
        "Show me well-rated flights",
        # Low satisfaction
        "Find journeys with food satisfaction below 2",
        "Show me journeys with satisfaction score 1",
    ],
    "DELAY_CAUSES": [
        # General delays
        "Which flights are delayed?",
        "Find journeys with high delays",
        "What are the average delays by route?",
        # Route-specific delays
        "What are delays for flights from LAX to IAX?",
        "Show delays for flights from ABX to ACX",
        # Route-specific with missing airports
        "What are delays for flights from CAI to LHR?",
        # High delays
        "Find journeys with delays over 60 minutes",
        "Show me journeys with delays over 120 minutes",
        # Early arrivals
        "Show me journeys that arrived early",
        "Find journeys with negative delay",
    ],
    "BEST_ROUTE": [
        # City-to-city
        "What is the best route from Cairo to London?",
        "Show me routes between Cairo and London",
        # Airport-to-airport (real)
        "What is the best route from LAX to IAX?",
        "Show routes from ABX to ACX",
        # Airport-to-airport (missing)
        "What is the best route from CAI to LHR?",
    ],
    "AIRLINE_INFO": [
        "Tell me about the airline",
        "What is the airline information?",
        "Show me overall airline performance",
        "What are the airline's key metrics?",
    ],
    "AIRPORT_INFO": [
        # Real airports
        "Tell me about airport LAX",
        "What is airport IAX?",
        "Show information about ABX airport",
        # Missing airports
        "Tell me about airport CAI",
        "What is airport LHR?",
        # City-based
        "Show information about Cairo airport",
        "Airport details for London Heathrow",
    ],
    "GENERAL_KG_QUERY": [
        "Show me journey statistics",
        "What are the journey patterns?",
        "Analyze passenger journeys",
        "Analyze flight performance",
        "Show me overall airline performance",
        "What are the key operational insights?",
    ],
    "COMPLEX": [
        "Find journeys with high delay and low food satisfaction",
        "Show me overall airline performance",
        "What is the status of flight 42 from LAX to IAX?",
        "Show me satisfaction for flight 42 from LAX",
    ],
    "SEMANTIC_FALLBACK": [
        # Questions that intentionally have no baseline template (force baseline=0)
        "What are the most popular passenger classes?",
        "Which airports have the most connections?",
        "What is the distribution of journey distances?",
        "Show me passenger class breakdown",
        "What are the journey leg patterns?",
    ],
    "EDGE_CASES": [
        # Entity extraction edge cases
        "What is the status of flight 5?",
        "Flight 12345 status",
        "What flights go from lax to iax?",
        # Intent classification edge cases
        "Show me information about flight 2411",
        "What is satisfaction for flight 42?",
        "What are delays for flight 42?",
        # Ambiguous queries
        "Show me flights",
        "What can you tell me?",
        "Give me some information",
        # Boundary cases
        "What is the status of flight 0?",
        "Show me flight -1",
        "What flights go from A to B?",
        # Error handling
        "What is the status of flight 99999?",
        "Show satisfaction for flight 99999",
        "What flights go from INVALID to CODE?",
    ],
    "RETRIEVAL_METHODS": [
        # Test each retrieval method explicitly
        "What is the status of flight 42?",  # Baseline only
        "What are poorly rated flights?",  # Both
        "Show me journey statistics",  # Both (GENERAL_KG_QUERY)
        "What are the most popular passenger classes?",  # Semantic fallback
    ],
    "TEMPLATE_SPECIFIC": [
        # Test each template type
        "What is the status of flight 42?",  # flight_status_by_number
        "What flights go from LAX to IAX?",  # safe_flight_status_by_route (real)
        "What flights go from CAI to LHR?",  # safe_flight_status_by_route (missing)
        "What are poorly rated flights?",  # low_satisfaction_journeys
        "What is satisfaction for flight 42?",  # satisfaction_by_flight_number
        "Which flights are delayed?",  # high_delay_journeys
        "What are delays for flights from LAX to IAX?",  # delay_causes_for_route
        "What are the average delays by route?",  # average_delays_by_route
        "What is the best route from Cairo to London?",  # best_route_by_city
        "What is the best route from LAX to IAX?",  # best_route_by_airport_codes
        "Tell me about airport LAX",  # airport_basic_info
        "Show information about Cairo airport",  # airport_info_by_city
        "What are popular routes from LAX?",  # popular_routes_from_airport
        "Show me journey statistics",  # journey_statistics
        "What are the journey patterns?",  # journey_patterns
        "Analyze passenger journeys",  # analyze_passenger_journeys
        "Show me overall airline performance",  # overall_airline_performance
    ]
}

def test_question(
    question: str,
    retrieval_method: str = "both",
    use_llm: bool = False,
    llm_model: LLMModel = None,
    run_baseline_oracle: bool = False,
):
    """Test a single question and print results."""
    print(f"\n{'='*70}")
    print(f"Question: {question}")
    print(f"Retrieval: {retrieval_method} | LLM: {use_llm}")
    print(f"{'='*70}")
    
    try:
        baseline_oracle = None
        if run_baseline_oracle:
            baseline_oracle = process_query(
                question,
                retrieval_method="baseline",
                llm_model=None,
                use_llm=False
            )
        
        result = process_query(
            question,
            retrieval_method=retrieval_method,
            llm_model=llm_model,
            use_llm=use_llm
        )
        
        print(f"Intent: {result.get('intent')} (confidence: {result.get('intent_confidence', 0):.2f})")
        template_info = result.get('template', {})
        if template_info:
            print(f"Template: {template_info.get('id', 'unknown')}")
            print(f"Params: {result.get('params', {})}")
        else:
            print(f"Template: None")
        print(f"Baseline rows: {result.get('num_baseline_rows', 0)}")
        print(f"Semantic rows: {result.get('num_semantic_rows', 0)}")
        print(f"Total rows: {result.get('num_rows', 0)}")
        
        if baseline_oracle is not None:
            print(f"[ORACLE] Baseline-only total rows: {baseline_oracle.get('num_rows', 0)}")
            oracle_template = (baseline_oracle.get("template") or {}).get("id")
            print(f"[ORACLE] Baseline-only template: {oracle_template}")
        
        if use_llm and 'llm_response' in result:
            llm_resp = result['llm_response']
            if 'error' not in llm_resp:
                llm_text = llm_resp.get('text', '')
                # Show full response, but wrap long lines for readability
                if len(llm_text) > 0:
                    # Show explicit model tracking fields
                    model_requested = llm_resp.get('model_requested', 'unknown')
                    model_used = llm_resp.get('model_used', llm_resp.get('model', 'unknown'))
                    fallback_used = llm_resp.get('fallback_used', False)
                    fallback_reason = llm_resp.get('fallback_reason', '')
                    grounding_override = llm_resp.get('grounding_override', False)
                    
                    # Build model info string
                    model_info = f"requested={model_requested}, used={model_used}"
                    if fallback_used:
                        model_info += f", FALLBACK=True"
                        if fallback_reason:
                            model_info += f" (reason: {fallback_reason[:50]})"
                    if grounding_override:
                        model_info += ", GROUNDING_OVERRIDE=True"
                    
                    print(f"LLM Answer [{model_info}]: {llm_text}")
                else:
                    print("LLM Answer: (empty response)")
            else:
                error_msg = llm_resp.get('error', 'Unknown error')
                model_display = llm_resp.get('model_display_name', 'unknown')
                print(f"LLM Error ({model_display}): {error_msg}")
                if "429" in str(error_msg) or "rate limit" in str(error_msg).lower():
                    print("  ⚠️  Rate limit hit - system should automatically try other models/keys")
        
        return result, baseline_oracle
        
    except Exception as e:
        print(f"ERROR: {e}")
        return None, None

def run_batch_tests(retrieval_method: str = "both", use_llm: bool = False, llm_model: LLMModel = None):
    """Run all test questions."""
    print("\n" + "="*70)
    print("BATCH TESTING - Airline GraphRAG System")
    print("="*70)
    
    results = {}
    failures = []
    
    for category, questions in TEST_QUESTIONS.items():
        print(f"\n\n📋 Testing {category} queries...")
        results[category] = []
        
        for question in questions:
            # In semantic-only mode, also run baseline oracle so we can judge "should be empty" vs "leakage"
            run_oracle = (retrieval_method == "semantic")
            
            result, oracle = test_question(question, retrieval_method, use_llm, llm_model, run_baseline_oracle=run_oracle)
            
            if not result:
                results[category].append({"question": question, "success": False, "reason": "exception"})
                failures.append((category, question, "exception"))
                continue
            
            intent = result.get("intent")
            template_id = (result.get("template") or {}).get("id")
            params = result.get("params") or {}
            
            baseline_rows = result.get("num_baseline_rows", 0)
            semantic_rows = result.get("num_semantic_rows", 0)
            total_rows = result.get("num_rows", 0)
            
            # Routing sanity: if we extracted strict params, we expect a real template, not a generic fallback
            strict_lookup = any(k in params for k in ("flight_number", "airport_code", "origin_code", "dest_code"))
            routing_ok = True
            if strict_lookup:
                routing_ok = (template_id is not None) and (template_id not in ("operational_insights",))
            
            # Retrieval correctness (semantic-only): compare semantic results with baseline oracle
            retrieval_ok = True
            reason = None
            if retrieval_method == "semantic" and strict_lookup and oracle is not None:
                oracle_rows = oracle.get("num_rows", 0)
                
                if oracle_rows == 0 and total_rows > 0:
                    retrieval_ok = False
                    reason = "semantic_leakage_expected_empty"
                elif oracle_rows > 0 and total_rows == 0:
                    retrieval_ok = False
                    reason = "semantic_miss_expected_results"
            
            # Exploratory / non-strict queries:
            # - require intent not UNKNOWN and we got some rows (baseline or semantic)
            if not strict_lookup:
                routing_ok = (intent not in (None, "UNKNOWN"))
                if retrieval_method == "semantic":
                    retrieval_ok = (semantic_rows > 0)
                else:
                    retrieval_ok = (total_rows > 0)
                
                # Special case: BEST_ROUTE with invalid or missing route entities
                # e.g. "What flights go from A to B?", "from INVALID to CODE"
                # We treat these as "handled invalid input" rather than hard failures.
                if intent == "BEST_ROUTE" and template_id is None and total_rows == 0:
                    retrieval_ok = True
                    routing_ok = True
                    reason = "invalid_input"
                else:
                    if not routing_ok:
                        reason = reason or "unknown_intent"
                    elif not retrieval_ok:
                        # More accurate label for non-semantic modes
                        if retrieval_method == "semantic":
                            reason = reason or "no_semantic_results"
                        else:
                            reason = reason or "no_rows_returned"
            
            # Additional assertions for "both" mode
            if retrieval_method == "both":
                # Assertion 1: Baseline monotonicity
                # If baseline has results, total must be >= baseline (baseline rows never dropped)
                if baseline_rows > 0:
                    if total_rows < baseline_rows:
                        retrieval_ok = False
                        reason = reason or "baseline_rows_dropped"
                        print(f"[ASSERTION FAILED] Baseline monotonicity: baseline={baseline_rows}, total={total_rows} for '{question}'")
                
                # Assertion 2: Entity faithfulness (for route queries)
                # If origin_code/dest_code exist, validate rows match them
                if strict_lookup and "origin_code" in params and "dest_code" in params:
                    origin_code = params.get("origin_code")
                    dest_code = params.get("dest_code")
                    if origin_code and dest_code:
                        # Get actual rows from result
                        actual_rows = result.get("rows", [])
                        # Check that semantic rows (if any) match the route
                        for r in actual_rows:
                            if r.get("_retrieval_source") == "semantic":
                                row_origin = r.get("origin_code") or r.get("origin")
                                row_dest = r.get("dest_code") or r.get("destination")
                                if row_origin and row_dest:
                                    if row_origin != origin_code or row_dest != dest_code:
                                        retrieval_ok = False
                                        reason = reason or "semantic_false_positive_route"
                                        print(f"[ASSERTION FAILED] Entity faithfulness: semantic row {row_origin}->{row_dest} doesn't match {origin_code}->{dest_code} for '{question}'")
                                        break
                
                # Assertion 3: Semantic expansion policy enforcement
                # If baseline has results, semantic should be disabled for non-allowlisted templates
                from backend.pipeline import SEMANTIC_EXPAND_ALLOWLIST
                
                if baseline_rows > 0:
                    if template_id not in SEMANTIC_EXPAND_ALLOWLIST:
                        # Non-allowlisted template with baseline results → semantic should be 0
                        if semantic_rows > 0:
                            retrieval_ok = False
                            reason = reason or "semantic_expansion_not_allowed"
                            print(f"[ASSERTION FAILED] Semantic expansion not allowed for template '{template_id}' when baseline has results (baseline={baseline_rows}, semantic={semantic_rows})")
                    else:
                        # Allowlisted template → semantic expansion is OK, but log it
                        if semantic_rows > 0:
                            print(f"[NOTE] Semantic expansion allowed for '{template_id}' (baseline={baseline_rows}, semantic={semantic_rows}, total={total_rows})")
            
            is_success = routing_ok and retrieval_ok
            if not is_success and reason is None:
                reason = "routing_or_retrieval_failed"
            
            row = {
                "question": question,
                "intent": intent,
                "template": template_id,
                "baseline_rows": baseline_rows,
                "semantic_rows": semantic_rows,
                "total_rows": total_rows,
                "success": is_success,
                "reason": reason,
            }
            results[category].append(row)
            
            if not is_success:
                failures.append((category, question, reason, intent, template_id, params, total_rows))
    
    # Summary
    print("\n\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    
    total_questions = sum(len(qs) for qs in TEST_QUESTIONS.values())
    successful = sum(1 for cat in results.values() for r in cat if r.get("success"))
    print(f"Total questions: {total_questions}")
    print(f"Successful: {successful}")
    print(f"Failed: {total_questions - successful}")
    
    for category, cat_results in results.items():
        success_count = sum(1 for r in cat_results if r.get("success"))
        print(f"\n{category}: {success_count}/{len(cat_results)} successful")
    
    # Print a compact failure list (super helpful)
    if failures:
        print("\n\n--- FAILURES (compact) ---")
        for f in failures[:30]:
            if len(f) == 3:
                cat, q, reason = f
                print(f"[{cat}] {reason} :: {q}")
            else:
                cat, q, reason, intent, template_id, params, total_rows = f
                print(f"[{cat}] {reason} | intent={intent} template={template_id} rows={total_rows} params={params} :: {q}")
    
    return results

if __name__ == "__main__":
    import sys
    
    # Parse arguments
    retrieval_method = sys.argv[1] if len(sys.argv) > 1 else "both"
    use_llm = sys.argv[2].lower() == "true" if len(sys.argv) > 2 else False
    
    print(f"\nConfiguration:")
    print(f"  Retrieval method: {retrieval_method}")
    print(f"  Use LLM: {use_llm}")
    
    if use_llm:
        available_models = get_available_models()
        if available_models:
            # Prefer OpenRouter or OpenAI models (skip HuggingFace if others available)
            preferred_models = [m for m in available_models if m.provider in ("openrouter", "openai")]
            if preferred_models:
                llm_model = preferred_models[0]  # Use first OpenRouter/OpenAI model
                print(f"  LLM Model: {llm_model.display_name} ({llm_model.provider})")
            else:
                # Fallback to HuggingFace if that's all we have
                llm_model = available_models[0]
                print(f"  LLM Model: {llm_model.display_name} ({llm_model.provider}) - Note: HuggingFace models may timeout")
        else:
            print("  ⚠️  No LLM models available")
            llm_model = None
    else:
        llm_model = None
    
    # Run tests
    results = run_batch_tests(retrieval_method, use_llm, llm_model)
    
    # Optionally save results (commented out for now)
    # with open("test_results.json", "w") as f:
    #     json.dump(results, f, indent=2)
    # print(f"\n✅ Results saved to test_results.json")
