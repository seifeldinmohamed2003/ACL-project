# Test Questions for Airline GraphRAG System

This document contains comprehensive test questions organized by intent type and retrieval method.

---

## 🎯 FLIGHT_STATUS Queries

### Exact Flight Number Queries (Baseline Only)
1. What is the status of flight 2411?
2. Show me information about flight 2411
3. Flight 2411 status
4. Is flight 2411 on time?
5. Tell me about flight 2411
6. What aircraft is used for flight 2411?
7. Flight number 2411 details

### Route-Based Flight Status (Baseline)
8. What flights go from CAI to LHR?
9. Show flights between Cairo and London
10. Flights from CAI to LHR status
11. What are the flights from Cairo to London Heathrow?

---

## 🗺️ BEST_ROUTE Queries

### City-to-City Routes (Baseline)
12. What is the best route from Cairo to London?
13. Show me routes between Cairo and London
14. Best way to travel from Cairo to London
15. Routes from Cairo to London
16. How to get from Cairo to London?

### Semantic Search (Fuzzy Route Questions)
17. What are the most efficient routes?
18. Show me popular travel routes
19. Which routes have the best performance?
20. Find routes with good passenger experience

---

## 😊 PASSENGER_SATISFACTION Queries

### General Satisfaction (Semantic + Baseline)
21. What are poorly rated flights?
22. Show me flights with low satisfaction
23. Which journeys have poor ratings?
24. Find journeys with low food satisfaction scores
25. What are the worst rated flights?
26. Show me unsatisfied passengers
27. Which flights have bad reviews?

### Specific Satisfaction Metrics (Baseline)
28. What is satisfaction for flight 2411?
29. Show satisfaction scores for flight 2411
30. Passenger satisfaction for flight 2411
31. How satisfied are passengers on flight 2411?

### Satisfaction Analysis (Semantic)
32. Find journeys with high satisfaction
33. Show me well-rated flights
34. Which journeys have good passenger feedback?
35. What are the best rated journeys?

---

## ⏰ DELAY_CAUSES Queries

### High Delay Queries (Baseline + Semantic)
36. Which flights are delayed?
37. Show me delayed journeys
38. Find journeys with high delays
39. What flights have significant delays?
40. Which journeys are most delayed?
41. Show me flights with arrival delays

### Delay Analysis (Baseline)
42. What are the average delays by route?
43. Show delay statistics
44. Which routes have the most delays?
45. Calculate average delays for different routes

### Delay Patterns (Semantic)
46. Find patterns in flight delays
47. Show me journeys with delay issues
48. Which routes experience frequent delays?

---

## 🏢 AIRLINE_INFO Queries

### General Airline Information (Baseline)
49. Tell me about the airline
50. What is the airline information?
51. Show airline details
52. Airline company information

### Airline Performance (Semantic)
53. How is the airline performing?
54. Show airline operational metrics
55. What are the airline's service quality metrics?

---

## 🛫 AIRPORT_INFO Queries

### Airport Details (Baseline)
56. Tell me about airport CAI
57. What is airport LHR?
58. Show information about Cairo airport
59. Airport details for London Heathrow

### Airport Performance (Semantic)
60. Which airports have the most traffic?
61. Show airport operational data
62. What are the busiest airports?

---

## 📊 GENERAL_KG_QUERY (Exploratory)

### Journey Analysis (Semantic)
63. Show me journey statistics
64. What are the journey patterns?
65. Analyze passenger journeys
66. Find interesting journey data
67. What insights can you provide about journeys?

### Flight Analysis (Baseline + Semantic)
68. Analyze flight performance
69. Show me flight statistics
70. What are the flight patterns?
71. Provide insights about flights

### Combined Analysis (Both Methods)
72. Show me overall airline performance
73. What are the key operational insights?
74. Analyze delays and satisfaction together
75. Show me comprehensive airline data

---

## 🔍 Edge Cases & Complex Queries

### Multi-Entity Queries
76. What is the status of flight 2411 from Cairo to London?
77. Show me satisfaction for flights from CAI to LHR
78. What are delays for flights between Cairo and London?

### Ambiguous Queries
79. Show me flights
80. What can you tell me?
81. Give me some information
82. Analyze the data

### Specific Metrics
83. What is the average delay for B777-200 aircraft?
84. Show me journeys with food satisfaction below 3
85. Find journeys with delays over 60 minutes
86. Which journeys have the highest satisfaction scores?

### Comparative Queries
87. Compare delays between different routes
88. Show me satisfaction trends
89. What are the differences between passenger classes?
90. Compare performance across different aircraft types

---

## 🧪 Testing Scenarios

### Test Baseline Only
- Questions 1-11, 28-31, 42-44, 49-52, 56-59
- Expected: Structured Cypher queries return results
- Semantic: 0 rows (or skipped for FLIGHT_STATUS)

### Test Semantic Only
- Questions 17-20, 32-35, 46-48, 53-55, 60-67
- Expected: Vector similarity search returns Journey nodes
- Baseline: May return 0 rows if no template matches

### Test Both Methods
- Questions 21-27, 36-41, 68-75, 76-90
- Expected: Both baseline and semantic return results
- Combined context provides comprehensive answer

### Test Intent Classification
- Mix of all question types
- Verify correct intent is detected
- Check entity extraction accuracy

### Test LLM Integration
- All questions with LLM enabled
- Verify answers are airline operations perspective
- Check that limitations are stated clearly
- Ensure no external system suggestions

---

## 📝 Quick Test Checklist

- [ ] FLIGHT_STATUS with exact flight number (baseline)
- [ ] FLIGHT_STATUS with route (baseline)
- [ ] BEST_ROUTE with cities (baseline)
- [ ] PASSENGER_SATISFACTION general (semantic)
- [ ] PASSENGER_SATISFACTION specific flight (baseline)
- [ ] DELAY_CAUSES high delays (baseline + semantic)
- [ ] DELAY_CAUSES average delays (baseline)
- [ ] AIRLINE_INFO general (baseline)
- [ ] AIRPORT_INFO specific (baseline)
- [ ] GENERAL_KG_QUERY exploratory (semantic)
- [ ] Test "Baseline only" retrieval method
- [ ] Test "Semantic only" retrieval method
- [ ] Test "Both" retrieval method
- [ ] Test with LLM enabled
- [ ] Test with different LLM models
- [ ] Verify UI displays correctly
- [ ] Check metrics dashboard accuracy
- [ ] Verify technical details in debug section

---

## 💡 Tips for Testing

1. **Start Simple**: Test basic queries first (flight status, satisfaction)
2. **Test Each Intent**: Ensure all intent types work
3. **Test Each Retrieval Method**: Baseline, Semantic, Both
4. **Test LLM Integration**: Enable LLM and verify answers
5. **Test Edge Cases**: Ambiguous queries, multi-entity queries
6. **Verify UI**: Check all sections display correctly
7. **Check Metrics**: Verify counts match actual results
8. **Test Different Models**: Try different LLM models if available

---

## 🎯 Priority Test Questions (Start Here)

If you want to quickly verify the system works, test these 10 questions first:

1. What is the status of flight 2411? (FLIGHT_STATUS, baseline)
2. What are poorly rated flights? (PASSENGER_SATISFACTION, semantic)
3. Find journeys with high delay and low food satisfaction (DELAY_CAUSES, semantic)
4. What is the best route from Cairo to London? (BEST_ROUTE, baseline)
5. Show me delayed journeys (DELAY_CAUSES, semantic)
6. What is satisfaction for flight 2411? (PASSENGER_SATISFACTION, baseline)
7. Which flights are delayed? (DELAY_CAUSES, both)
8. Show me journey statistics (GENERAL_KG_QUERY, semantic)
9. What flights go from CAI to LHR? (FLIGHT_STATUS, baseline)
10. Analyze flight performance (GENERAL_KG_QUERY, both)

---

## 🧪 COMPREHENSIVE TEST SUITE - All Possible Cases

### FLIGHT_STATUS - Complete Coverage

#### Flight Numbers (All Variations)
91. What is the status of flight 42? (Flight with journeys)
92. Show me information about flight 19? (Flight with journeys)
93. Flight 86 status (2-digit flight number)
94. What is the status of flight 27? (2-digit flight number)
95. Flight 966 details (3-digit flight number)
96. What is the status of flight 57? (2-digit flight number)
97. Show me flight 1686 (4-digit flight number)
98. Flight 219 information (3-digit flight number)
99. What is the status of flight 819? (3-digit flight number)
100. Flight 991 details (3-digit flight number)
101. What is the status of flight 1004? (4-digit flight number)
102. Show me flight 1005 (4-digit flight number)
103. Flight 1008 status (4-digit flight number)
104. What is the status of flight 1009? (4-digit flight number)
105. Flight 1010 details (4-digit flight number)

#### Route Queries (Real Airport Codes)
106. What flights go from LAX to IAX? (Real airports)
107. Show flights from ABX to ACX (Real airports)
108. What flights go from ALX to AMX? (Real airports)
109. Flights from ANX to ASX (Real airports)
110. What flights go from ATX to AUX? (Real airports)
111. Show flights from BCX to BDX (Real airports)
112. What flights go from CAI to LHR? (Missing airports - safe template)
113. Flights from JFK to DXB (Missing airports - safe template)
114. What flights go from CDG to FRA? (Missing airports - safe template)

#### Route Queries (Missing Airports - Error Handling)
115. What flights go from XXX to YYY? (Non-existent airports)
116. Show flights from ZZZ to AAA (Non-existent airports)
117. What flights go from INVALID to CODE? (Invalid airport codes)

---

### PASSENGER_SATISFACTION - Complete Coverage

#### Flight-Specific Satisfaction (All Flights with Data)
118. What is satisfaction for flight 42? (Flight with 14 journeys)
119. Show satisfaction scores for flight 19 (Flight with 13 journeys)
120. Passenger satisfaction for flight 86 (Flight with 12 journeys)
121. What is satisfaction for flight 27? (Flight with 12 journeys)
122. Satisfaction scores for flight 966 (Flight with 12 journeys)
123. What is satisfaction for flight 57? (Flight with 11 journeys)
124. Show satisfaction for flight 1686 (Flight with 11 journeys)
125. Passenger satisfaction for flight 219 (Flight with 11 journeys)
126. What is satisfaction for flight 819? (Flight with 9 journeys)
127. Satisfaction for flight 991 (Flight with 9 journeys)

#### Flight-Specific Satisfaction (Flights Without Data)
128. What is satisfaction for flight 2411? (Flight with 0 journeys - should show flight_found=False)
129. Show satisfaction for flight 99999 (Non-existent flight)
130. Passenger satisfaction for flight 0 (Invalid flight number)

#### General Satisfaction Queries
131. What are poorly rated flights? (Baseline + Semantic)
132. Show me flights with low satisfaction (Baseline + Semantic)
133. Which journeys have poor ratings? (Baseline + Semantic)
134. Find journeys with low food satisfaction scores (Baseline + Semantic)
135. What are the worst rated flights? (Baseline + Semantic)
136. Show me unsatisfied passengers (Baseline + Semantic)
137. Which flights have bad reviews? (Baseline + Semantic)
138. Find journeys with food satisfaction below 2 (Baseline)
139. Show me journeys with satisfaction score 1 (Baseline)
140. What journeys have the lowest food satisfaction? (Baseline)

#### High Satisfaction Queries
141. Find journeys with high satisfaction (Semantic)
142. Show me well-rated flights (Semantic)
143. Which journeys have good passenger feedback? (Semantic)
144. What are the best rated journeys? (Semantic)
145. Find journeys with food satisfaction above 4 (Baseline)
146. Show me journeys with satisfaction score 5 (Baseline)

---

### DELAY_CAUSES - Complete Coverage

#### Route-Specific Delay Queries (Real Routes)
147. What are delays for flights from LAX to IAX? (Route-specific delays)
148. Show delays for flights from ABX to ACX (Route-specific delays)
149. What are delays for flights from ALX to AMX? (Route-specific delays)
150. Delays for flights from ANX to ASX (Route-specific delays)
151. What are delays for flights from ATX to AUX? (Route-specific delays)
152. Show delays for flights from BCX to BDX (Route-specific delays)

#### Route-Specific Delay Queries (Missing Routes)
153. What are delays for flights from CAI to LHR? (Missing airports - should return 0)
154. Delays for flights from JFK to DXB (Missing airports - should return 0)
155. What are delays for flights from XXX to YYY? (Non-existent airports)

#### General Delay Queries
156. Which flights are delayed? (Baseline + Semantic)
157. Show me delayed journeys (Baseline + Semantic)
158. Find journeys with high delays (Baseline + Semantic)
159. What flights have significant delays? (Baseline + Semantic)
160. Which journeys are most delayed? (Baseline + Semantic)
161. Show me flights with arrival delays (Baseline + Semantic)
162. Find journeys with delays over 60 minutes (Baseline)
163. Show me journeys with delays over 120 minutes (Baseline)
164. What journeys have the highest delays? (Baseline)
165. Find journeys that arrived more than 30 minutes late (Baseline)

#### Early Arrival Queries
166. Show me journeys that arrived early (Baseline)
167. Find journeys with negative delay (arrived early) (Baseline)
168. Which flights arrived ahead of schedule? (Baseline)

#### Delay Analysis
169. What are the average delays by route? (Baseline)
170. Show delay statistics (Baseline)
171. Which routes have the most delays? (Baseline)
172. Calculate average delays for different routes (Baseline)
173. What are delay patterns by passenger class? (Baseline)
174. Show delay distribution by number of legs (Baseline)

---

### BEST_ROUTE - Complete Coverage

#### City-to-City Routes
175. What is the best route from Cairo to London? (Baseline)
176. Show me routes between Cairo and London (Baseline)
177. Best way to travel from Cairo to London (Baseline)
178. Routes from Cairo to London (Baseline)
179. How to get from Cairo to London? (Baseline)
180. What is the best route from Paris to New York? (Baseline)
181. Show routes from Tokyo to Sydney (Baseline)
182. Best route from Dubai to Singapore (Baseline)

#### Airport-to-Airport Routes (Real Codes)
183. What is the best route from LAX to IAX? (Real airports)
184. Show routes from ABX to ACX (Real airports)
185. Best route from ALX to AMX (Real airports)
186. Routes from ANX to ASX (Real airports)

#### Airport-to-Airport Routes (Missing Codes)
187. What is the best route from CAI to LHR? (Missing airports)
188. Show routes from JFK to DXB (Missing airports)

---

### AIRLINE_INFO - Complete Coverage

#### General Airline Queries
189. Tell me about the airline (Baseline)
190. What is the airline information? (Baseline)
191. Show airline details (Baseline)
192. Airline company information (Baseline)
193. Show me overall airline performance (Baseline)
194. What are the airline's key metrics? (Baseline)
195. Airline operational statistics (Baseline)

#### Airline Performance (Semantic)
196. How is the airline performing? (Semantic)
197. Show airline operational metrics (Semantic)
198. What are the airline's service quality metrics? (Semantic)

---

### AIRPORT_INFO - Complete Coverage

#### Real Airport Codes
199. Tell me about airport LAX (Real airport)
200. What is airport IAX? (Real airport)
201. Show information about ABX airport (Real airport)
202. Airport details for ACX (Real airport)
203. Tell me about ALX airport (Real airport)
204. What is AMX airport? (Real airport)
205. Show information about ANX airport (Real airport)
206. Airport details for ASX (Real airport)

#### Missing Airport Codes
207. Tell me about airport CAI (Missing airport)
208. What is airport LHR? (Missing airport)
209. Show information about JFK airport (Missing airport)
210. Airport details for DXB (Missing airport)

#### City-Based Airport Queries
211. Show information about Cairo airport (City query)
212. Airport details for London Heathrow (City query)
213. What airports are in Paris? (City query)
214. Show me airports in New York (City query)

---

### GENERAL_KG_QUERY - Complete Coverage

#### Journey Statistics & Patterns
215. Show me journey statistics (Baseline + Semantic)
216. What are the journey patterns? (Baseline + Semantic)
217. Analyze passenger journeys (Baseline + Semantic)
218. Find interesting journey data (Semantic)
219. What insights can you provide about journeys? (Semantic)
220. Show me journey distribution by class (Baseline)
221. What are the journey patterns by legs? (Baseline)
222. Analyze journey patterns by distance (Baseline)

#### Flight Analysis
223. Analyze flight performance (Baseline + Semantic)
224. Show me flight statistics (Baseline + Semantic)
225. What are the flight patterns? (Baseline + Semantic)
226. Provide insights about flights (Baseline + Semantic)
227. Show me all flights (Baseline)
228. What flights do we have? (Baseline)
229. List all flight numbers (Baseline)

#### Combined Analysis
230. Show me overall airline performance (Baseline + Semantic)
231. What are the key operational insights? (Baseline + Semantic)
232. Analyze delays and satisfaction together (Baseline + Semantic)
233. Show me comprehensive airline data (Baseline + Semantic)
234. What are the operational trends? (Baseline + Semantic)

---

### SEMANTIC FALLBACK - Test Cases (Baseline=0, Semantic Should Work)

#### Queries with No Baseline Template
235. What are the most popular passenger classes? (No baseline template - semantic fallback)
236. Which airports have the most connections? (No baseline template - semantic fallback)
237. What is the distribution of journey distances? (No baseline template - semantic fallback)
238. Show me passenger class breakdown (No baseline template - semantic fallback)
239. What are the journey leg patterns? (No baseline template - semantic fallback)

---

### EDGE CASES - Comprehensive Testing

#### Entity Extraction Edge Cases
240. What is the status of flight 42? (2-digit number)
241. Show me flight 5 (1-digit number - may not be detected)
242. Flight 12345 status (5-digit number)
243. What is the status of flight BA2490? (Alphanumeric)
244. Show me flight AA123 (Alphanumeric)
245. What flights go from lax to iax? (Lowercase airport codes - should normalize)
246. Show flights from Lax to Iax (Mixed case - should normalize)

#### Intent Classification Edge Cases
247. Show me information about flight 2411 (Should be FLIGHT_STATUS, not GENERAL_KG_QUERY)
248. What is satisfaction for flight 42? (Should be PASSENGER_SATISFACTION, not FLIGHT_STATUS)
249. What are delays for flight 42? (Should be DELAY_CAUSES)
250. Show me flight 42 rating (Should be PASSENGER_SATISFACTION)
251. What is flight 42 delay? (Should be DELAY_CAUSES)

#### Multi-Entity Queries
252. What is the status of flight 42 from LAX to IAX? (Flight + Route)
253. Show me satisfaction for flight 42 from LAX (Flight + Airport)
254. What are delays for flights from LAX to IAX for flight 42? (Route + Flight)
255. Show me flight 42 satisfaction and delays (Flight + Multiple intents)

#### Ambiguous Queries
256. Show me flights (Very ambiguous)
257. What can you tell me? (Very ambiguous)
258. Give me some information (Very ambiguous)
259. Analyze the data (Very ambiguous)
260. Tell me something (Very ambiguous)
261. What do you know? (Very ambiguous)

#### Boundary Cases
262. What is the status of flight 0? (Invalid flight number)
263. Show me flight -1 (Invalid flight number)
264. What flights go from A to B? (Invalid airport codes)
265. Show flights from 123 to 456 (Invalid airport codes)
266. What is satisfaction for flight ? (Missing flight number)
267. Show delays for flights from ? to ? (Missing airport codes)

#### Safe Template Scenarios
268. What flights go from CAI to LHR? (Missing airports - safe template)
269. Show flights from JFK to DXB (Missing airports - safe template)
270. What flights go from XXX to YYY? (Non-existent airports - safe template)
271. Flights from ZZZ to AAA (Non-existent airports - safe template)

#### Error Handling Cases
272. What is the status of flight 99999? (Non-existent flight - should show flight_found=False)
273. Show satisfaction for flight 99999 (Non-existent flight - should show flight_found=False)
274. What flights go from INVALID to CODE? (Invalid codes - should show origin_found=False, dest_found=False)

---

### RETRIEVAL METHOD COMBINATIONS - Systematic Testing

#### Baseline Only - All Intents
275. What is the status of flight 42? (Baseline only - FLIGHT_STATUS)
276. What are poorly rated flights? (Baseline only - PASSENGER_SATISFACTION)
277. Which flights are delayed? (Baseline only - DELAY_CAUSES)
278. What is the best route from Cairo to London? (Baseline only - BEST_ROUTE)
279. Tell me about the airline (Baseline only - AIRLINE_INFO)
280. Tell me about airport LAX (Baseline only - AIRPORT_INFO)
281. Show me journey statistics (Baseline only - GENERAL_KG_QUERY)

#### Semantic Only - All Intents
282. What is the status of flight 42? (Semantic only - should use baseline fallback)
283. What are poorly rated flights? (Semantic only - PASSENGER_SATISFACTION)
284. Which flights are delayed? (Semantic only - DELAY_CAUSES)
285. What is the best route from Cairo to London? (Semantic only - BEST_ROUTE)
286. Tell me about the airline (Semantic only - AIRLINE_INFO)
287. Tell me about airport LAX (Semantic only - AIRPORT_INFO)
288. Show me journey statistics (Semantic only - GENERAL_KG_QUERY)

#### Both Methods - All Intents
289. What is the status of flight 42? (Both - FLIGHT_STATUS, semantic skipped)
290. What are poorly rated flights? (Both - PASSENGER_SATISFACTION)
291. Which flights are delayed? (Both - DELAY_CAUSES)
292. What is the best route from Cairo to London? (Both - BEST_ROUTE)
293. Tell me about the airline (Both - AIRLINE_INFO)
294. Tell me about airport LAX (Both - AIRPORT_INFO)
295. Show me journey statistics (Both - GENERAL_KG_QUERY, both should work)

---

### TEMPLATE-SPECIFIC TEST CASES

#### Flight Status Templates
296. What is the status of flight 42? (flight_status_by_number)
297. What flights go from LAX to IAX? (safe_flight_status_by_route - real airports)
298. What flights go from CAI to LHR? (safe_flight_status_by_route - missing airports)

#### Satisfaction Templates
299. What are poorly rated flights? (low_satisfaction_journeys)
300. What is satisfaction for flight 42? (satisfaction_by_flight_number)
301. Show satisfaction for EgyptAir (passenger_satisfaction_for_airline)

#### Delay Templates
302. Which flights are delayed? (high_delay_journeys)
303. What are delays for flights from LAX to IAX? (delay_causes_for_route)
304. What are the average delays by route? (average_delays_by_route)

#### Route Templates
305. What is the best route from Cairo to London? (best_route_by_city)
306. What is the best route from LAX to IAX? (best_route_by_airport_codes)

#### Airport Templates
307. Tell me about airport LAX (airport_basic_info)
308. Show information about Cairo airport (airport_info_by_city)
309. What are popular routes from LAX? (popular_routes_from_airport)

#### General Templates
310. Show me journey statistics (journey_statistics)
311. What are the journey patterns? (journey_patterns)
312. Analyze passenger journeys (analyze_passenger_journeys)
313. Show me overall airline performance (overall_airline_performance)
314. Show me flights (general_flights_from_city)

---

### LLM INTEGRATION TEST CASES

#### With LLM Enabled - All Intents
315. What is the status of flight 42? (LLM should provide comprehensive analysis)
316. What are poorly rated flights? (LLM should identify patterns)
317. Which flights are delayed? (LLM should analyze delay causes)
318. What is the best route from Cairo to London? (LLM should provide recommendations)
319. Tell me about the airline (LLM should provide performance overview)
320. Tell me about airport LAX (LLM should provide airport insights)
321. Show me journey statistics (LLM should provide statistical analysis)

#### LLM Error Handling
322. What is the status of flight 99999? (LLM should handle missing data gracefully)
323. Show flights from XXX to YYY (LLM should explain missing airports)
324. What is satisfaction for flight 0? (LLM should handle invalid input)

---

### COMPREHENSIVE COVERAGE CHECKLIST

#### Intent Coverage (7 intents × multiple variations)
- [x] FLIGHT_STATUS: Flight numbers (1-2, 3-4, 5+ digits), Routes (real, missing), Alphanumeric
- [x] PASSENGER_SATISFACTION: General, Flight-specific, High/Low satisfaction, With/without data
- [x] DELAY_CAUSES: General delays, Route-specific, High delays, Early arrivals, Analysis
- [x] BEST_ROUTE: City-to-city, Airport-to-airport (real, missing)
- [x] AIRLINE_INFO: General, Performance metrics
- [x] AIRPORT_INFO: Real airports, Missing airports, City-based
- [x] GENERAL_KG_QUERY: Journey stats, Flight analysis, Combined analysis

#### Entity Coverage
- [x] FLIGHT_NUMBER: 1-digit, 2-digit, 3-digit, 4-digit, 5-digit, Alphanumeric, Invalid
- [x] AIRPORT_CODE: Real codes, Missing codes, Invalid codes, Lowercase, Mixed case
- [x] CITY: Real cities, Missing cities
- [x] AIRLINE: With airline name, Without airline name

#### Retrieval Method Coverage
- [x] Baseline only: All intents
- [x] Semantic only: All intents (with fallback where needed)
- [x] Both methods: All intents

#### Edge Case Coverage
- [x] Missing data (flights without journeys, missing airports)
- [x] Invalid input (non-existent flights, invalid airport codes)
- [x] Boundary cases (0, negative numbers, very large numbers)
- [x] Ambiguous queries (no entities, no clear intent)
- [x] Multi-entity queries (flight + route, multiple airports)
- [x] Safe template scenarios (missing airports, missing flights)
- [x] Error handling (flight_found=False, origin_found=False)

#### Template Coverage
- [x] All 17+ templates tested with appropriate queries
- [x] Safe templates tested with missing data
- [x] Fallback templates tested

---

**Total Questions: 324**
**Coverage: All intents, all retrieval methods, all edge cases, all templates, comprehensive testing**
