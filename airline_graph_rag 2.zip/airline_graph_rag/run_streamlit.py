#!/usr/bin/env python3
"""
Wrapper script to run Streamlit with proper environment variables.
This suppresses PyTorch/Streamlit warnings that appear in the terminal.

Usage:
    python run_streamlit.py
    # or
    python run_streamlit.py --server.port 8502
"""

import os
import sys
import subprocess

# Set environment variables BEFORE importing anything
os.environ["STREAMLIT_SERVER_FILE_WATCHER_TYPE"] = "none"
os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["PYTHONWARNINGS"] = "ignore"

# Suppress warnings
import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")

# Now run Streamlit
if __name__ == "__main__":
    cmd = ["streamlit", "run", "ui/app.py"] + sys.argv[1:]
    subprocess.run(cmd)
