"""
Simple sanity tests for semantic (embedding-based) retrieval.
Run from project root:

    python -m tests.test_semantic_retrieval
"""

from backend.retrieval.embedding_retrieval import semantic_retrieve
from backend.preprocessing.embeddings import EmbeddingService, EmbeddingBackend
from backend.neo4j_client import Neo4jClient


TEST_QUERIES = [
    "What are journeys with high food satisfaction?",
    "Which journeys have long delays but high food satisfaction?",
    "Show journeys with short flights and low food satisfaction.",
    "Find journeys with medium delay and medium food satisfaction.",
]


def run_semantic_tests():
    embedding_service = EmbeddingService(EmbeddingBackend.SENTENCE_TRANSFORMER)
    client = Neo4jClient()

    for q in TEST_QUERIES:
        print("=" * 70)
        print(f"Query: {q}")

        rows = semantic_retrieve(
            client=client,
            embedding_service=embedding_service,
            question=q,
            top_k=5
        )

        print(f"Returned {len(rows)} rows")

        # Basic checks
        assert len(rows) > 0, "Expected at least 1 result"

        for r in rows:
            score = r.get("_similarity_score")
            assert score is not None, "Missing _similarity_score in result row"
            assert 0.0 <= score <= 1.0, f"Score out of range: {score}"

        print("✓ Passed basic sanity checks.\n")


if __name__ == "__main__":
    try:
    run_semantic_tests()
    print("\nAll semantic retrieval sanity tests passed ✅")
    finally:
        client.close()
