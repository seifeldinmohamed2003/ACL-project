"""
LLM Model Client supporting multiple providers.

Supports:
- OpenAI (GPT-3.5, GPT-4)
- HuggingFace Inference API (free models)
- OpenRouter (access to multiple models)
"""

from enum import Enum
from typing import Optional, Dict, Any
import time
import os

from backend.config import settings


class LLMProvider(Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    HUGGINGFACE = "huggingface"
    OPENROUTER = "openrouter"


class LLMModel(Enum):
    """Available LLM models."""
    # OpenAI models
    GPT_3_5_TURBO = ("openai", "gpt-3.5-turbo", "OpenAI GPT-3.5 Turbo")
    GPT_4 = ("openai", "gpt-4", "OpenAI GPT-4 (requires paid plan)")
    GPT_4_TURBO = ("openai", "gpt-4-turbo-preview", "OpenAI GPT-4 Turbo")
    GPT_4O_MINI = ("openai", "gpt-4o-mini", "OpenAI GPT-4o Mini (cheaper)")
    
    # HuggingFace models (free, via Inference API)
    # Using models that are confirmed to work with Inference API
    MISTRAL_7B = ("huggingface", "mistralai/Mistral-7B-Instruct-v0.2", "Mistral 7B Instruct")
    GEMMA_2B = ("huggingface", "google/gemma-2-2b-it", "Google Gemma 2B")
    # Models that work reliably with text-generation API
    FLAN_T5_BASE = ("huggingface", "google/flan-t5-base", "Google Flan-T5 Base (Reliable)")
    FLAN_T5_LARGE = ("huggingface", "google/flan-t5-large", "Google Flan-T5 Large")
    # Alternative reliable model
    FALCON_7B = ("huggingface", "tiiuae/falcon-7b-instruct", "Falcon 7B Instruct")
    
    # OpenRouter models (free tier options - actual free models!)
    DEEPSEEK_FREE = ("openrouter", "nex-agi/deepseek-v3.1-nex-n1:free", "DeepSeek V3.1 Nex (FREE)")
    MISTRAL_FREE = ("openrouter", "mistralai/devstral-2512:free", "Mistral Devstral 2 (FREE)")
    AMAZON_FREE = ("openrouter", "amazon/nova-2-lite-v1:free", "Amazon Nova 2 Lite (FREE)")
    # Paid but cheap models
    LLAMA_3_8B = ("openrouter", "meta-llama/llama-3-8b-instruct", "Llama 3 8B Instruct")
    
    def __init__(self, provider: str, model_id: str, display_name: str):
        self.provider = provider
        self.model_id = model_id
        self.display_name = display_name


class LLMClient:
    """Unified client for multiple LLM providers."""
    
    def __init__(self, model: LLMModel):
        self.model = model
        self.provider = LLMProvider(model.provider)
        self._client = None
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the appropriate client based on provider."""
        if self.provider == LLMProvider.OPENAI:
            try:
                import openai
                if not settings.OPENAI_API_KEY:
                    raise RuntimeError("OPENAI_API_KEY not set in environment")
                self._client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            except ImportError:
                raise ImportError("openai package not installed. Run: pip install openai")
        
        elif self.provider == LLMProvider.HUGGINGFACE:
            try:
                from huggingface_hub import InferenceClient
                # HuggingFace Inference API requires authentication
                # Get free token at: https://huggingface.co/settings/tokens
                hf_token = settings.HUGGINGFACE_API_TOKEN or os.getenv("HUGGINGFACE_API_TOKEN") or os.getenv("HF_TOKEN")
                if hf_token:
                    self._client = InferenceClient(token=hf_token)
                else:
                    # Try without token, but it will likely fail
                    try:
                        self._client = InferenceClient()
                    except Exception as e:
                        raise RuntimeError(
                            "HuggingFace API requires authentication. "
                            "Get a FREE token at https://huggingface.co/settings/tokens "
                            "(create account if needed, then create a token). "
                            "Then add HUGGINGFACE_API_TOKEN=your_token to your .env file. "
                            f"Original error: {e}"
                        )
            except ImportError:
                raise ImportError("huggingface_hub not installed. Run: pip install huggingface_hub")
        
        elif self.provider == LLMProvider.OPENROUTER:
            try:
                import openai
                # OpenRouter uses OpenAI-compatible API
                # Try primary token first, fallback to alternative if available
                api_key = settings.OPENROUTER_API_KEY or os.getenv('OPENROUTER_API_KEY')
                alt_api_key = settings.OPENROUTER_API_KEY_ALT or os.getenv('OPENROUTER_API_KEY_ALT')
                
                if not api_key and not alt_api_key:
                    raise RuntimeError("OPENROUTER_API_KEY not set. Get free key at https://openrouter.ai")
                
                # Store both keys for fallback mechanism
                self._openrouter_primary_key = api_key
                self._openrouter_alt_key = alt_api_key
                
                # Initialize with primary key (will switch to alt if rate limited)
                self._client = openai.OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=api_key or alt_api_key  # Use primary if available, else alt
                )
            except ImportError:
                raise ImportError("openai package not installed. Run: pip install openai")
    
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> Dict[str, Any]:
        """
        Generate a response from the LLM.
        
        Args:
            prompt: User prompt/question
            system_prompt: System/instruction prompt
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dictionary with 'text', 'usage', 'model', 'response_time'
        """
        start_time = time.time()
        
        try:
            if self.provider == LLMProvider.OPENAI:
                messages = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.append({"role": "user", "content": prompt})
                
                try:
                    response = self._client.chat.completions.create(
                        model=self.model.model_id,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens
                    )
                    
                    return {
                        "text": response.choices[0].message.content,
                        "usage": {
                            "prompt_tokens": response.usage.prompt_tokens,
                            "completion_tokens": response.usage.completion_tokens,
                            "total_tokens": response.usage.total_tokens
                        },
                        "model": self.model.model_id,
                        "response_time": time.time() - start_time
                    }
                except Exception as e:
                    error_msg = str(e)
                    error_lower = error_msg.lower()
                    
                    # Check if it's a quota/rate limit error
                    if "429" in error_msg or "quota" in error_lower or "insufficient_quota" in error_lower or "rate limit" in error_lower:
                        raise RuntimeError(
                            f"OpenAI API quota exceeded or rate limited.\n"
                            f"Error: {error_msg}\n\n"
                            "Solutions:\n"
                            "1. Wait a few minutes and try again (rate limits reset)\n"
                            "2. Check your OpenAI usage: https://platform.openai.com/usage\n"
                            "3. Add billing/payment method to increase quota\n"
                            "4. Use HuggingFace models instead (free, no quota)\n"
                            "5. Use OpenRouter for free tier access to multiple models"
                        )
                    # Check if it's a model access error
                    elif "model_not_found" in error_lower or "does not exist" in error_lower or "do not have access" in error_lower:
                        raise RuntimeError(
                            f"Model {self.model.model_id} is not available or you don't have access.\n"
                            f"Error: {error_msg}\n\n"
                            "Solutions:\n"
                            "1. Use 'GPT-3.5 Turbo' instead (available on free tier)\n"
                            "2. Use 'GPT-4o Mini' (newer, cheaper alternative)\n"
                            "3. GPT-4 requires a paid OpenAI plan\n"
                            "4. Check your OpenAI account access level"
                        )
                    else:
                        raise
            
            elif self.provider == LLMProvider.HUGGINGFACE:
                # HuggingFace Inference API
                # Build prompt (combine system and user prompt)
                combined_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt
                text = None
                conv_error = None
                text_error = None
                
                # Set timeout to prevent long waits (10 seconds)
                import signal
                
                # For Mistral Instruct models, try conversational API first
                if "mistral" in self.model.model_id.lower() and "instruct" in self.model.model_id.lower():
                    try:
                        # Try with timeout
                        response = self._client.conversational(
                            text=combined_prompt,
                            past_user_inputs=[],
                            generated_responses=[],
                            model=self.model.model_id,
                            timeout=10.0  # 10 second timeout
                        )
                        text = response.get("generated_text", "")
                    except Exception as e:
                        conv_error = e
                        text = None
                
                # If conversational didn't work or not a Mistral model, try text generation
                if not text:
                    try:
                        # Format prompt for instruction models
                        if "instruct" in self.model.model_id.lower() or "it" in self.model.model_id.lower():
                            if "mistral" in self.model.model_id.lower():
                                formatted_prompt = f"<s>[INST] {combined_prompt} [/INST]"
                            elif "gemma" in self.model.model_id.lower():
                                formatted_prompt = f"<start_of_turn>user\n{combined_prompt}<end_of_turn>\n<start_of_turn>model\n"
                            else:
                                formatted_prompt = combined_prompt
                        else:
                            formatted_prompt = combined_prompt
                        
                        # For Flan-T5 models, use simpler API call (they work better this way)
                        if "flan-t5" in self.model.model_id.lower():
                            response = self._client.text_generation(
                                prompt=formatted_prompt,
                                model=self.model.model_id,
                                max_new_tokens=min(max_tokens, 200),  # Flan models work better with smaller limits
                                return_full_text=False,
                                timeout=10.0  # 10 second timeout
                            )
                        else:
                            response = self._client.text_generation(
                                prompt=formatted_prompt,
                                model=self.model.model_id,
                                max_new_tokens=max_tokens,
                                temperature=temperature,
                                return_full_text=False,
                                timeout=10.0  # 10 second timeout
                            )
                        text = response
                    except Exception as e:
                        text_error = e
                        # Check if it's a timeout
                        error_str = str(e).lower()
                        if "timeout" in error_str or "timed out" in error_str or "max retries" in error_str:
                            text_error = RuntimeError(
                                f"Request timed out after 10 seconds. "
                                f"The model {self.model.model_id} may not be available via Inference API. "
                                f"Try using OpenAI models instead (faster and more reliable)."
                            )
                        # For Flan models, try one more time with just user prompt (no system)
                        if "flan" in self.model.model_id.lower() and system_prompt and not isinstance(text_error, RuntimeError):
                            try:
                                simple_response = self._client.text_generation(
                                    prompt=prompt,  # Just user prompt
                                    model=self.model.model_id,
                                    max_new_tokens=min(max_tokens, 200),
                                    return_full_text=False,
                                    timeout=5.0  # Shorter timeout for retry
                                )
                                text = simple_response
                                text_error = None  # Success!
                            except:
                                pass  # Keep original error
                
                # If both failed, raise helpful error
                if not text:
                    error_parts = [f"HuggingFace API error for {self.model.model_id}."]
                    if conv_error:
                        error_parts.append(f"Conversational API error: {str(conv_error)}")
                    if text_error:
                        error_parts.append(f"Text generation API error: {str(text_error)}")
                    
                    # Check if token is set
                    hf_token = settings.HUGGINGFACE_API_TOKEN or os.getenv("HUGGINGFACE_API_TOKEN") or os.getenv("HF_TOKEN")
                    if not hf_token:
                        error_parts.append("\n⚠ HUGGINGFACE_API_TOKEN is not set!")
                        error_parts.append("Get a FREE token at: https://huggingface.co/settings/tokens")
                        error_parts.append("Add to .env: HUGGINGFACE_API_TOKEN=your_token")
                    else:
                        error_parts.append("\n⚠ Token is set but API call failed.")
                        error_parts.append("The model might not be available via Inference API.")
                    
                    error_parts.append("\nSolutions:")
                    error_parts.append("1. Verify HUGGINGFACE_API_TOKEN is correct in .env")
                    error_parts.append("2. Try OpenAI models (GPT-3.5/GPT-4) if you have an API key")
                    error_parts.append("3. Check HuggingFace model page for API availability")
                    
                    raise RuntimeError("\n".join(error_parts))
                
                return {
                    "text": text,
                    "usage": {
                        "prompt_tokens": None,
                        "completion_tokens": None,
                        "total_tokens": None
                    },
                    "model": self.model.model_id,
                    "response_time": time.time() - start_time
                }
            
            elif self.provider == LLMProvider.OPENROUTER:
                # OpenRouter uses OpenAI-compatible API
                messages = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.append({"role": "user", "content": prompt})
                
                # Log the exact model being sent (only in debug mode)
                import os
                debug_llm = os.getenv("DEBUG_LLM", "false").lower() == "true"
                if debug_llm:
                    print(f"[DEBUG LLM] Sending request to OpenRouter with model: {self.model.model_id}")
                    print(f"[DEBUG LLM] Model display name: {self.model.display_name}")
                
                try:
                    response = self._client.chat.completions.create(
                        model=self.model.model_id,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens
                    )
                    
                    # Log the actual model used (OpenRouter may route to different model)
                    actual_model = getattr(response, 'model', None) or self.model.model_id
                    if debug_llm:
                        print(f"[DEBUG LLM] OpenRouter response - requested: {self.model.model_id}, actual: {actual_model}")
                    
                    return {
                        "text": response.choices[0].message.content,
                        "usage": {
                            "prompt_tokens": response.usage.prompt_tokens,
                            "completion_tokens": response.usage.completion_tokens,
                            "total_tokens": response.usage.total_tokens
                        },
                        "model": actual_model,  # Use actual model from response
                        "requested_model": self.model.model_id,  # Keep track of what we requested
                        "model_display_name": self.model.display_name,
                        "response_time": time.time() - start_time
                    }
                except Exception as e:
                    error_msg = str(e)
                    error_lower = error_msg.lower()
                    
                    # Check if it's a rate limit error and we have an alternative token
                    if ("429" in error_msg or "rate limit" in error_lower or "rate_limit" in error_lower) and hasattr(self, '_openrouter_alt_key') and self._openrouter_alt_key:
                        # Try with alternative token
                        try:
                            import openai
                            alt_client = openai.OpenAI(
                                base_url="https://openrouter.ai/api/v1",
                                api_key=self._openrouter_alt_key
                            )
                            import os
                            if os.getenv("DEBUG_LLM", "false").lower() == "true":
                                print(f"[DEBUG LLM] Retrying with alternative OpenRouter key, model: {self.model.model_id}")
                            response = alt_client.chat.completions.create(
                                model=self.model.model_id,
                                messages=messages,
                                temperature=temperature,
                                max_tokens=max_tokens
                            )
                            
                            actual_model = getattr(response, 'model', None) or self.model.model_id
                            import os
                            if os.getenv("DEBUG_LLM", "false").lower() == "true":
                                print(f"[DEBUG LLM] Alternative key response - requested: {self.model.model_id}, actual: {actual_model}")
                            
                            return {
                                "text": response.choices[0].message.content,
                                "usage": {
                                    "prompt_tokens": response.usage.prompt_tokens,
                                    "completion_tokens": response.usage.completion_tokens,
                                    "total_tokens": response.usage.total_tokens
                                },
                                "model": actual_model,
                                "requested_model": self.model.model_id,
                                "model_display_name": self.model.display_name,
                                "response_time": time.time() - start_time
                            }
                        except Exception as alt_e:
                            # Both tokens failed, raise original error
                            if debug_llm:
                                print(f"[DEBUG LLM] Alternative key also failed: {alt_e}")
                            raise e
                    else:
                        # Not a rate limit or no alt token, raise original error
                        if debug_llm:
                            print(f"[DEBUG LLM] Not retrying with alt key (error: {error_msg[:100]})")
                        raise e
        
        except Exception as e:
            error_str = str(e)
            import os
            if os.getenv("DEBUG_LLM", "false").lower() == "true":
                print(f"[DEBUG LLM] Error with model {self.model.model_id} ({self.model.display_name}): {error_str}")
                # Try to extract HTTP body if it's an API error
                if hasattr(e, 'response') and hasattr(e.response, 'text'):
                    print(f"[DEBUG LLM] HTTP response body: {e.response.text}")
            return {
                "text": f"Error generating response: {error_str}",
                "usage": {},
                "model": self.model.model_id,
                "model_display_name": self.model.display_name,
                "response_time": time.time() - start_time,
                "error": error_str
            }


def get_available_models() -> list[LLMModel]:
    """
    Get list of available models based on API keys.
    Prioritizes OpenRouter and OpenAI over HuggingFace (which is unreliable).
    """
    available = []
    
    # Priority 1: OpenRouter (has free tier and is reliable!)
    # Check both primary and alternative tokens
    or_key = settings.OPENROUTER_API_KEY or os.getenv('OPENROUTER_API_KEY')
    or_alt_key = settings.OPENROUTER_API_KEY_ALT or os.getenv('OPENROUTER_API_KEY_ALT')
    if or_key or or_alt_key:
        # Add free models first (they're actually free and reliable!)
        available.append(LLMModel.DEEPSEEK_FREE)
        available.append(LLMModel.MISTRAL_FREE)
        available.append(LLMModel.AMAZON_FREE)
        # Also add cheap paid model
        available.append(LLMModel.LLAMA_3_8B)
    
    # Priority 2: OpenAI (reliable and fast)
    if settings.OPENAI_API_KEY:
        available.append(LLMModel.GPT_4O_MINI)  # Newer, cheaper alternative (recommended)
        available.append(LLMModel.GPT_3_5_TURBO)  # Most accessible
        # GPT-4 requires paid plan, add it but user may not have access
        available.append(LLMModel.GPT_4)
        available.append(LLMModel.GPT_4_TURBO)
    
    # Priority 3: HuggingFace (only if OpenRouter/OpenAI not available - often unreliable)
    # Only add if no other options are available
    if not available:
        hf_token = settings.HUGGINGFACE_API_TOKEN or os.getenv("HUGGINGFACE_API_TOKEN") or os.getenv("HF_TOKEN")
        if hf_token:
            # Add HuggingFace models as last resort
            # Note: These often timeout or fail, so they're deprioritized
            available.append(LLMModel.MISTRAL_7B)  # Most reliable HuggingFace option
            available.append(LLMModel.GEMMA_2B)
            available.append(LLMModel.FALCON_7B)
            # Flan models are often unreliable (timeout), add last
            available.append(LLMModel.FLAN_T5_BASE)
            available.append(LLMModel.FLAN_T5_LARGE)
        else:
            # Still show them but user will need to add token
            available.append(LLMModel.MISTRAL_7B)
            available.append(LLMModel.GEMMA_2B)
            available.append(LLMModel.FLAN_T5_BASE)
    
    return available


if __name__ == "__main__":
    """Test LLM clients."""
    print("Testing LLM Clients")
    print("=" * 70)
    
    # Test HuggingFace (free, no key required)
    print("\n1. Testing HuggingFace (Mistral 7B)...")
    try:
        client = LLMClient(LLMModel.MISTRAL_7B)
        response = client.generate("What is a knowledge graph?", max_tokens=100)
        print(f"Response: {response['text'][:200]}...")
        print(f"Time: {response['response_time']:.2f}s")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test OpenAI if key available
    if settings.OPENAI_API_KEY:
        print("\n2. Testing OpenAI (GPT-3.5)...")
        try:
            client = LLMClient(LLMModel.GPT_3_5_TURBO)
            response = client.generate("What is a knowledge graph?", max_tokens=100)
            print(f"Response: {response['text'][:200]}...")
            print(f"Time: {response['response_time']:.2f}s")
        except Exception as e:
            print(f"Error: {e}")
    
    print("\n" + "=" * 70)
    print("Available models:")
    for model in get_available_models():
        print(f"  - {model.display_name} ({model.provider})")
