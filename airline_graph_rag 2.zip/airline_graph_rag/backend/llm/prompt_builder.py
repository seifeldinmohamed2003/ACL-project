"""
Prompt builder for structured LLM prompts.

Creates prompts with three components:
1. Context: Retrieved KG information
2. Persona: Assistant's role
3. Task: Instructions for the LLM
"""

from typing import List, Dict, Any, Optional


def format_context(baseline_rows: List[Dict[str, Any]], semantic_rows: List[Dict[str, Any]], debug: bool = False) -> str:
    """
    Format retrieved graph data into context string.
    
    Args:
        baseline_rows: Results from Cypher queries
        semantic_rows: Results from semantic search
        debug: If True, log context assembly details
        
    Returns:
        Formatted context string
    """
    # CRITICAL: Assert that if we have rows, they're actually included
    if debug:
        print(f"[DEBUG CONTEXT] Formatting context: baseline_rows={len(baseline_rows)}, semantic_rows={len(semantic_rows)}")
        if baseline_rows:
            print(f"[DEBUG CONTEXT] First baseline row keys: {list(baseline_rows[0].keys())}")
            print(f"[DEBUG CONTEXT] First baseline row sample: {dict(list(baseline_rows[0].items())[:5])}")
    
    context_parts = []
    
    if baseline_rows:
        total_baseline = len(baseline_rows)
        shown_baseline = min(10, total_baseline)
        context_parts.append(f"=== Baseline Query Results (Structured Data) ===")
        context_parts.append(f"Total baseline results: {total_baseline} (showing first {shown_baseline})")
        for i, row in enumerate(baseline_rows[:10], 1):  # Limit to 10 rows
            # Remove embedding vectors for readability
            clean_row = {k: v for k, v in row.items() if k != "embedding"}
            context_parts.append(f"\nResult {i}:")
            for key, value in clean_row.items():
                context_parts.append(f"  {key}: {value}")
    else:
        if debug:
            print("[DEBUG CONTEXT] WARNING: baseline_rows is empty!")
    
    if semantic_rows:
        total_semantic = len(semantic_rows)
        shown_semantic = min(10, total_semantic)
        context_parts.append("\n=== Semantic Search Results (Similar Journeys) ===")
        context_parts.append(f"Total semantic results: {total_semantic} (showing first {shown_semantic})")
        for i, row in enumerate(semantic_rows[:10], 1):  # Limit to 10 rows
            # Remove embedding vectors, keep similarity score
            clean_row = {k: v for k, v in row.items() if k != "embedding"}
            similarity = clean_row.pop("_similarity_score", None)
            if similarity is not None:
                context_parts.append(f"\nResult {i} (Similarity: {similarity:.3f}):")
            else:
                context_parts.append(f"\nResult {i}:")
            for key, value in clean_row.items():
                context_parts.append(f"  {key}: {value}")
    
    if not context_parts:
        return "No relevant data found in the knowledge graph."
    
    context_str = "\n".join(context_parts)
    
    # CRITICAL ASSERTION: If we have rows, context must include them
    if baseline_rows and "Total baseline results: 0" not in context_str:
        # Verify at least one row is in context
        if f"Result 1:" not in context_str:
            if debug:
                print(f"[DEBUG CONTEXT] ERROR: baseline_rows={len(baseline_rows)} but context doesn't contain 'Result 1:'")
                print(f"[DEBUG CONTEXT] Context preview: {context_str[:200]}")
            # Force include at least first row
            context_parts = []
            context_parts.append(f"=== Baseline Query Results (Structured Data) ===")
            context_parts.append(f"Total baseline results: {len(baseline_rows)} (showing first {min(10, len(baseline_rows))})")
            for i, row in enumerate(baseline_rows[:10], 1):
                clean_row = {k: v for k, v in row.items() if k != "embedding"}
                context_parts.append(f"\nResult {i}:")
                for key, value in clean_row.items():
                    context_parts.append(f"  {key}: {value}")
            context_str = "\n".join(context_parts)
    
    return context_str


def build_prompt(
    question: str,
    baseline_rows: List[Dict[str, Any]],
    semantic_rows: List[Dict[str, Any]],
    intent: Optional[str] = None,
    total_rows: int = 0,
    num_baseline_rows: int = 0,
    template_id: Optional[str] = None
) -> tuple[str, str]:
    """
    Build structured prompt with context, persona, and task.
    
    Args:
        question: User's question
        baseline_rows: Results from baseline retrieval
        semantic_rows: Results from semantic retrieval
        intent: Detected intent (optional)
        
    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    # Format context from retrieved data
    # CRITICAL ASSERTION: If total_rows > 0, baseline_rows must not be empty
    if total_rows > 0 and len(baseline_rows) == 0 and len(semantic_rows) == 0:
        print(f"[WARNING] total_rows={total_rows} but both baseline_rows and semantic_rows are empty!")
    
    context = format_context(baseline_rows, semantic_rows, debug=False)
    
    # Add template-specific context hints for top-N queries
    template_context_note = ""
    list_templates = ["low_satisfaction_journeys", "high_satisfaction_journeys", "high_delay_journeys", 
                      "early_arrival_journeys", "high_delay_low_satisfaction_journeys", 
                      "delay_causes_for_route", "popular_routes_from_airport", "airports_most_connections"]
    
    # Special handling for city-based route queries (data limitation)
    if template_id == "best_route_by_city":
        origin_city = params.get("origin_city", "") if params else ""
        dest_city = params.get("dest_city", "") if params else ""
        template_context_note = f"\n\nIMPORTANT: This query is for routes between {origin_city} and {dest_city}, but the dataset doesn't contain explicit city-to-city route mapping. The results show sample journeys from the knowledge graph. Explain that these are example journeys (not necessarily the exact route requested) and summarize their characteristics (number of legs, delays, satisfaction)."
    
    if template_id in list_templates:
        if num_baseline_rows > 0:
            if template_id == "low_satisfaction_journeys":
                template_context_note = f"\n\nIMPORTANT: These are the BOTTOM {num_baseline_rows} journeys by satisfaction score. SUMMARIZE the top 5-10 with key insights (journey IDs, satisfaction scores, delays). Do NOT list all {num_baseline_rows} raw."
            elif template_id == "high_satisfaction_journeys":
                template_context_note = f"\n\nIMPORTANT: These are the TOP {num_baseline_rows} journeys by satisfaction score. SUMMARIZE the top 5-10 with key insights (journey IDs, satisfaction scores, delays). Do NOT list all {num_baseline_rows} raw."
            elif template_id == "high_delay_journeys":
                template_context_note = f"\n\nIMPORTANT: These are the TOP {num_baseline_rows} journeys by delay. SUMMARIZE the top 5-10 with key insights (journey IDs, delay minutes, satisfaction scores). Do NOT list all {num_baseline_rows} raw."
            elif template_id == "early_arrival_journeys":
                template_context_note = f"\n\nIMPORTANT: These are {num_baseline_rows} journeys that arrived early. SUMMARIZE key patterns (journey IDs, delay patterns, satisfaction). Do NOT list all {num_baseline_rows} raw."
            elif template_id == "delay_causes_for_route":
                template_context_note = f"\n\nIMPORTANT: These are {num_baseline_rows} delayed journeys for a specific route. ANALYZE delay patterns (average delay, range, journey IDs). If origin_code/dest_code are present in results, the route IS known - use them."
            elif template_id == "popular_routes_from_airport":
                template_context_note = f"\n\nIMPORTANT: These are {num_baseline_rows} popular destination routes from an airport. SUMMARIZE top 5-10 destinations with flight counts. Do NOT list all {num_baseline_rows} raw."
            elif template_id == "airports_most_connections":
                template_context_note = f"\n\nIMPORTANT: These are {num_baseline_rows} airports with most connections. SUMMARIZE top 5-10 airports with connection counts. Do NOT list all {num_baseline_rows} raw."
    
    # Check for route fields in results
    route_fields_note = ""
    if baseline_rows:
        first_row = baseline_rows[0]
        has_route_fields = ("origin_code" in first_row or "dest_code" in first_row) and \
                          ("origin_code" in first_row and "dest_code" in first_row)
        if has_route_fields:
            route_fields_note = "\n\nIMPORTANT: The results contain origin_code and dest_code fields. The route IS known - use these codes in your analysis. Do NOT say 'route information not available' or 'origin/destination not in dataset'."
    
    # Check if this is a city→airport query that returned 0 rows
    city_airport_note = ""
    if intent == "AIRPORT_INFO" and len(baseline_rows) == 0:
        city_airport_note = "\n\nIMPORTANT: This query was for airport information by city name. If 0 results were returned, clearly state that the city's airport is not found in the dataset (e.g., 'Airport CAI (Cairo) not found in the dataset'). Do NOT return information about a different airport."
    
    # Build evidence summary (list of fields available in the data)
    evidence_fields = set()
    for row in baseline_rows[:5]:  # Check first 5 rows
        evidence_fields.update(row.keys())
    for row in semantic_rows[:5]:
        evidence_fields.update(row.keys())
    # Remove internal metadata fields
    evidence_fields = {f for f in evidence_fields if not f.startswith("_")}
    evidence_summary = ", ".join(sorted(evidence_fields)) if evidence_fields else "none"
    
    # Check if this is a FLIGHT_STATUS query with only fleet info (no real-time status)
    status_limitation_note = ""
    if intent == "FLIGHT_STATUS" and baseline_rows:
        # Check if baseline only has fleet_type_description (no status, departure_time, arrival_time)
        has_only_fleet_info = all(
            "fleet_type_description" in row and 
            "status" not in row and 
            "departure_time" not in row and 
            "arrival_time" not in row
            for row in baseline_rows
        )
        if has_only_fleet_info:
            status_limitation_note = """

CRITICAL FOR FLIGHT STATUS QUERIES:
The dataset only contains fleet information (aircraft type) for flights, NOT real-time operational status.
- The context does NOT contain: current status (departed/arrived/delayed/cancelled), departure times, arrival times, or gate information
- You MUST explicitly state that real-time flight status is not available in the dataset
- You can only provide: aircraft type (fleet_type_description) and any historical journey performance data if available
- ABSOLUTELY DO NOT suggest checking flight tracking systems, external systems, or any other systems
- ABSOLUTELY DO NOT suggest checking internal flight operations systems or any other systems
- You are analyzing the knowledge graph data ONLY - if the data isn't there, simply state what IS available (aircraft type)
- Do NOT provide recommendations to check other systems - just state what data is available from the knowledge graph
"""
    
    # Persona: Define the assistant's role (AIRLINE COMPANY PERSPECTIVE)
    persona = """You are an airline operations analyst assistant. Your role is to help airline company staff gain insights about flight performance, passenger satisfaction, delays, and service quality from the airline's knowledge graph data. You provide operational insights, identify problems (poorly rated flights, delays), and help the airline improve operations. You analyze data from the AIRLINE COMPANY'S perspective, not the passenger's perspective."""
    
    # Task: Clear instructions (AIRLINE COMPANY FOCUS)
    task = """Your task is to provide operational insights and analysis from the airline company's perspective using the data in the context below.

CRITICAL RULES:
1. NEVER say the knowledge graph is "empty" or "appears to be empty" - if you have 0 results, say "No records found for [specific query] in the current dataset"
2. NEVER make external benchmarking claims (e.g., "industry average", "unacceptable standards", "needs immediate attention", "compensation") - these are NOT in the data
3. NEVER make causal claims without evidence (e.g., "systemic catering problem", "when delays occur food collapses") - instead say "In this sample, low food scores co-occur with high delays"
4. ALWAYS include an "Evidence" section listing the exact fields you used from the data
5. ALWAYS state the exact number of results (e.g., "Top 10 of 20 results" if showing 10 of 20)
6. BE CONCISE: Keep responses under 200 words unless detailed analysis is explicitly requested. Summarize list results instead of listing all items.
7. For list templates (journeys, routes, airports): Summarize top 5-10 items with key insights. Do NOT dump raw lists.

Guidelines (AIRLINE COMPANY PERSPECTIVE):
- Focus on OPERATIONAL INSIGHTS: delays, passenger satisfaction, service quality, performance metrics
- Identify PROBLEMS: poorly rated flights, high delays, low satisfaction scores (relative to THIS dataset, not external benchmarks)
- Provide ACTIONABLE INSIGHTS: which flights/journeys need attention, what patterns exist
- Analyze PERFORMANCE METRICS: arrival delays (negative = early, positive = late), food satisfaction scores (1-5 scale)
- For flight status queries: Use journey data to provide insights about that flight's performance (delays, satisfaction, passenger feedback)
- For route queries: Analyze journey data to identify best/worst performing routes based on delays and satisfaction
- For satisfaction queries: Identify patterns, poorly rated journeys, areas for improvement
- Cite specific values: feedback_IDs, delay minutes, satisfaction scores, passenger classes
- Summarize patterns: average delays, satisfaction trends, performance comparisons (WITHIN THIS DATASET)
- Use relative language: "low compared to other journeys in this dataset", "high relative to this dataset"
- NEVER suggest checking flight tracking systems, external systems, or any other systems
- NEVER suggest checking internal flight operations systems or any other systems
- You analyze ONLY the knowledge graph data - if data isn't available, simply state what IS available
- Use journey data creatively: if asked about flights but you have journeys, analyze the journey data for that flight
- For FLIGHT_STATUS with only fleet info: State what's available (aircraft type) and that real-time status is not in the dataset - do NOT suggest checking other systems

REQUIRED OUTPUT FORMAT:
1. Answer the question using the data provided
2. Include an "Evidence" section at the end listing the exact field names you used (e.g., "Evidence: Used fields: flight_number, aircraft_type, journeys_count, avg_delay, avg_food_score")
3. State the number of results: "Based on {total_rows} results" or "Top {shown} of {total} results" if showing subset"""
    
    # Combine into system prompt
    system_prompt = f"""{persona}

{task}
{status_limitation_note}

IMPORTANT: You are analyzing data for AIRLINE COMPANY STAFF. Focus on operational insights, performance metrics, and identifying areas for improvement. Use the journey data (delays, satisfaction scores, passenger feedback) to provide actionable insights.

Context from Knowledge Graph:
{context}
{template_context_note}
{route_fields_note}
{city_airport_note}

Available Data Fields (Evidence): {evidence_summary}
Total Results: {total_rows} (Baseline: {num_baseline_rows}, Semantic: {len(semantic_rows)})

Remember: 
- Analyze from the AIRLINE COMPANY'S perspective (not passengers)
- Focus on INSIGHTS: delays, satisfaction, performance problems (relative to THIS dataset)
- Identify POORLY RATED flights/journeys that need attention (within this dataset)
- Provide ACTIONABLE recommendations based on the data
- Use journey data to infer flight/route performance even if not a perfect match
- For FLIGHT_STATUS: If only fleet_type_description is available, explicitly state that real-time status (departed/arrived/delayed/cancelled) is not in the dataset
- NEVER say the knowledge graph is empty - if no results, say "No records found for [query] in the current dataset"
- Include an "Evidence" section listing the exact fields you used from the data"""
    
    # User prompt is the question
    user_prompt = question
    
    return system_prompt, user_prompt


def build_simple_prompt(
    question: str,
    baseline_rows: List[Dict[str, Any]],
    semantic_rows: List[Dict[str, Any]]
) -> str:
    """
    Build a simple single-prompt format (for models that don't support system prompts).
    
    Args:
        question: User's question
        baseline_rows: Results from baseline retrieval
        semantic_rows: Results from semantic retrieval
        
    Returns:
        Complete prompt string
    """
    context = format_context(baseline_rows, semantic_rows)
    
    prompt = f"""You are a helpful airline information assistant. Answer the user's question using ONLY the information provided below.

Context from Knowledge Graph:
{context}

Question: {question}

Answer:"""
    
    return prompt
