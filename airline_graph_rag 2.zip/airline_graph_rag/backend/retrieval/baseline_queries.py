"""
Baseline retrieval layer using hand-written Cypher templates for airline GraphRAG.

This module provides a rule-based retrieval system that matches user intents and
extracted entities to predefined Cypher query templates.
"""

from dataclasses import dataclass
from typing import Optional

from ..neo4j_client import Neo4jClient
from ..preprocessing.intent_classifier import Intent, IntentResult
from ..preprocessing.entity_extractor import Entity, EntityType


@dataclass
class QueryTemplate:
    """Represents a Cypher query template for a specific intent and entity combination."""
    
    id: str
    description: str
    intent: Intent
    required_entity_types: list[EntityType]
    cypher: str
    # Optional default parameters for this template.
    # These will be merged into the runtime params before executing Cypher.
    default_params: dict | None = None


# Baseline query templates for different intents and entity combinations
BASELINE_TEMPLATES: dict[str, QueryTemplate] = {
    "flight_status_by_number": QueryTemplate(
        id="flight_status_by_number",
        description="Get flight status by flight number with journey performance data",
        intent=Intent.FLIGHT_STATUS,
        required_entity_types=[EntityType.FLIGHT_NUMBER],
        cypher="""
        MATCH (f:Flight {flight_number: $flight_number})
        OPTIONAL MATCH (j:Journey)-[:ON]->(f)
        WITH f,
             COUNT(j) AS journeys,
             ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
             ROUND(AVG(j.food_satisfaction_score), 2) AS avg_food_satisfaction,
             COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_journeys
        RETURN
            f.flight_number AS flight_number,
            f.fleet_type_description AS fleet_type_description,
            journeys AS journey_count,
            avg_delay AS avg_delay_minutes,
            avg_food_satisfaction AS avg_food_satisfaction,
            delayed_journeys AS delayed_journey_count
        LIMIT 10
        """
    ),
    
    "flight_status_by_route": QueryTemplate(
        id="flight_status_by_route",
        description="Get flight status for flights between two airports",
        intent=Intent.FLIGHT_STATUS,
        required_entity_types=[EntityType.AIRPORT_CODE, EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (origin:Airport {station_code: $origin_code})
        MATCH (dest:Airport {station_code: $dest_code})
        MATCH (f:Flight)-[:DEPARTS_FROM]->(origin)
        WHERE (f)-[:ARRIVES_AT]->(dest)
        RETURN f.flight_number AS flight_number,
               f.fleet_type_description AS fleet_type_description,
               origin.station_code AS origin_code,
               dest.station_code AS dest_code
        ORDER BY f.flight_number ASC
        LIMIT 20
        """
    ),
    
    "best_route_by_city": QueryTemplate(
        id="best_route_by_city",
        description="Find best routes between two cities sorted by duration",
        intent=Intent.BEST_ROUTE,
        required_entity_types=[EntityType.CITY, EntityType.CITY],
        cypher="""
        // NOTE: origin_city and dest_city are not used because
        // the dataset doesn't contain city / route information.
        MATCH (j:Journey)
        WITH j
        RETURN
            j.feedback_ID AS journey_id,
            j.number_of_legs AS number_of_legs,
            j.passenger_class AS passenger_class,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.arrival_delay_minutes ASC
        LIMIT 3
        """
    ),
    
    "airline_basic_info": QueryTemplate(
        id="airline_basic_info",
        description="Get basic information about an airline",
        intent=Intent.AIRLINE_INFO,
        required_entity_types=[EntityType.AIRLINE],
        cypher="""
        // We don't have actual Airline nodes; instead we aggregate
        // over all journeys and just echo back the requested name.
        MATCH (j:Journey)
        RETURN
            $airline_name AS airline_name,
            COUNT(j) AS total_flights,
            ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_arrival_delay_minutes,
            ROUND(AVG(j.food_satisfaction_score), 2) AS avg_food_satisfaction_score
        """
    ),
    
    "airport_basic_info": QueryTemplate(
        id="airport_basic_info",
        description="Get basic information about an airport by code",
        intent=Intent.AIRPORT_INFO,
        required_entity_types=[EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (a:Airport {station_code: $airport_code})
        OPTIONAL MATCH (departing:Flight)-[:DEPARTS_FROM]->(a)
        OPTIONAL MATCH (arriving:Flight)-[:ARRIVES_AT]->(a)
        WITH a,
             COUNT(DISTINCT departing) AS departing_flights,
             COUNT(DISTINCT arriving) AS arriving_flights,
             COUNT(DISTINCT departing) + COUNT(DISTINCT arriving) AS total_flights
        RETURN a.station_code AS airport_code,
               departing_flights AS departing_flights,
               arriving_flights AS arriving_flights,
               total_flights AS total_flights
        """
    ),
    
    "airport_info_by_city": QueryTemplate(
        id="airport_info_by_city",
        description="Get airport information by city name (uses city→airport mapping)",
        intent=Intent.AIRPORT_INFO,
        required_entity_types=[EntityType.CITY],
        cypher="""
        // Map city name to airport code, then query airport
        // If airport doesn't exist, returns 0 rows (correct behavior)
        MATCH (a:Airport {station_code: $airport_code})
        OPTIONAL MATCH (departing:Flight)-[:DEPARTS_FROM]->(a)
        OPTIONAL MATCH (arriving:Flight)-[:ARRIVES_AT]->(a)
        WITH a,
             COUNT(DISTINCT departing) AS departing_flights,
             COUNT(DISTINCT arriving) AS arriving_flights,
             COUNT(DISTINCT departing) + COUNT(DISTINCT arriving) AS total_flights
        RETURN a.station_code AS airport_code,
               departing_flights AS departing_flights,
               arriving_flights AS arriving_flights,
               total_flights AS total_flights
        """
    ),
    
    "airports_most_connections": QueryTemplate(
        id="airports_most_connections",
        description="Find airports with the most flight connections (incoming + outgoing)",
        intent=Intent.AIRPORT_INFO,
        required_entity_types=[],
        cypher="""
        MATCH (a:Airport)
        OPTIONAL MATCH (departing:Flight)-[:DEPARTS_FROM]->(a)
        OPTIONAL MATCH (arriving:Flight)-[:ARRIVES_AT]->(a)
        WITH a,
             COUNT(DISTINCT departing) AS departing_flights,
             COUNT(DISTINCT arriving) AS arriving_flights,
             COUNT(DISTINCT departing) + COUNT(DISTINCT arriving) AS total_connections
        WHERE total_connections > 0
        RETURN a.station_code AS airport_code,
               departing_flights AS outgoing_flights,
               arriving_flights AS incoming_flights,
               total_connections AS total_connections
        ORDER BY total_connections DESC
        LIMIT 10
        """
    ),
    
    "delay_causes_for_route": QueryTemplate(
        id="delay_causes_for_route",
        description="Analyze delays for journeys on a specific route (Journey -> Flight -> Airports)",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[EntityType.AIRPORT_CODE, EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (o:Airport {station_code: $origin_code})
        MATCH (d:Airport {station_code: $dest_code})
        MATCH (j:Journey)-[:ON]->(f:Flight)-[:DEPARTS_FROM]->(o)
        WHERE (f)-[:ARRIVES_AT]->(d)
          AND j.arrival_delay_minutes IS NOT NULL
          AND j.arrival_delay_minutes > 0
        RETURN
          j.feedback_ID AS journey_id,
          j.arrival_delay_minutes AS delay_minutes,
          j.number_of_legs AS number_of_legs,
          j.passenger_class AS passenger_class
        ORDER BY delay_minutes DESC
        LIMIT 20
        """
    ),
    
    "delay_by_flight_number": QueryTemplate(
        id="delay_by_flight_number",
        description="Get delay information for journeys on a specific flight number",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[EntityType.FLIGHT_NUMBER],
        cypher="""
        MATCH (f:Flight {flight_number: $flight_number})
        MATCH (j:Journey)-[:ON]->(f)
        WHERE j.arrival_delay_minutes IS NOT NULL
        RETURN
          f.flight_number AS flight_number,
          COUNT(j) AS journey_count,
          ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay_minutes,
          ROUND(AVG(CASE WHEN j.arrival_delay_minutes > 0 THEN j.arrival_delay_minutes END), 2) AS avg_positive_delay,
          MAX(j.arrival_delay_minutes) AS max_delay_minutes,
          COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_journeys,
          COUNT(CASE WHEN j.arrival_delay_minutes < 0 THEN 1 END) AS early_journeys
        LIMIT 1
        """
    ),
    
    "passenger_satisfaction_for_airline": QueryTemplate(
        id="passenger_satisfaction_for_airline",
        description="Compute passenger satisfaction metrics for an airline",
        intent=Intent.PASSENGER_SATISFACTION,
        required_entity_types=[EntityType.AIRLINE],
        cypher="""
        // We don't have actual Airline nodes; aggregate over all journeys
        // and provide satisfaction metrics
        MATCH (j:Journey)
        WHERE j.food_satisfaction_score IS NOT NULL
        WITH COUNT(j) AS total_journeys,
             ROUND(AVG(j.food_satisfaction_score), 2) AS avg_satisfaction,
             COUNT(CASE WHEN j.food_satisfaction_score >= 4 THEN 1 END) AS satisfied_journeys,
             COUNT(CASE WHEN j.food_satisfaction_score < 3 THEN 1 END) AS unsatisfied_journeys
        RETURN $airline_name AS airline_name,
               total_journeys AS total_journeys,
               avg_satisfaction AS avg_satisfaction_score,
               satisfied_journeys AS satisfied_journeys,
               unsatisfied_journeys AS unsatisfied_journeys,
               CASE
                 WHEN total_journeys = 0 THEN 0
                 ELSE ROUND(100.0 * satisfied_journeys / total_journeys, 2)
               END AS satisfaction_percentage
        """
    ),
    
    "low_satisfaction_journeys": QueryTemplate(
        id="low_satisfaction_journeys",
        description="Find journeys with low satisfaction scores (poorly rated flights)",
        intent=Intent.PASSENGER_SATISFACTION,
        required_entity_types=[],
        cypher="""
        // Find journeys with low food satisfaction scores (poorly rated)
        // This helps identify flights/journeys that need attention
        MATCH (j:Journey)
        WHERE j.food_satisfaction_score IS NOT NULL AND j.food_satisfaction_score <= 2
        RETURN
            j.feedback_ID AS journey_id,
            j.passenger_class AS passenger_class,
            j.number_of_legs AS number_of_legs,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.food_satisfaction_score ASC, j.arrival_delay_minutes DESC
        LIMIT COALESCE($limit, 20)
        """,
        default_params={"max_food_score": 2, "limit": 20}
    ),
    
    "high_satisfaction_journeys": QueryTemplate(
        id="high_satisfaction_journeys",
        description="Find journeys with high satisfaction scores (well-rated flights)",
        intent=Intent.PASSENGER_SATISFACTION,
        required_entity_types=[],
        cypher="""
        // Find journeys with high food satisfaction scores (well-rated)
        // This helps identify successful flights/journeys
        MATCH (j:Journey)
        WHERE j.food_satisfaction_score IS NOT NULL AND j.food_satisfaction_score >= 4
        RETURN
            j.feedback_ID AS journey_id,
            j.passenger_class AS passenger_class,
            j.number_of_legs AS number_of_legs,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.food_satisfaction_score DESC, j.arrival_delay_minutes ASC
        LIMIT 20
        """
    ),
    
    "satisfaction_by_flight_number": QueryTemplate(
        id="satisfaction_by_flight_number",
        description="Get satisfaction metrics for journeys on a specific flight number",
        intent=Intent.PASSENGER_SATISFACTION,
        required_entity_types=[EntityType.FLIGHT_NUMBER],
        cypher="""
        MATCH (f:Flight {flight_number: $flight_number})
        MATCH (j:Journey)-[:ON]->(f)
        WHERE j.food_satisfaction_score IS NOT NULL
        RETURN
          f.flight_number AS flight_number,
          count(j) AS journey_count,
          round(avg(j.food_satisfaction_score), 2) AS avg_food_satisfaction,
          count(CASE WHEN j.food_satisfaction_score <= 2 THEN 1 END) AS low_satisfaction_journeys
        LIMIT 1
        """
    ),
    
    "high_delay_journeys": QueryTemplate(
        id="high_delay_journeys",
        description="Find journeys with significant arrival delays",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[],
        cypher="""
        // Find journeys with high arrival delays (positive delays = late arrivals)
        // Negative delays mean early arrivals, so we filter for positive delays
        MATCH (j:Journey)
        WHERE j.arrival_delay_minutes IS NOT NULL 
          AND j.arrival_delay_minutes > COALESCE($min_delay, 0)
        RETURN
            j.feedback_ID AS journey_id,
            j.passenger_class AS passenger_class,
            j.number_of_legs AS number_of_legs,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.arrival_delay_minutes DESC
        LIMIT COALESCE($limit, 20)
        """,
        default_params={"min_delay": 15, "limit": 20}
    ),
    
    "high_delay_low_satisfaction_journeys": QueryTemplate(
        id="high_delay_low_satisfaction_journeys",
        description="Find journeys with both high delays AND low food satisfaction (intersection query)",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[],
        cypher="""
        // Find journeys that satisfy BOTH conditions:
        // 1. High arrival delays (positive delays = late arrivals)
        // 2. Low food satisfaction (score <= 2)
        MATCH (j:Journey)
        WHERE j.arrival_delay_minutes IS NOT NULL 
          AND j.arrival_delay_minutes > COALESCE($min_delay, 0)
          AND j.food_satisfaction_score IS NOT NULL
          AND j.food_satisfaction_score <= COALESCE($max_food_score, 2)
        RETURN
            j.feedback_ID AS journey_id,
            j.passenger_class AS passenger_class,
            j.number_of_legs AS number_of_legs,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.arrival_delay_minutes DESC, j.food_satisfaction_score ASC
        LIMIT COALESCE($limit, 20)
        """,
        default_params={"min_delay": 60, "max_food_score": 2, "limit": 20}
    ),

    "early_arrival_journeys": QueryTemplate(
        id="early_arrival_journeys",
        description="Find journeys that arrived early (negative delays)",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[],
        cypher="""
        // Find journeys with negative arrival delays (arrived earlier than scheduled)
        MATCH (j:Journey)
        WHERE j.arrival_delay_minutes IS NOT NULL 
          AND j.arrival_delay_minutes < COALESCE($max_delay, 0)
        RETURN
            j.feedback_ID AS journey_id,
            j.passenger_class AS passenger_class,
            j.number_of_legs AS number_of_legs,
            j.actual_flown_miles AS distance_miles,
            j.arrival_delay_minutes AS arrival_delay_minutes,
            j.food_satisfaction_score AS food_satisfaction_score
        ORDER BY j.arrival_delay_minutes ASC
        LIMIT COALESCE($limit, 20)
        """,
        default_params={"max_delay": -1, "limit": 20}
    ),
    
    "average_delays_by_route": QueryTemplate(
        id="average_delays_by_route",
        description="Calculate average delays for different route patterns",
        intent=Intent.DELAY_CAUSES,
        required_entity_types=[],
        cypher="""
        // Analyze delay patterns by grouping journeys
        // Since we don't have explicit routes, we group by number_of_legs and distance ranges
        MATCH (j:Journey)
        WHERE j.arrival_delay_minutes IS NOT NULL
        WITH 
            j.number_of_legs AS route_legs,
            CASE 
                WHEN j.actual_flown_miles < 1000 THEN 'Short-haul'
                WHEN j.actual_flown_miles < 3000 THEN 'Medium-haul'
                ELSE 'Long-haul'
            END AS route_type,
            j.arrival_delay_minutes AS delay
        WITH route_legs, route_type,
             COUNT(*) AS journey_count,
             ROUND(AVG(delay), 2) AS avg_delay,
             ROUND(AVG(CASE WHEN delay > 0 THEN delay END), 2) AS avg_positive_delay,
             COUNT(CASE WHEN delay > 0 THEN 1 END) AS delayed_journeys
        RETURN route_legs AS number_of_legs,
               route_type AS route_category,
               journey_count AS total_journeys,
               avg_delay AS avg_delay_minutes,
               avg_positive_delay AS avg_late_arrival_minutes,
               delayed_journeys AS delayed_count,
               ROUND(100.0 * delayed_journeys / journey_count, 2) AS delay_percentage
        ORDER BY avg_delay DESC
        LIMIT 10
        """
    ),
    
    "general_flights_from_city": QueryTemplate(
        id="general_flights_from_city",
        description="List flights departing from a city (general query)",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[EntityType.CITY],
        cypher="""
        // Our airports don't have a city field; just return a sample of flights.
        MATCH (f:Flight)
        RETURN
            f.flight_number AS flight_number,
            f.fleet_type_description AS fleet_type_description
        ORDER BY f.flight_number
        LIMIT 20
        """
    ),
    
    "general_flights_to_city": QueryTemplate(
        id="general_flights_to_city",
        description="List flights arriving to a city (simplified - airports don't have city property)",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[EntityType.CITY],
        cypher="""
        // Note: Airports don't have city property in our schema
        // Return a sample of flights with arrival airports
        MATCH (f:Flight)-[:ARRIVES_AT]->(a:Airport)
        OPTIONAL MATCH (f)-[:DEPARTS_FROM]->(origin:Airport)
        RETURN f.flight_number AS flight_number,
               f.fleet_type_description AS fleet_type_description,
               origin.station_code AS origin_code,
               a.station_code AS dest_code
        ORDER BY f.flight_number ASC
        LIMIT 20
        """
    ),
    
    "popular_routes_from_airport": QueryTemplate(
        id="popular_routes_from_airport",
        description="Find most popular destination airports from a given airport",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (origin:Airport {station_code: $airport_code})
        MATCH (f:Flight)-[:DEPARTS_FROM]->(origin)
        MATCH (f)-[:ARRIVES_AT]->(dest:Airport)
        WITH dest, COUNT(*) AS route_frequency
        RETURN dest.station_code AS destination_code,
               route_frequency AS flight_count
        ORDER BY route_frequency DESC
        LIMIT 10
        """
    ),
    
    "best_route_by_airport_codes": QueryTemplate(
        id="best_route_by_airport_codes",
        description="Find best routes between two airports by codes",
        intent=Intent.BEST_ROUTE,
        required_entity_types=[EntityType.AIRPORT_CODE, EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (origin:Airport {station_code: $origin_code})
        MATCH (dest:Airport {station_code: $dest_code})
        MATCH (f:Flight)-[:DEPARTS_FROM]->(origin)
        WHERE (f)-[:ARRIVES_AT]->(dest)
        RETURN f.flight_number AS flight_number,
               f.fleet_type_description AS aircraft_type,
               origin.station_code AS origin_code,
               dest.station_code AS dest_code
        ORDER BY f.flight_number ASC
        LIMIT 3
        """
    ),
    
    "route_performance_by_airport_codes": QueryTemplate(
        id="route_performance_by_airport_codes",
        description="Get performance metrics (delays, satisfaction) for a specific route",
        intent=Intent.BEST_ROUTE,
        required_entity_types=[EntityType.AIRPORT_CODE, EntityType.AIRPORT_CODE],
        cypher="""
        MATCH (origin:Airport {station_code: $origin_code})
        MATCH (dest:Airport {station_code: $dest_code})
        MATCH (f:Flight)-[:DEPARTS_FROM]->(origin)
        WHERE (f)-[:ARRIVES_AT]->(dest)
        MATCH (j:Journey)-[:ON]->(f)
        WITH origin, dest, f,
             COUNT(j) AS journey_count,
             ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
             ROUND(AVG(j.food_satisfaction_score), 2) AS avg_food_satisfaction,
             COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_journey_count
        RETURN DISTINCT
            origin.station_code AS origin_code,
            dest.station_code AS dest_code,
            f.flight_number AS flight_number,
            f.fleet_type_description AS aircraft_type,
            journey_count AS journey_count,
            avg_delay AS avg_delay_minutes,
            avg_food_satisfaction AS avg_food_satisfaction,
            delayed_journey_count AS delayed_journey_count
        ORDER BY avg_delay ASC, avg_food_satisfaction DESC
        LIMIT 20
        """
    ),
    
    "journey_statistics": QueryTemplate(
        id="journey_statistics",
        description="Get overall journey statistics",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[],
        cypher="""
        MATCH (j:Journey)
        RETURN 
            COUNT(j) AS total_journeys,
            ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_arrival_delay,
            ROUND(AVG(j.food_satisfaction_score), 2) AS avg_food_satisfaction,
            COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_journeys,
            COUNT(CASE WHEN j.food_satisfaction_score <= 2 THEN 1 END) AS low_satisfaction_journeys
        """
    ),
    
    "journey_patterns": QueryTemplate(
        id="journey_patterns",
        description="Get journey patterns by legs and passenger class",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[],
        cypher="""
        MATCH (j:Journey)
        WHERE j.number_of_legs IS NOT NULL AND j.passenger_class IS NOT NULL
        RETURN 
            j.number_of_legs AS legs,
            j.passenger_class AS passenger_class,
            COUNT(*) AS journeys,
            ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
            ROUND(AVG(j.food_satisfaction_score), 2) AS avg_satisfaction
        ORDER BY journeys DESC
        LIMIT 25
        """
    ),
    
    "journey_leg_patterns": QueryTemplate(
        id="journey_leg_patterns",
        description="Analyze journey distribution by number of legs",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[],
        cypher="""
        MATCH (j:Journey)
        WHERE j.number_of_legs IS NOT NULL
        WITH COUNT(j) AS total_journeys
        MATCH (j:Journey)
        WHERE j.number_of_legs IS NOT NULL
        WITH total_journeys,
             j.number_of_legs AS number_of_legs,
             COUNT(*) AS journey_count,
             ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
             ROUND(AVG(j.food_satisfaction_score), 2) AS avg_satisfaction,
             ROUND(AVG(j.actual_flown_miles), 2) AS avg_distance
        WITH total_journeys, number_of_legs, journey_count, avg_delay, avg_satisfaction, avg_distance
        RETURN number_of_legs,
               journey_count,
               COALESCE(avg_delay, 0) AS avg_delay,
               COALESCE(avg_satisfaction, 0) AS avg_satisfaction,
               COALESCE(avg_distance, 0) AS avg_distance,
               CASE 
                   WHEN total_journeys > 0 THEN ROUND(100.0 * journey_count / total_journeys, 2)
                   ELSE 0
               END AS percentage
        ORDER BY number_of_legs ASC
        """
    ),
    
    "operational_insights": QueryTemplate(
        id="operational_insights",
        description="Get key operational insights and metrics",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[],
        cypher="""
        OPTIONAL MATCH (j:Journey)
        WITH COUNT(j) AS total_journeys,
             ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
             ROUND(AVG(j.food_satisfaction_score), 2) AS avg_satisfaction,
             COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_count,
             COUNT(CASE WHEN j.food_satisfaction_score <= 2 THEN 1 END) AS low_satisfaction_count,
             ROUND(percentileCont(j.arrival_delay_minutes, 0.9), 2) AS p90_delay
        OPTIONAL MATCH (f:Flight)
        WITH total_journeys, avg_delay, avg_satisfaction, delayed_count, low_satisfaction_count, p90_delay,
             COUNT(DISTINCT f) AS total_flights
        OPTIONAL MATCH (a:Airport)
        WITH total_journeys, avg_delay, avg_satisfaction, delayed_count, low_satisfaction_count, p90_delay, total_flights,
             COUNT(DISTINCT a) AS total_airports
        RETURN 
            COALESCE(total_journeys, 0) AS total_journeys,
            COALESCE(total_flights, 0) AS total_flights,
            COALESCE(total_airports, 0) AS total_airports,
            COALESCE(avg_delay, 0) AS avg_arrival_delay_minutes,
            COALESCE(p90_delay, 0) AS p90_arrival_delay_minutes,
            COALESCE(avg_satisfaction, 0) AS avg_food_satisfaction,
            COALESCE(delayed_count, 0) AS delayed_journeys,
            COALESCE(low_satisfaction_count, 0) AS low_satisfaction_journeys,
            CASE 
                WHEN total_journeys > 0 THEN ROUND(100.0 * delayed_count / total_journeys, 2)
                ELSE 0
            END AS delay_percentage,
            CASE 
                WHEN total_journeys > 0 THEN ROUND(100.0 * low_satisfaction_count / total_journeys, 2)
                ELSE 0
            END AS low_satisfaction_percentage
        """
    ),
    
    "analyze_passenger_journeys": QueryTemplate(
        id="analyze_passenger_journeys",
        description="Analyze passenger journeys by route",
        intent=Intent.GENERAL_KG_QUERY,
        required_entity_types=[],
        cypher="""
        MATCH (j:Journey)-[:ON]->(f:Flight)
        MATCH (f)-[:DEPARTS_FROM]->(o:Airport)
        MATCH (f)-[:ARRIVES_AT]->(d:Airport)
        RETURN 
            o.station_code AS origin,
            d.station_code AS dest,
            COUNT(*) AS journeys,
            ROUND(AVG(j.arrival_delay_minutes), 2) AS avg_delay,
            ROUND(AVG(j.food_satisfaction_score), 2) AS avg_food
        ORDER BY journeys DESC
        LIMIT 25
        """
    ),
    
    "overall_airline_performance": QueryTemplate(
        id="overall_airline_performance",
        description="Get overall airline performance metrics",
        intent=Intent.AIRLINE_INFO,
        required_entity_types=[],
        cypher="""
        MATCH (j:Journey)
        WITH 
            COUNT(j) AS journeys,
            AVG(j.arrival_delay_minutes) AS avg_delay,
            PERCENTILECONT(j.arrival_delay_minutes, 0.9) AS p90_delay,
            AVG(j.food_satisfaction_score) AS avg_food,
            COUNT(CASE WHEN j.arrival_delay_minutes > 0 THEN 1 END) AS delayed_count,
            COUNT(CASE WHEN j.food_satisfaction_score <= 2 THEN 1 END) AS low_satisfaction_count
        RETURN 
            journeys AS total_journeys,
            ROUND(avg_delay, 2) AS avg_delay_minutes,
            ROUND(p90_delay, 2) AS p90_delay_minutes,
            ROUND(avg_food, 2) AS avg_food_satisfaction,
            delayed_count AS delayed_journeys,
            low_satisfaction_count AS low_satisfaction_journeys
        """
    ),
    
    "safe_flight_status_by_route": QueryTemplate(
        id="safe_flight_status_by_route",
        description="Route lookup (safe): returns found flags + direct flight count + sample flight list",
        intent=Intent.FLIGHT_STATUS,
        required_entity_types=[EntityType.AIRPORT_CODE, EntityType.AIRPORT_CODE],
        cypher="""
        WITH $origin_code AS origin_code, $dest_code AS dest_code
        OPTIONAL MATCH (o:Airport {station_code: origin_code})
        OPTIONAL MATCH (d:Airport {station_code: dest_code})
        OPTIONAL MATCH (f:Flight)-[:DEPARTS_FROM]->(o)
        WHERE (f)-[:ARRIVES_AT]->(d)
        WITH origin_code, dest_code, o, d,
             collect(CASE
               WHEN f IS NULL THEN NULL
               ELSE {flight_number: f.flight_number, fleet_type_description: f.fleet_type_description}
             END) AS flights_raw
        WITH origin_code, dest_code, o, d,
             [x IN flights_raw WHERE x IS NOT NULL] AS flights
        RETURN
          origin_code AS origin_code,
          dest_code AS dest_code,
          (o IS NOT NULL) AS origin_found,
          (d IS NOT NULL) AS dest_found,
          size(flights) AS direct_flights,
          flights[0..20] AS flights
        """
    ),
}


# City → Airport code mapping (common cities to IATA codes)
CITY_TO_AIRPORT_MAP = {
    "cairo": "CAI",
    "london": "LHR",
    "new york": "JFK",
    "dubai": "DXB",
    "paris": "CDG",
    "frankfurt": "FRA",
    "amsterdam": "AMS",
    "istanbul": "IST",
    "doha": "DOH",
    "abu dhabi": "AUH",
    "toronto": "YYZ",
    "singapore": "SIN",
    "hong kong": "HKG",
    "tokyo": "NRT",
    "sydney": "SYD",
    "los angeles": "LAX",
    "chicago": "ORD",
    "miami": "MIA",
    "berlin": "BER",
    "rome": "FCO",
    "madrid": "MAD",
    "barcelona": "BCN",
}


class BaselineRetriever:
    """
    Baseline retriever that uses hand-written Cypher templates to query the Neo4j graph.
    
    This class matches user intents and extracted entities to predefined query templates
    and executes them against the Neo4j database.
    """
    
    def __init__(self, client: Neo4jClient | None = None):
        """
        Initialize the baseline retriever.
        
        Args:
            client: Optional Neo4jClient instance. If None, a new client will be created.
        """
        self.client = client if client is not None else Neo4jClient()
    
    def select_template(
        self, 
        intent: Intent, 
        entities: list[Entity],
        question: str = ""
    ) -> tuple[QueryTemplate | None, dict]:
        """
        Select the best matching query template based on intent and entities.
        
        Args:
            intent: The classified intent from the user query.
            entities: List of extracted entities from the user query.
            question: Original user question (for keyword-based template selection).
            
        Returns:
            Tuple of (QueryTemplate or None, parameter dictionary).
            Returns (None, {}) if no suitable template is found.
        """
        # Group entities by type for easier lookup
        entity_map: dict[EntityType, list[Entity]] = {}
        for entity in entities:
            entity_map.setdefault(entity.type, []).append(entity)
        
        params: dict = {}
        template: QueryTemplate | None = None
        
        # FLIGHT_STATUS intent matching
        if intent == Intent.FLIGHT_STATUS:
            if EntityType.FLIGHT_NUMBER in entity_map:
                # Already normalized to string in pipeline
                flight_num = entity_map[EntityType.FLIGHT_NUMBER][0].text
                template = BASELINE_TEMPLATES.get("flight_status_by_number")
                params = {"flight_number": flight_num}
            elif len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                # Use the safe route template so we don't return empty on missing airports
                template = BASELINE_TEMPLATES.get("safe_flight_status_by_route")
                params = {
                    "origin_code": airport_codes[0].text,
                    "dest_code": airport_codes[1].text
                }
        
        # BEST_ROUTE intent matching
        elif intent == Intent.BEST_ROUTE:
            question_lower = question.lower()
            
            # KEYWORD-BASED OVERRIDE: Check for delay/satisfaction keywords first
            # Even if intent is BEST_ROUTE, if query mentions delays/satisfaction, use those templates
            delay_keywords = ["delay", "delayed", "late", "on time", "early", "negative delay", "delays"]
            satisfaction_keywords = ["satisfaction", "rating", "food score", "reviews", "rated"]
            
            has_delay_keywords = any(kw in question_lower for kw in delay_keywords)
            has_satisfaction_keywords = any(kw in question_lower for kw in satisfaction_keywords)
            
            # Override to DELAY_CAUSES if delay keywords present
            if has_delay_keywords and len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                template = BASELINE_TEMPLATES.get("delay_causes_for_route")
                params = {
                    "origin_code": airport_codes[0].text,
                    "dest_code": airport_codes[1].text
                }
            # Override to route_performance if asking for "best route" with performance context
            elif ("best" in question_lower or "performance" in question_lower) and len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                template = BASELINE_TEMPLATES.get("route_performance_by_airport_codes")
                params = {
                    "origin_code": airport_codes[0].text,
                    "dest_code": airport_codes[1].text
                }
            # Override to PASSENGER_SATISFACTION if satisfaction keywords present
            elif has_satisfaction_keywords and len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                # For route + satisfaction, use general satisfaction (no route-specific template yet)
                # Could add route_satisfaction template later
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                # For now, use low_satisfaction_journeys as fallback
                template = BASELINE_TEMPLATES.get("low_satisfaction_journeys")
                params = {}
            # Normal BEST_ROUTE handling
            # Try city-to-airport mapping first (preferred approach)
            elif len(entity_map.get(EntityType.CITY, [])) >= 2:
                cities = entity_map[EntityType.CITY]
                origin_city = cities[0].text.lower()
                dest_city = cities[1].text.lower()
                
                # Try to map cities to airport codes
                origin_code = CITY_TO_AIRPORT_MAP.get(origin_city)
                dest_code = CITY_TO_AIRPORT_MAP.get(dest_city)
                
                if origin_code and dest_code:
                    # Both cities mapped successfully - use airport codes template
                    template = BASELINE_TEMPLATES.get("best_route_by_airport_codes")
                    params = {
                        "origin_code": origin_code,
                        "dest_code": dest_code
                    }
                else:
                    # City mapping failed - return None to indicate cities not in dataset
                    # This will trigger a clear "not available" message instead of misleading sample data
                    template = None
                    params = {
                        "origin_city": cities[0].text,
                        "dest_city": cities[1].text,
                        "origin_code_mapped": origin_code,
                        "dest_code_mapped": dest_code
                    }
            elif len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                template = BASELINE_TEMPLATES.get("best_route_by_airport_codes")
                params = {
                    "origin_code": airport_codes[0].text,
                    "dest_code": airport_codes[1].text
                }
        
        # AIRLINE_INFO intent matching
        elif intent == Intent.AIRLINE_INFO:
            if EntityType.AIRLINE in entity_map:
                airline = entity_map[EntityType.AIRLINE][0].text
                template = BASELINE_TEMPLATES.get("airline_basic_info")
                params = {"airline_name": airline}
            else:
                # Default to overall airline performance
                template = BASELINE_TEMPLATES.get("overall_airline_performance")
                params = {}
        
        # AIRPORT_INFO intent matching
        elif intent == Intent.AIRPORT_INFO:
            question_lower = question.lower()
            # Check for explicit airport code entity first
            if EntityType.AIRPORT_CODE in entity_map:
                airport_code = entity_map[EntityType.AIRPORT_CODE][0].text
                template = BASELINE_TEMPLATES.get("airport_basic_info")
                params = {"airport_code": airport_code}
            elif EntityType.CITY in entity_map:
                city = entity_map[EntityType.CITY][0].text
                # Map city name to airport code
                city_lower = city.lower()
                airport_code = CITY_TO_AIRPORT_MAP.get(city_lower)
                if airport_code:
                    template = BASELINE_TEMPLATES.get("airport_info_by_city")
                    params = {"airport_code": airport_code}
                else:
                    # City not in mapping - return None template (will result in 0 rows)
                    template = BASELINE_TEMPLATES.get("airport_info_by_city")
                    params = {"airport_code": "UNKNOWN"}  # Will return 0 rows
            elif "most connections" in question_lower or "most connected" in question_lower or ("connections" in question_lower and "airport" in question_lower):
                # Query about airports with most connections (check before generic "connections")
                template = BASELINE_TEMPLATES.get("airports_most_connections")
                params = {}
            elif "connections" in question_lower:
                # Generic connections query
                template = BASELINE_TEMPLATES.get("airports_most_connections")
                params = {}
            else:
                # Default: airports with most connections
                template = BASELINE_TEMPLATES.get("airports_most_connections")
                params = {}
        
        # DELAY_CAUSES intent matching
        elif intent == Intent.DELAY_CAUSES:
            question_lower = question.lower()
            
            # Check for combined delay + satisfaction query
            has_delay_keywords = any(kw in question_lower for kw in ["delay", "delayed", "late", "delays"])
            has_satisfaction_keywords = any(kw in question_lower for kw in ["satisfaction", "food", "rating", "score", "low food"])
            # Extract numeric thresholds (e.g., "over 60 minutes", "over 120")
            import re
            delay_threshold = None
            m_delay = re.search(r"(?:over|above|more than)\s+(\d+)\s*(?:minutes|min)?", question_lower)
            if m_delay:
                delay_threshold = int(m_delay.group(1))
            
            # Priority 1: Combined delay + satisfaction (e.g., "high delay and low food satisfaction")
            if has_delay_keywords and has_satisfaction_keywords:
                template = BASELINE_TEMPLATES.get("high_delay_low_satisfaction_journeys")
                params = {}
                if delay_threshold is not None:
                    params["min_delay"] = delay_threshold
            # Priority 2: Flight number → delay_by_flight_number
            elif EntityType.FLIGHT_NUMBER in entity_map:
                flight_num = entity_map[EntityType.FLIGHT_NUMBER][0].text
                template = BASELINE_TEMPLATES.get("delay_by_flight_number")
                params = {"flight_number": flight_num}
            # Priority 3: Route (2 airport codes) → delay_causes_for_route
            elif len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                template = BASELINE_TEMPLATES.get("delay_causes_for_route")
                params = {
                    "origin_code": airport_codes[0].text,
                    "dest_code": airport_codes[1].text
                }
            # Priority 4: Average delays → average_delays_by_route
            elif "average" in question_lower or "avg" in question_lower:
                template = BASELINE_TEMPLATES.get("average_delays_by_route")
                params = {}
            # Priority 5: Negative delay / early arrivals
            elif "negative delay" in question_lower or ("early" in question_lower and "arrival" in question_lower) or "arrived early" in question_lower:
                # Early arrivals (negative delays) → dedicated template
                template = BASELINE_TEMPLATES.get("early_arrival_journeys")
                params = {}
            # Default: high delay journeys (optionally with threshold)
            else:
                template = BASELINE_TEMPLATES.get("high_delay_journeys")
                params = {}
                if delay_threshold is not None:
                    params["min_delay"] = delay_threshold
        
        # PASSENGER_SATISFACTION intent matching
        elif intent == Intent.PASSENGER_SATISFACTION:
            question_lower = question.lower()
            # Check for satisfaction keywords first (to avoid FLIGHT_STATUS misclassification)
            satisfaction_keywords = ["satisfaction", "rating", "score", "food", "service", "review", "feedback"]
            has_satisfaction_keyword = any(kw in question_lower for kw in satisfaction_keywords)
            
            # Priority 1: flight-specific satisfaction (flight number + satisfaction wording)
            flight_num_entity = entity_map.get(EntityType.FLIGHT_NUMBER)
            flight_num: str | None = None
            if flight_num_entity:
                flight_num = flight_num_entity[0].text
            else:
                # Fallback: extract numeric flight number directly from question text
                # Handles cases like "What is satisfaction for flight 42?"
                import re
                m = re.search(r"\bflight(?:\s*number)?\s*(\d{1,5})\b", question_lower)
                if m:
                    flight_num = m.group(1)
            
            if has_satisfaction_keyword and flight_num:
                # Use satisfaction_by_flight_number when we have both concept + specific flight
                template = BASELINE_TEMPLATES.get("satisfaction_by_flight_number")
                params = {"flight_number": flight_num}
            
            # Priority 2: airline-level satisfaction
            elif EntityType.AIRLINE in entity_map:
                airline = entity_map[EntityType.AIRLINE][0].text
                template = BASELINE_TEMPLATES.get("passenger_satisfaction_for_airline")
                params = {"airline_name": airline}
            
            else:
                # Priority 3: well-rated vs poorly rated general journeys
                # Check for well-rated/high satisfaction FIRST (before poorly rated)
                # This prevents "well-rated" from matching "poorly rated" patterns
                well_rated_keywords = [
                    "well rated", "well-rated", "highly rated", "top rated", "best rated",
                    "good satisfaction", "high satisfaction", "well-rated flights"
                ]
                if any(kw in question_lower for kw in well_rated_keywords):
                    # Query about well-rated flights/journeys
                    template = BASELINE_TEMPLATES.get("high_satisfaction_journeys")
                    params = {}
                elif "poor" in question_lower or "low satisfaction" in question_lower or "poorly rated" in question_lower:
                    # Query about poorly rated flights/journeys
                    import re
                    template = BASELINE_TEMPLATES.get("low_satisfaction_journeys")
                    params = {}
                    # Optional numeric threshold: "below 2", "less than 3"
                    m_food = re.search(r"(?:below|under|less than)\s+(\d+)", question_lower)
                    if m_food:
                        params["max_food_score"] = int(m_food.group(1))
                    else:
                        # Also support "score 1", "rating 1" style phrasing
                        m_exact = re.search(r"(?:score|rating)\s+(\d+)", question_lower)
                        if m_exact:
                            params["max_food_score"] = int(m_exact.group(1))
                else:
                    # General satisfaction query - default to low satisfaction journeys
                    import re
                    template = BASELINE_TEMPLATES.get("low_satisfaction_journeys")
                    params = {}
                    m_food = re.search(r"(?:below|under|less than)\s+(\d+)", question_lower)
                    if m_food:
                        params["max_food_score"] = int(m_food.group(1))
        
        # GENERAL_KG_QUERY intent matching
        elif intent == Intent.GENERAL_KG_QUERY:
            question_lower = question.lower()  # Normalize once for all checks
            # Check for two airport codes first (route query)
            if len(entity_map.get(EntityType.AIRPORT_CODE, [])) >= 2:
                airport_codes = entity_map[EntityType.AIRPORT_CODE]
                # If question mentions "flight" or "status", use flight_status_by_route
                if "flight" in question_lower or "status" in question_lower:
                    template = BASELINE_TEMPLATES.get("safe_flight_status_by_route")
                    params = {
                        "origin_code": airport_codes[0].text,
                        "dest_code": airport_codes[1].text
                    }
                else:
                    # Otherwise use best_route
                    template = BASELINE_TEMPLATES.get("best_route_by_airport_codes")
                    params = {
                        "origin_code": airport_codes[0].text,
                        "dest_code": airport_codes[1].text
                    }
            elif EntityType.FLIGHT_NUMBER in entity_map:
                # Already normalized to string in pipeline
                flight_num = entity_map[EntityType.FLIGHT_NUMBER][0].text
                template = BASELINE_TEMPLATES.get("flight_status_by_number")
                params = {"flight_number": flight_num}
            elif EntityType.CITY in entity_map:
                city = entity_map[EntityType.CITY][0].text
                # Try "from" city first, could be enhanced with keyword detection
                template = BASELINE_TEMPLATES.get("general_flights_from_city")
                params = {"city": city}
            elif EntityType.AIRPORT_CODE in entity_map:
                airport_code = entity_map[EntityType.AIRPORT_CODE][0].text
                template = BASELINE_TEMPLATES.get("popular_routes_from_airport")
                params = {"airport_code": airport_code}
            # Passenger class analytics: use journey_statistics as a reasonable summary
            elif "passenger class" in question_lower or "passenger classes" in question_lower:
                template = BASELINE_TEMPLATES.get("journey_statistics")
                params = {}
            elif "journey statistics" in question_lower or ("statistics" in question_lower and "journey" in question_lower):
                template = BASELINE_TEMPLATES.get("journey_statistics")
                params = {}
            # Check for "leg patterns" FIRST (most specific) - before generic "journey patterns" or "patterns"
            elif "leg patterns" in question_lower or "leg pattern" in question_lower or ("leg" in question_lower and "pattern" in question_lower):
                # Specific query about journey leg patterns
                template = BASELINE_TEMPLATES.get("journey_leg_patterns")
                params = {}
            # Guard: journey_patterns only if NOT about leg patterns
            elif ("journey patterns" in question_lower or ("patterns" in question_lower and "journey" in question_lower)) \
                 and "leg pattern" not in question_lower and "leg patterns" not in question_lower:
                template = BASELINE_TEMPLATES.get("journey_patterns")
                params = {}
            elif "analyze" in question_lower and "journey" in question_lower:
                template = BASELINE_TEMPLATES.get("analyze_passenger_journeys")
                params = {}
            elif "operational insights" in question_lower or "key insights" in question_lower or ("insights" in question_lower and "operational" in question_lower):
                # Query about operational insights (check before generic "insights")
                template = BASELINE_TEMPLATES.get("operational_insights")
                params = {}
            elif "statistics" in question_lower or "stats" in question_lower:
                template = BASELINE_TEMPLATES.get("journey_statistics")
                params = {}
            elif "patterns" in question_lower:
                # Generic patterns fallback (only if not leg patterns)
                template = BASELINE_TEMPLATES.get("journey_patterns")
                params = {}
            elif "insights" in question_lower:
                # Generic "insights" keyword fallback
                template = BASELINE_TEMPLATES.get("operational_insights")
                params = {}
            else:
                # Default fallback for general queries - use operational insights for comprehensive overview
                template = BASELINE_TEMPLATES.get("operational_insights")
                params = {}
        
        # Handle UNKNOWN intent - return None (no template, no query)
        # This prevents misleading "1 row" results for unclassifiable queries
        elif intent == Intent.UNKNOWN:
            template = None
            params = {}
        
        return (template, params)

    def run_template(self, template: QueryTemplate, params: dict | None = None) -> list[dict]:
        """
        Execute a template's Cypher query with merged default parameters.
        
        - Merges template.default_params (if any) with the provided params.
        - Auto-injects any missing Cypher parameters as None to avoid ParameterMissing errors.
        """
        import re

        params = params or {}
        base_defaults = template.default_params or {}
        merged_params = {**base_defaults, **params}

        # Detect all $param names in the Cypher and ensure keys exist
        param_re = re.compile(r"\$([A-Za-z_]\w*)")
        expected = set(param_re.findall(template.cypher))
        for key in expected:
            merged_params.setdefault(key, None)

        return self.client.run_query(template.cypher, merged_params)
    
    def retrieve(
        self, 
        intent_result: IntentResult, 
        entities: list[Entity],
        question: str = ""
    ) -> list[dict]:
        """
        Retrieve results from the graph using the selected template.
        
        Args:
            intent_result: The intent classification result.
            entities: List of extracted entities.
            question: Original user question (for keyword-based template selection).
            
        Returns:
            List of dictionaries representing query results. Returns empty list
            if no suitable template is found or if the query fails.
        """
        template, params = self.select_template(intent_result.intent, entities, question=question)
        
        if template is None:
            return []
        
        try:
            # Use run_template helper to merge default params and auto-inject missing Cypher params
            results = self.run_template(template, params)
            return results
        except Exception as e:
            print(f"Error executing query template '{template.id}': {e}")
            return []


if __name__ == "__main__":
    """Demo script showing baseline retrieval in action."""
    
    from ..preprocessing.intent_classifier import IntentResult
    from ..preprocessing.entity_extractor import Entity, EntityType
    
    # Create retriever (will create its own Neo4jClient if not provided)
    retriever = BaselineRetriever()
    
    # Scenario 1: Flight status by flight number
    print("=" * 70)
    print("Scenario 1: Flight status by flight number")
    print("=" * 70)
    intent1 = IntentResult(
        intent=Intent.FLIGHT_STATUS,
        confidence=0.95,
        matched_keywords=["flight status", "flight number"]
    )
    entities1 = [
        Entity(
            type=EntityType.FLIGHT_NUMBER,
            text="2411",
            start=0,
            end=4
        )
    ]
    results1 = retriever.retrieve(intent1, entities1)
    print(f"Query: flight_status_by_number")
    print(f"Parameters: {{'flight_number': '2411'}}")
    print(f"Results: {len(results1)} rows")
    if results1:
        print("Sample result:", results1[0] if results1 else "None")
    print()
    
    # Scenario 2: Best route between cities
    print("=" * 70)
    print("Scenario 2: Best route between cities")
    print("=" * 70)
    intent2 = IntentResult(
        intent=Intent.BEST_ROUTE,
        confidence=0.88,
        matched_keywords=["best route"]
    )
    entities2 = [
        Entity(
            type=EntityType.CITY,
            text="Cairo",
            start=0,
            end=5
        ),
        Entity(
            type=EntityType.CITY,
            text="London",
            start=0,
            end=6
        )
    ]
    results2 = retriever.retrieve(intent2, entities2)
    print(f"Query: best_route_by_city")
    print(f"Parameters: {{'origin_city': 'Cairo', 'dest_city': 'London'}}")
    print(f"Results: {len(results2)} rows")
    if results2:
        print("Sample result:", results2[0] if results2 else "None")
    print()
    
    # Scenario 3: Airline information
    print("=" * 70)
    print("Scenario 3: Airline information")
    print("=" * 70)
    intent3 = IntentResult(
        intent=Intent.AIRLINE_INFO,
        confidence=0.92,
        matched_keywords=["airline"]
    )
    entities3 = [
        Entity(
            type=EntityType.AIRLINE,
            text="EgyptAir",
            start=0,
            end=8
        )
    ]
    results3 = retriever.retrieve(intent3, entities3)
    print(f"Query: airline_basic_info")
    print(f"Parameters: {{'airline_name': 'EgyptAir'}}")
    print(f"Results: {len(results3)} rows")
    if results3:
        print("Sample result:", results3[0] if results3 else "None")
    print()
    
    # Scenario 4: General query - flights from city
    print("=" * 70)
    print("Scenario 4: General query - flights from city")
    print("=" * 70)
    intent4 = IntentResult(
        intent=Intent.GENERAL_KG_QUERY,
        confidence=0.75,
        matched_keywords=["what", "flights"]
    )
    entities4 = [
        Entity(
            type=EntityType.CITY,
            text="Paris",
            start=0,
            end=5
        )
    ]
    results4 = retriever.retrieve(intent4, entities4)
    print(f"Query: general_flights_from_city")
    print(f"Parameters: {{'city': 'Paris'}}")
    print(f"Results: {len(results4)} rows")
    if results4:
        print("Sample result:", results4[0] if results4 else "None")
    print()
    
    # Close the client connection
    retriever.client.close()
    print("=" * 70)
    print("Demo completed!")
