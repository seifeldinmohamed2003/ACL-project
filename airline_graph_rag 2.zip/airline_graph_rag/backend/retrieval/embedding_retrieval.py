"""
Semantic retrieval using vector embeddings for airline GraphRAG.

This module provides:
1. Functions to generate and store embeddings for graph nodes
2. Semantic similarity search using Neo4j vector index
3. Integration with the baseline retrieval system
"""

from typing import List, Dict, Any, Optional

from ..neo4j_client import Neo4jClient
from ..preprocessing.embeddings import EmbeddingService, EmbeddingBackend


def _as_float_list(vec) -> List[float]:
    """
    Safely convert an embedding vector to a plain list of floats.
    
    Handles list/tuple/NumPy/torch tensors without importing heavy libs here.
    """
    try:
        return [float(x) for x in vec]
    except Exception:
        return list(map(float, list(vec)))


def create_text_representation(node: Dict[str, Any], node_type: str) -> str:
    """
    Create a text representation of a node for embedding.
    
    For Journey nodes, combines multiple properties into a descriptive text.
    For Flight nodes, creates a description from available properties.
    
    Args:
        node: Dictionary containing node properties
        node_type: Type of node ('Journey' or 'Flight')
        
    Returns:
        Text representation suitable for embedding
    """
    if node_type == "Journey":
        # Create a descriptive text from Journey properties
        parts = []
        if "feedback_ID" in node:
            parts.append(f"Journey ID: {node['feedback_ID']}")
        if "passenger_class" in node:
            parts.append(f"Passenger class: {node['passenger_class']}")
        if "number_of_legs" in node:
            parts.append(f"Number of legs: {node['number_of_legs']}")
        if "actual_flown_miles" in node:
            parts.append(f"Distance: {node['actual_flown_miles']} miles")
        if "arrival_delay_minutes" in node:
            delay = node["arrival_delay_minutes"]
            if delay is not None:
                if delay > 0:
                    parts.append(f"Delayed by {delay} minutes")
                else:
                    parts.append(f"Arrived {abs(delay)} minutes early")
            else:
                parts.append("On-time arrival")
        if "food_satisfaction_score" in node:
            score = node["food_satisfaction_score"]
            if score is not None:
                parts.append(f"Food satisfaction: {score}/5")
        
        return ". ".join(parts) if parts else "Journey information"
    
    elif node_type == "Flight":
        parts = []
        if "flight_number" in node:
            parts.append(f"Flight {node['flight_number']}")
        if "fleet_type_description" in node:
            parts.append(f"Aircraft: {node['fleet_type_description']}")
        
        return ". ".join(parts) if parts else "Flight information"
    
    else:
        # Generic fallback
        return str(node)


def generate_and_store_embeddings(
    client: Neo4jClient,
    embedding_service: EmbeddingService,
    node_type: str = "Journey",
    batch_size: int = 100,
    property_name: str = "embedding"
) -> int:
    """
    Generate embeddings for nodes and store them in Neo4j.
    
    Args:
        client: Neo4j client instance
        embedding_service: Embedding service to generate vectors
        node_type: Type of nodes to embed ('Journey' or 'Flight')
        batch_size: Number of nodes to process in each batch
        property_name: Name of the property to store embeddings in
        
    Returns:
        Number of nodes processed
    """
    print(f"Generating embeddings for {node_type} nodes...")
    
    # Fetch all nodes of the specified type
    query = f"MATCH (n:{node_type}) RETURN n, id(n) AS node_id"
    all_nodes = client.run_query(query)
    
    if not all_nodes:
        print(f"No {node_type} nodes found.")
        return 0
    
    total_nodes = len(all_nodes)
    print(f"Found {total_nodes} {node_type} nodes. Processing in batches of {batch_size}...")
    
    processed = 0
    
    # Process in batches
    for i in range(0, total_nodes, batch_size):
        batch = all_nodes[i:i + batch_size]
        
        # Create text representations
        texts = []
        node_ids = []
        for record in batch:
            node = record["n"]
            node_id = record["node_id"]
            text = create_text_representation(node, node_type)
            texts.append(text)
            node_ids.append(node_id)
        
        # Generate embeddings
        print(f"  Processing batch {i // batch_size + 1} ({len(texts)} nodes)...")
        embeddings = embedding_service.embed_batch(texts)
        
        # Store embeddings back to Neo4j
        for node_id, embedding in zip(node_ids, embeddings):
            update_query = f"""
            MATCH (n:{node_type})
            WHERE id(n) = $node_id
            SET n.{property_name} = $embedding
            """
            client.run_query(update_query, {
                "node_id": node_id,
                "embedding": embedding
            })
        
        processed += len(batch)
        print(f"  Processed {processed}/{total_nodes} nodes")
    
    print(f"✓ Completed embedding generation for {processed} {node_type} nodes")
    return processed


def create_vector_index(
    client: Neo4jClient,
    index_name: str,
    node_type: str,
    property_name: str = "embedding",
    vector_dimension: int = 384  # Default for all-MiniLM-L6-v2
) -> bool:
    """
    Create a vector index in Neo4j for similarity search.
    
    Args:
        client: Neo4j client instance
        index_name: Name for the vector index
        node_type: Type of nodes to index
        property_name: Property containing the embedding vector
        vector_dimension: Dimension of the embedding vectors
        
    Returns:
        True if index was created successfully, False otherwise
    """
    # Check if index already exists
    check_query = "SHOW INDEXES"
    existing_indexes = client.run_query(check_query)
    
    for idx in existing_indexes:
        if idx.get("name") == index_name:
            print(f"Index '{index_name}' already exists. Skipping creation.")
            return True
    
    # Create vector index
    # Note: Neo4j 5.11+ uses CREATE VECTOR INDEX syntax
    # For older versions or different syntax, we'll try multiple approaches
    create_queries = [
        # Neo4j 5.11+ syntax
        f"""
        CREATE VECTOR INDEX {index_name} IF NOT EXISTS
        FOR (n:{node_type})
        ON n.{property_name}
        OPTIONS {{
            indexConfig: {{
                `vector.dimensions`: {vector_dimension},
                `vector.similarity_function`: 'cosine'
            }}
        }}
        """,
        # Alternative syntax (some Neo4j versions)
        f"""
        CALL db.index.vector.createNodeIndex(
            '{index_name}',
            '{node_type}',
            '{property_name}',
            {vector_dimension},
            'cosine'
        )
        """
    ]
    
    # Try each query syntax until one works
    for i, create_query in enumerate(create_queries):
        try:
            client.run_query(create_query)
            print(f"✓ Created vector index '{index_name}' (using syntax {i+1})")
            return True
        except Exception as e:
            if i == len(create_queries) - 1:
                # Last attempt failed
                print(f"Error creating vector index: {e}")
                print("Note: Vector indexes require Neo4j 5.11+ with vector index support.")
                print("You may need to create the index manually in Neo4j Browser.")
                return False
            # Try next syntax
            continue


def semantic_retrieve(
    client: Neo4jClient,
    embedding_service: EmbeddingService,
    question: str,
    index_name: str = "journey_embeddings",
    node_type: str = "Journey",
    top_k: int = 5,
    property_name: str = "embedding",
    min_score: float = 0.3
) -> List[Dict[str, Any]]:
    """
    Perform semantic similarity search using vector embeddings.
    
    Args:
        client: Neo4j client instance
        embedding_service: Embedding service to generate query vector
        question: User's question to search for
        index_name: Name of the vector index to use
        node_type: Type of nodes to search
        top_k: Number of top results to return
        property_name: Property containing the embedding vector
        min_score: Minimum similarity score threshold (0.0-1.0). Results below this are filtered out.
                  Default 0.3 allows exploratory queries while filtering weak matches.
                  For structured queries, use 0.5-0.6 to avoid misleading results.
        
    Returns:
        List of matching nodes with their properties and similarity scores (filtered by min_score)
    """
    # Generate embedding for the question and ensure it's a plain list of floats
    query_embedding = _as_float_list(embedding_service.embed_text(question))

    # Query more candidates than we ultimately return so min_score filtering
    # doesn't trivially zero out the small top_k slice.
    candidate_k = max(top_k * 5, 25)

    # Primary: Neo4j 5.11+ vector index API
    search_query = f"""
    CALL db.index.vector.queryNodes(
        '{index_name}',
        $candidate_k,
        $query_embedding
    )
    YIELD node, score
    WITH node, score
    WHERE score >= $min_score
    RETURN elementId(node) AS node_id, node, score
    ORDER BY score DESC
    LIMIT $top_k
    """
    
    try:
        results = client.run_query(
            search_query,
            {
                "query_embedding": query_embedding,
                "top_k": top_k,
                "candidate_k": candidate_k,
                "min_score": float(min_score),
            },
        )
        
        formatted_results: List[Dict[str, Any]] = []
        for record in results:
            score = record.get("score", 0.0)
            node = record.get("node", {})
            node_data = dict(node)
            node_data["_node_id"] = record.get("node_id", "")
            if "feedback_ID" in node_data:
                node_data["journey_id"] = node_data["feedback_ID"]
            node_data["_similarity_score"] = score
            formatted_results.append(node_data)
        
        return formatted_results
    
    except Exception as e:
        print(f"[semantic_retrieve] vector index query failed: {type(e).__name__}: {e}")

        # Fallback: Neo4j native cosine similarity without requiring GDS
        fallback_query = f"""
        MATCH (n:{node_type})
        WHERE n.{property_name} IS NOT NULL
        WITH n, vector.similarity.cosine(n.{property_name}, $query_embedding) AS score
        WHERE score >= $min_score
        RETURN elementId(n) AS node_id, n AS node, score
        ORDER BY score DESC
        LIMIT $top_k
        """
        try:
            results = client.run_query(
                fallback_query,
                {
                    "query_embedding": query_embedding,
                    "top_k": top_k,
                    "min_score": float(min_score),
                },
            )

            formatted_results: List[Dict[str, Any]] = []
            for record in results:
                score = record.get("score", 0.0)
                node = record.get("node", {})
                node_data = dict(node)
                node_data["_node_id"] = record.get("node_id", "")
                if "feedback_ID" in node_data:
                    node_data["journey_id"] = node_data["feedback_ID"]
                node_data["_similarity_score"] = score
                formatted_results.append(node_data)

            return formatted_results
        except Exception as e2:
            print(f"[semantic_retrieve] fallback failed: {type(e2).__name__}: {e2}")
            return []


if __name__ == "__main__":
    """Script to generate embeddings and create vector index."""
    from ..preprocessing.embeddings import EmbeddingService, EmbeddingBackend
    
    client = Neo4jClient()
    embedding_service = EmbeddingService(EmbeddingBackend.SENTENCE_TRANSFORMER)
    
    # Generate embeddings for Journey nodes
    print("=" * 70)
    print("Step 1: Generating embeddings for Journey nodes")
    print("=" * 70)
    num_processed = generate_and_store_embeddings(
        client=client,
        embedding_service=embedding_service,
        node_type="Journey",
        batch_size=50
    )
    
    if num_processed > 0:
        print("\n" + "=" * 70)
        print("Step 2: Creating vector index")
        print("=" * 70)
        # all-MiniLM-L6-v2 has 384 dimensions
        create_vector_index(
            client=client,
            index_name="journey_embeddings",
            node_type="Journey",
            property_name="embedding",
            vector_dimension=384
        )
        
        print("\n" + "=" * 70)
        print("Step 3: Testing semantic search")
        print("=" * 70)
        test_queries = [
            "What are the best journeys with minimal delays?",
            "Find journeys with high food satisfaction",
            "Show me long distance flights"
        ]
        
        for query in test_queries:
            print(f"\nQuery: {query}")
            results = semantic_retrieve(
                client=client,
                embedding_service=embedding_service,
                question=query,
                top_k=3
            )
            print(f"Found {len(results)} results")
            for i, result in enumerate(results, 1):
                score = result.pop("_similarity_score", 0.0)
                print(f"  {i}. Score: {score:.3f}, Data: {result}")
    
    client.close()
    print("\n✓ Embedding generation and indexing complete!")
