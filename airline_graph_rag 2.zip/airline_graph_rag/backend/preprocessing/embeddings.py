from enum import Enum
from typing import Optional

from sentence_transformers import SentenceTransformer
import openai

from backend.config import settings


class EmbeddingBackend(Enum):
    SENTENCE_TRANSFORMER = "sentence_transformer"
    OPENAI = "openai"


class EmbeddingService:
    def __init__(self, backend: EmbeddingBackend = EmbeddingBackend.SENTENCE_TRANSFORMER):
        self.backend = backend
        self._model: Optional[SentenceTransformer] = None
        self._openai_client: Optional[openai.OpenAI] = None
        
        if backend == EmbeddingBackend.SENTENCE_TRANSFORMER:
            # Lazy loading - will be loaded on first use
            pass
        elif backend == EmbeddingBackend.OPENAI:
            if not settings.OPENAI_API_KEY:
                raise RuntimeError(
                    "OPENAI_API_KEY is not set. Please set it in your environment variables or .env file."
                )
            self._openai_client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
    
    def _get_sentence_transformer_model(self) -> SentenceTransformer:
        """Lazily load the SentenceTransformer model."""
        if self._model is None:
            # Default model: all-MiniLM-L6-v2 (384 dimensions, fast)
            # Can be changed to test other models:
            # - "all-mpnet-base-v2" (768 dimensions, more accurate)
            # - "sentence-transformers/all-MiniLM-L6-v2" (explicit)
            try:
                self._model = SentenceTransformer("all-MiniLM-L6-v2")
            except Exception as e:
                # Graceful failure: if model download fails, disable semantic retrieval
                print(f"[WARNING] Failed to load SentenceTransformer model: {e}")
                print("[WARNING] Semantic retrieval will be disabled. Model may need to be downloaded first.")
                print("[WARNING] To download: python -c \"from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')\"")
                raise RuntimeError(f"Embedding model unavailable: {e}. Semantic retrieval disabled.")
        return self._model
    
    def embed_text(self, text: str) -> list[float]:
        """Embed a single text string."""
        if self.backend == EmbeddingBackend.SENTENCE_TRANSFORMER:
            model = self._get_sentence_transformer_model()
            embedding = model.encode(text, convert_to_numpy=True)
            return embedding.tolist()
        elif self.backend == EmbeddingBackend.OPENAI:
            if self._openai_client is None:
                raise RuntimeError("OpenAI client not initialized")
            response = self._openai_client.embeddings.create(
                model="text-embedding-3-small",
                input=text
            )
            return response.data[0].embedding
        else:
            raise ValueError(f"Unknown backend: {self.backend}")
    
    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of text strings."""
        if self.backend == EmbeddingBackend.SENTENCE_TRANSFORMER:
            model = self._get_sentence_transformer_model()
            embeddings = model.encode(texts, convert_to_numpy=True)
            return embeddings.tolist()
        elif self.backend == EmbeddingBackend.OPENAI:
            if self._openai_client is None:
                raise RuntimeError("OpenAI client not initialized")
            response = self._openai_client.embeddings.create(
                model="text-embedding-3-small",
                input=texts
            )
            # Sort by index to maintain order (OpenAI may return in different order)
            sorted_data = sorted(response.data, key=lambda x: x.index)
            return [item.embedding for item in sorted_data]
        else:
            raise ValueError(f"Unknown backend: {self.backend}")


if __name__ == "__main__":
    sample_text = "What flights are available from New York to London?"
    
    # Test SentenceTransformer backend
    print("Testing SentenceTransformer backend...")
    try:
        st_service = EmbeddingService(EmbeddingBackend.SENTENCE_TRANSFORMER)
        st_embedding = st_service.embed_text(sample_text)
        print(f"SentenceTransformer embedding length: {len(st_embedding)}")
    except Exception as e:
        print(f"Error with SentenceTransformer: {e}")
    
    # Test OpenAI backend (if key is available)
    print("\nTesting OpenAI backend...")
    try:
        openai_service = EmbeddingService(EmbeddingBackend.OPENAI)
        openai_embedding = openai_service.embed_text(sample_text)
        print(f"OpenAI embedding length: {len(openai_embedding)}")
    except RuntimeError as e:
        print(f"OpenAI backend not available: {e}")
    except Exception as e:
        print(f"Error with OpenAI: {e}")
