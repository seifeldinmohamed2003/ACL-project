"""Rule-based intent classifier for airline/aviation queries."""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List


class Intent(str, Enum):
    """Intent categories for airline-related queries."""
    
    FLIGHT_STATUS = "FLIGHT_STATUS"
    BEST_ROUTE = "BEST_ROUTE"
    AIRLINE_INFO = "AIRLINE_INFO"
    AIRPORT_INFO = "AIRPORT_INFO"
    PASSENGER_SATISFACTION = "PASSENGER_SATISFACTION"
    DELAY_CAUSES = "DELAY_CAUSES"
    GENERAL_KG_QUERY = "GENERAL_KG_QUERY"
    UNKNOWN = "UNKNOWN"


@dataclass
class IntentResult:
    """Result of intent classification."""
    
    intent: Intent
    confidence: float
    matched_keywords: List[str]


class RuleBasedIntentClassifier:
    """Rule-based classifier for identifying user intent in airline queries."""
    
    def __init__(self) -> None:
        """Initialize keyword lists for each intent category."""
        self.keyword_map: Dict[Intent, List[str]] = {
            Intent.FLIGHT_STATUS: [
                "flight status", "status of flight", "where is flight", "arrival time", 
                "departure time", "flight number", "is flight", "flight delayed", 
                "flight on time", "when does flight", "flight arrival", "flight departure", 
                "track flight", "status", "arrival", "departure",
                "what is the status", "show me information about flight"
            ],
            Intent.BEST_ROUTE: [
                "best route", "cheapest", "shortest", "fastest route", "optimal route",
                "best way to", "recommended route", "best flight", "cheapest flight",
                "shortest path", "quickest route", "best connection",
                "between", "routes between", "flights between",  # "between X and Y" -> BEST_ROUTE
                "from.*to", "go from.*to", "flights from.*to"  # Pattern matching handled separately
            ],
            Intent.AIRLINE_INFO: [
                "airline", "carrier", "airline name", "which airline", "airline company",
                "airline service", "airline quality", "airline rating", "airline reputation"
            ],
            Intent.AIRPORT_INFO: [
                "airport", "terminal", "gate", "airport code", "airport location",
                "airport facilities", "airport services", "which airport", "airport name"
            ],
            Intent.PASSENGER_SATISFACTION: [
                "satisfaction", "complaint", "review", "rating", "feedback",
                "passenger experience", "service quality", "customer service",
                "passenger complaints", "how satisfied", "passenger rating",
                "poorly rated", "poor rating", "low satisfaction", "poorly rated flights",
                "worst flights", "bad flights", "unsatisfied", "dissatisfied",
                "food satisfaction", "food score", "service score", "satisfaction score",
                "well rated", "well-rated", "highly rated", "top rated", "best rated",
                "good satisfaction", "high satisfaction", "well-rated flights"
            ],
            Intent.DELAY_CAUSES: [
                "delay", "late", "cancelled", "cancellation", "why delayed",
                "delay reason", "delay cause", "why late", "why cancelled",
                "delayed flights", "flight delays", "cancelled flights",
                "high delay", "significant delay", "most delayed", "delayed journeys"
            ],
            Intent.GENERAL_KG_QUERY: [
                # Focus GENERAL_KG_QUERY on analytics / exploratory language,
                # not generic question stopwords that appear in nearly every query.
                "statistics", "stats", "patterns", "insights", "analysis",
                "distribution", "breakdown", "summary", "overall",
                "journey statistics", "journey patterns", "operational insights"
            ]
        }
    
    def classify(self, text: str, entities: list = None) -> IntentResult:
        """
        Classify the intent of a user query.
        
        Args:
            text: The user query text to classify.
            entities: Optional list of extracted entities (for entity-based overrides)
            
        Returns:
            IntentResult containing the classified intent, confidence score,
            and list of matched keywords.
        """
        text_lower = text.lower()
        
        # Intent override rules (applied before keyword matching)
        # CORRECTED Priority order: 
        # 1. flight_number + delay/satisfaction keywords (highest priority)
        # 2. delay keywords (without flight_number)
        # 3. satisfaction keywords (without flight_number)
        # 4. flight_number alone → FLIGHT_STATUS
        # 5. route queries (2 airports) → BEST_ROUTE/DELAY_CAUSES
        # 6. other keywords
        
        if entities:
            has_flight_number = any(e.type.value == "flight_number" for e in entities)
            has_satisfaction_keywords = any(kw in text_lower for kw in ["satisfaction", "rating", "score", "review", "feedback"])
            has_delay_keywords = any(kw in text_lower for kw in ["delay", "late", "on time", "delayed", "cancelled"])
            # Early-arrival / negative delay strongly indicates delay intent
            has_early_arrival = ("negative delay" in text_lower) or ("arrived early" in text_lower) or ("early arrival" in text_lower)
            
            # Priority 1: flight_number + delay keywords → DELAY_CAUSES
            if has_flight_number and (has_delay_keywords or has_early_arrival):
                return IntentResult(
                    intent=Intent.DELAY_CAUSES,
                    confidence=0.95,
                    matched_keywords=["flight_number", "delay_keywords"]
                )
            
            # Priority 2: flight_number + satisfaction keywords → PASSENGER_SATISFACTION
            if has_flight_number and has_satisfaction_keywords:
                return IntentResult(
                    intent=Intent.PASSENGER_SATISFACTION,
                    confidence=0.95,
                    matched_keywords=["flight_number", "satisfaction_keywords"]
                )
            
            # Priority 3: flight_number + status/info keywords → FLIGHT_STATUS (highest priority for status queries)
            has_status_keywords = any(kw in text_lower for kw in ["status", "information about flight", "show me flight", "flight details", "flight info"])
            if has_flight_number and has_status_keywords:
                return IntentResult(
                    intent=Intent.FLIGHT_STATUS,
                    confidence=0.98,  # Very high confidence - user explicitly asked for status
                    matched_keywords=["flight_number", "status_keywords"]
                )
            
            # Priority 4: flight_number alone (no delay/satisfaction/status) → FLIGHT_STATUS
            if has_flight_number and not has_delay_keywords and not has_satisfaction_keywords and not has_status_keywords:
                return IntentResult(
                    intent=Intent.FLIGHT_STATUS,
                    confidence=0.95,
                    matched_keywords=["flight_number_entity"]
                )
        
        # Priority 4: Delay keywords (without flight_number) → DELAY_CAUSES
        if any(kw in text_lower for kw in ["delay", "late", "on time", "delayed", "cancelled"]) or \
           "arrived early" in text_lower or "early arrival" in text_lower or "negative delay" in text_lower:
            return IntentResult(
                intent=Intent.DELAY_CAUSES,
                confidence=0.90,
                matched_keywords=["delay/late/cancelled"]
            )
        
        # Priority 5: Satisfaction keywords (without flight_number) → PASSENGER_SATISFACTION
        if any(kw in text_lower for kw in ["satisfaction", "rating", "score", "review", "feedback"]):
            return IntentResult(
                intent=Intent.PASSENGER_SATISFACTION,
                confidence=0.90,
                matched_keywords=["satisfaction/rating/score/review/feedback"]
            )
        
        # Priority 6: Route queries (2 airports + route keywords) → BEST_ROUTE or DELAY_CAUSES
        if entities:
            airport_codes = [e for e in entities if e.type.value == "airport_code"]
            has_two_airports = len(airport_codes) >= 2
            # Include "flights go" as a route keyword (e.g., "What flights go from X to Y")
            has_route_keywords = any(kw in text_lower for kw in ["from", "to", "between", "route", "flights go", "go from"])
            # Don't use standalone "flight" as route keyword - it's too generic
            
            if has_two_airports and has_route_keywords:
                # "between" keyword is a strong signal for BEST_ROUTE
                if "between" in text_lower:
                    return IntentResult(
                        intent=Intent.BEST_ROUTE,
                        confidence=0.95,
                        matched_keywords=["two_airport_codes", "between_keyword"]
                    )
                # Check if it's asking for "best route"
                elif any(kw in text_lower for kw in ["best", "optimal", "recommended", "preferred", "cheapest", "shortest"]):
                    return IntentResult(
                        intent=Intent.BEST_ROUTE,
                        confidence=0.90,
                        matched_keywords=["two_airport_codes", "best_route_keywords"]
                    )
                else:
                    # "What flights go from X to Y" → BEST_ROUTE (for route lookup)
                    return IntentResult(
                        intent=Intent.BEST_ROUTE,
                        confidence=0.85,
                        matched_keywords=["two_airport_codes", "route_keywords"]
                    )

        # Route-shaped queries WITHOUT extracted airport codes:
        # e.g. "What flights go from A to B?", "What flights go from INVALID to CODE?"
        if "flights go from" in text_lower or "what flights go from" in text_lower:
            return IntentResult(
                intent=Intent.BEST_ROUTE,
                confidence=0.7,
                matched_keywords=["route_shaped_query_no_entities"]
            )
        
        # 2. Keyword-based overrides
        if any(kw in text_lower for kw in ["satisfaction", "rating", "score", "review", "feedback"]):
            # Strong signal for satisfaction - override to PASSENGER_SATISFACTION
            return IntentResult(
                intent=Intent.PASSENGER_SATISFACTION,
                confidence=0.90,
                matched_keywords=["satisfaction/rating/score/review/feedback"]
            )
        
        # 3. High-priority overrides for airline / airport information queries
        # e.g. "What is the airline information?", "Show information about ABX airport"
        if "airline" in text_lower and any(w in text_lower for w in ["info", "information", "details", "metrics", "performance"]):
            return IntentResult(
                intent=Intent.AIRLINE_INFO,
                confidence=0.95,
                matched_keywords=["airline", "info/information/details"]
            )
        
        if "airport" in text_lower and any(w in text_lower for w in ["info", "information", "details"]):
            return IntentResult(
                intent=Intent.AIRPORT_INFO,
                confidence=0.95,
                matched_keywords=["airport", "info/information/details"]
            )

        # 3a. Popular routes from a specific airport:
        # e.g. "What are popular routes from LAX?"
        if "popular routes" in text_lower:
            return IntentResult(
                intent=Intent.GENERAL_KG_QUERY,
                confidence=0.9,
                matched_keywords=["popular routes"]
            )

        # 3b. Passenger class analytics:
        # e.g. "What are the most popular passenger classes?", "Show me passenger class breakdown"
        if "passenger class" in text_lower or "passenger classes" in text_lower:
            return IntentResult(
                intent=Intent.GENERAL_KG_QUERY,
                confidence=0.9,
                matched_keywords=["passenger class(es)"]
            )
        
        # 4. Heuristic for analyze/patterns/statistics/info → GENERAL_KG_QUERY,
        # but only when not clearly about a specific airline or airport.
        info_keywords = ["analyze", "patterns", "statistics", "journeys", "give me", "some information", "info", "information"]
        if any(kw in text_lower for kw in info_keywords):
            if not any(w in text_lower for w in ["airline", "airport"]):
                return IntentResult(
                    intent=Intent.GENERAL_KG_QUERY,
                    confidence=0.85,
                    matched_keywords=["analyze/patterns/statistics/info"]
                )

        # 5. Generic fallback for extremely vague queries:
        # e.g. "Show me flights", "What can you tell me?"
        if "show me flights" in text_lower:
            return IntentResult(
                intent=Intent.GENERAL_KG_QUERY,
                confidence=0.7,
                matched_keywords=["show me flights"]
            )
        if "what can you tell me" in text_lower:
            return IntentResult(
                intent=Intent.GENERAL_KG_QUERY,
                confidence=0.7,
                matched_keywords=["what can you tell me"]
            )
        
        # Count keyword hits per intent
        intent_hits: Dict[Intent, List[str]] = {}
        
        for intent, keywords in self.keyword_map.items():
            matched = []
            for keyword in keywords:
                # Check for exact phrase match
                if keyword in text_lower:
                    matched.append(keyword)
                # For multi-word keywords, also check if all words appear
                elif " " in keyword:
                    words = keyword.split()
                    if all(word in text_lower for word in words):
                        matched.append(keyword)
            if matched:
                intent_hits[intent] = matched
        
        # If no hits, return UNKNOWN
        if not intent_hits:
            return IntentResult(
                intent=Intent.UNKNOWN,
                confidence=0.0,
                matched_keywords=[]
            )
        
        # Find intent with highest number of matched keywords
        best_intent = max(intent_hits.items(), key=lambda x: len(x[1]))[0]
        best_matched = intent_hits[best_intent]
        
        # Compute confidence: hits_for_best_intent / (total_hits + 1e-6)
        total_hits = sum(len(matched) for matched in intent_hits.values())
        confidence = len(best_matched) / (total_hits + 1e-6)
        
        return IntentResult(
            intent=best_intent,
            confidence=confidence,
            matched_keywords=best_matched
        )


if __name__ == "__main__":
    classifier = RuleBasedIntentClassifier()
    
    test_queries = [
        "What is the status of flight 2411?",
        "Which is the best route from Cairo to London?",
        "Why are so many flights delayed in winter?",
    ]
    
    print("Intent Classification Demo\n" + "=" * 50)
    for query in test_queries:
        result = classifier.classify(query)
        print(f"\nQuery: {query}")
        print(f"Intent: {result.intent.value}")
        print(f"Confidence: {result.confidence:.3f}")
        print(f"Matched Keywords: {result.matched_keywords}")

