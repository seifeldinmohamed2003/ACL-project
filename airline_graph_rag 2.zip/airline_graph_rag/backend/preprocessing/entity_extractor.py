"""
Rule-based entity extractor for airline domain.
Extracts airport codes, airline names, city names, and flight numbers.
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Set, Tuple


class EntityType(Enum):
    """Types of entities that can be extracted."""
    AIRPORT_CODE = "airport_code"
    AIRLINE = "airline"
    CITY = "city"
    FLIGHT_NUMBER = "flight_number"


@dataclass
class Entity:
    """Represents an extracted entity."""
    type: EntityType
    text: str
    start: int
    end: int  # exclusive end index


class RuleBasedEntityExtractor:
    """Lightweight rule-based entity extractor for airline domain."""
    
    def __init__(self):
        # Static vocabulary for airline names
        self.airline_names = [
            "EgyptAir",
            "British Airways",
            "Emirates",
            "Lufthansa",
            "Air France",
            "KLM",
            "Turkish Airlines",
            "Qatar Airways",
            "Etihad Airways",
            "American Airlines",
            "United Airlines",
            "Delta",
            "Air Canada",
            "Singapore Airlines",
            "Cathay Pacific",
        ]
        
        # Static vocabulary for city names
        self.city_names = [
            "Cairo",
            "London",
            "New York",
            "Dubai",
            "Paris",
            "Frankfurt",
            "Amsterdam",
            "Istanbul",
            "Doha",
            "Abu Dhabi",
            "Toronto",
            "Singapore",
            "Hong Kong",
            "Tokyo",
            "Sydney",
            "Los Angeles",
            "Chicago",
            "Miami",
            "Berlin",
            "Rome",
            "Madrid",
            "Barcelona",
        ]
        
        # Allow-list for airport codes (IATA 3-letter codes)
        self.airport_codes = {
            "CAI",  # Cairo
            "LHR",  # London Heathrow
            "JFK",  # New York JFK
            "DXB",  # Dubai
            "CDG",  # Paris Charles de Gaulle
            "FRA",  # Frankfurt
            "AMS",  # Amsterdam
            "IST",  # Istanbul
            "DOH",  # Doha
            "AUH",  # Abu Dhabi
            "YYZ",  # Toronto
            "SIN",  # Singapore
            "HKG",  # Hong Kong
            "NRT",  # Tokyo Narita
            "SYD",  # Sydney
            "LAX",  # Los Angeles
            "ORD",  # Chicago
            "MIA",  # Miami
            "BER",  # Berlin
            "FCO",  # Rome
            "MAD",  # Madrid
            "BCN",  # Barcelona
        }
        
        # Regex pattern for airport codes (3 letters, case-insensitive, will be normalized to uppercase)
        self.airport_code_pattern = re.compile(r"\b[A-Za-z]{3}\b")
        
        # Regex pattern for flight numbers (2 letters, optional space, 2-4 digits)
        self.flight_number_pattern = re.compile(r"\b[A-Z]{2}\s?\d{2,4}\b")
    
        # Regex pattern for numeric flight numbers (1-5 digits) when preceded by "flight"
        # Contextual pattern: matches "flight" (optional "number") followed by optional minus sign and 1-5 digits.
        # Negative numbers are captured so the pipeline can validate and return a proper INVALID_FLIGHT_NUMBER error.
        self.numeric_flight_number_pattern = re.compile(r"\bflight(?:\s*number)?\s*(-?\d{1,5})\b", re.IGNORECASE)
    
    def extract(self, text: str) -> List[Entity]:
        """
        Extract all entities from the given text.
        
        Args:
            text: Input text to extract entities from
            
        Returns:
            List of Entity objects, sorted by start position
        """
        entities: List[Entity] = []
        seen: Set[Tuple[int, int, EntityType]] = set()  # (start, end, type) for deduplication
        
        # Extract flight numbers (alphanumeric pattern like BA2490, or numeric like 2411, 924, etc.)
        for match in self.flight_number_pattern.finditer(text):
            start, end = match.span()
            entity_text = match.group()
            key = (start, end, EntityType.FLIGHT_NUMBER)
            if key not in seen:
                entities.append(Entity(
                    type=EntityType.FLIGHT_NUMBER,
                    text=entity_text,
                    start=start,
                    end=end
                ))
                seen.add(key)
        
        # Extract numeric flight numbers (1-5 digits) when preceded by "flight" or "flight number"
        # Use contextual regex to avoid capturing random numbers
        for match in self.numeric_flight_number_pattern.finditer(text):
            start, end = match.span()
            # Extract just the numeric part (group 1)
            entity_text = match.group(1)  # The captured digits only
            
            key = (start, end, EntityType.FLIGHT_NUMBER)
            if key not in seen:
                entities.append(Entity(
                    type=EntityType.FLIGHT_NUMBER,
                    text=entity_text,  # Store just the number (e.g., "5", "0", "2411")
                    start=start,
                    end=end
                ))
                seen.add(key)
        
        # Extract airport codes (case-insensitive, normalized to uppercase)
        # Filter out common English words that match 3-letter pattern
        common_words = {
            "THE", "ARE", "FOR", "AND", "BUT", "NOT", "YOU", "ALL", "CAN", "HER", "WAS", "ONE", "OUR", "OUT", "DAY", "GET", "HAS", "HIM", "HIS", "HOW", "ITS", "MAY", "NEW", "NOW", "OLD", "SEE", "TWO", "WHO", "WAY", "USE", "MAN", "MEN", "YEAR", "WELL", "SAID", "EACH", "WHICH", "THEIR", "TIME", "WILL", "ABOUT", "IF", "UP", "OUT", "MANY", "THEN", "THEM", "THESE", "SO", "SOME", "HER", "WOULD", "MAKE", "LIKE", "INTO", "HAS", "MORE", "VERY", "AFTER", "WORDS", "LONG", "THAN", "FIRST", "BEEN", "CALL", "WHO", "OIL", "ITS", "NOW", "FIND", "DOWN", "DAY", "DID", "GET", "MADE", "MAY", "PART", "OVER", "NEW", "SOUND", "TAKE", "ONLY", "LITTLE", "WORK", "KNOW", "PLACE", "YEAR", "LIVE", "ME", "BACK", "GIVE", "MOST", "VERY", "AFTER", "THING", "OUR", "JUST", "NAME", "GOOD", "SENTENCE", "MAN", "THINK", "SAY", "GREAT", "WHERE", "HELP", "THROUGH", "MUCH", "BEFORE", "LINE", "RIGHT", "TOO", "MEAN", "OLD", "ANY", "SAME", "TELL", "BOY", "FOLLOW", "CAME", "WANT", "SHOW", "ALSO", "AROUND", "FORM", "THREE", "SMALL", "SET", "PUT", "END", "DOES", "ANOTHER", "WELL", "LARGE", "MUST", "BIG", "EVEN", "SUCH", "BECAUSE", "TURN", "HERE", "WHY", "ASK", "WENT", "MEN", "READ", "NEED", "LAND", "DIFFERENT", "HOME", "US", "MOVE", "TRY", "KIND", "HAND", "PICTURE", "AGAIN", "CHANGE", "OFF", "PLAY", "SPELL", "AIR", "AWAY", "ANIMAL", "HOUSE", "POINT", "PAGE", "LETTER", "MOTHER", "ANSWER", "FOUND", "STUDY", "STILL", "LEARN", "SHOULD", "AMERICA", "WORLD", "HIGH", "EVERY", "NEAR", "ADD", "FOOD", "BETWEEN", "OWN", "BELOW", "COUNTRY", "PLANT", "LAST", "SCHOOL", "FATHER", "KEEP", "TREE", "NEVER", "START", "CITY", "EARTH", "EYE", "LIGHT", "THOUGHT", "HEAD", "UNDER", "STORY", "SAW", "LEFT", "DON'T", "FEW", "WHILE", "ALONG", "MIGHT", "CLOSE", "SOMETHING", "SEEM", "NEXT", "HARD", "OPEN", "EXAMPLE", "BEGIN", "LIFE", "ALWAYS", "THOSE", "BOTH", "PAPER", "TOGETHER", "GOT", "GROUP", "OFTEN", "RUN", "IMPORTANT", "UNTIL", "CHILDREN", "SIDE", "FEET", "CAR", "MILE", "NIGHT", "WALK", "WHITE", "SEA", "BEGAN", "GROW", "TOOK", "RIVER", "FOUR", "CARRY", "STATE", "ONCE", "BOOK", "HEAR", "STOP", "WITHOUT", "SECOND", "LATER", "MISS", "IDEA", "ENOUGH", "EAT", "FACE", "WATCH", "FAR", "INDIAN", "REALLY", "ALMOST", "LET", "ABOVE", "GIRL", "SOMETIMES", "MOUNTAIN", "CUT", "YOUNG", "TALK", "SOON", "LIST", "SONG", "LEAVE", "FAMILY", "IT'S"
        }
        
        for match in self.airport_code_pattern.finditer(text):
            start, end = match.span()
            entity_text = match.group().upper()  # Normalize to uppercase
            
            # Filter out common English words
            if entity_text in common_words:
                continue
            
            key = (start, end, EntityType.AIRPORT_CODE)
            if key not in seen:
                entities.append(Entity(
                    type=EntityType.AIRPORT_CODE,
                    text=entity_text,  # Already uppercase
                    start=start,
                    end=end
                ))
                seen.add(key)
        
        # Extract airline names (case-insensitive substring matching)
        text_lower = text.lower()
        for airline in self.airline_names:
            airline_lower = airline.lower()
            start = 0
            while True:
                idx = text_lower.find(airline_lower, start)
                if idx == -1:
                    break
                end = idx + len(airline)
                key = (idx, end, EntityType.AIRLINE)
                if key not in seen:
                    entities.append(Entity(
                        type=EntityType.AIRLINE,
                        text=text[idx:end],  # Preserve original case
                        start=idx,
                        end=end
                    ))
                    seen.add(key)
                start = idx + 1
        
        # Extract city names (case-insensitive substring matching)
        for city in self.city_names:
            city_lower = city.lower()
            start = 0
            while True:
                idx = text_lower.find(city_lower, start)
                if idx == -1:
                    break
                end = idx + len(city)
                key = (idx, end, EntityType.CITY)
                if key not in seen:
                    entities.append(Entity(
                        type=EntityType.CITY,
                        text=text[idx:end],  # Preserve original case
                        start=idx,
                        end=end
                    ))
                    seen.add(key)
                start = idx + 1
        
        # Sort entities by start position
        entities.sort(key=lambda e: e.start)
        return entities


if __name__ == "__main__":
    extractor = RuleBasedEntityExtractor()
    
    # Test cases
    test_sentences = [
        "What is the status of flight 2411?",
        "Find me a cheap flight with EgyptAir from Cairo to Paris.",
        "Give me info about flight 924",
        "Flight 12345 is delayed",  # 5 digits
        "The flight number 456 is on time",  # 3 digits
    ]
    
    for sentence in test_sentences:
        print(f"\nText: {sentence}")
        entities = extractor.extract(sentence)
        if entities:
            print("Extracted entities:")
            for entity in entities:
                print(f"  - {entity.type.value}: '{entity.text}' (position {entity.start}-{entity.end})")
        else:
            print("No entities found.")
