from neo4j import GraphDatabase
from .config import settings

# Single driver singleton for the entire application
_driver = None


def _get_driver():
    """Get or create the singleton Neo4j driver."""
    global _driver
    if _driver is None:
        _driver = GraphDatabase.driver(
            settings.NEO4J_URI,
            auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD)
        )
    return _driver


def close_driver():
    """Close the global driver (call on app shutdown)."""
    global _driver
    if _driver is not None:
        _driver.close()
        _driver = None


class Neo4jClient:
    def __init__(self):
        # Reuse the singleton driver
        self.driver = _get_driver()

    def close(self):
        # Don't close the global driver here - use close_driver() on app shutdown
        pass

    def run_query(self, query, params=None):
        params = params or {}
        with self.driver.session() as session:
            result = session.run(query, params)
            return [record.data() for record in result]


# Manual test
if __name__ == "__main__":
    client = Neo4jClient()
    res = client.run_query("MATCH (n) RETURN n LIMIT 3")
    print(res)
    client.close()
