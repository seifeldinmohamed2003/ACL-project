from __future__ import annotations

from typing import Any, Dict, List, Optional

from backend.preprocessing.intent_classifier import (
    RuleBasedIntentClassifier,
    IntentResult,
    Intent,
)
from backend.preprocessing.entity_extractor import (
    RuleBasedEntityExtractor,
    Entity,
    EntityType,
)
from backend.retrieval.baseline_queries import BaselineRetriever, QueryTemplate
from backend.retrieval.embedding_retrieval import semantic_retrieve
from backend.preprocessing.embeddings import EmbeddingService, EmbeddingBackend
from backend.neo4j_client import Neo4jClient
from backend.llm.model_client import LLMClient, LLMModel, get_available_models
from backend.llm.prompt_builder import build_prompt


# Singletons for now – simple and enough for the project
_intent_clf = RuleBasedIntentClassifier()
_entity_extractor = RuleBasedEntityExtractor()
_baseline_retriever = BaselineRetriever()
_embedding_service = EmbeddingService(EmbeddingBackend.SENTENCE_TRANSFORMER)
_semantic_client = Neo4jClient()  # Separate client for semantic search
_neo4j_client = Neo4jClient()  # Client for airport code validation


def _filter_valid_airport_codes(codes: List[str], question: str = "") -> List[str]:
    """
    Filter airport codes to only include those that exist in the Neo4j database.
    This removes false positives like "THE", "ARE", "FOR", etc.
    
    However, for route-shaped questions (e.g., "from CAI to LHR"), we preserve
    unknown codes so the correct route template is selected (even if it returns 0 rows).
    
    Args:
        codes: List of extracted airport codes (already uppercase)
        question: Original question text (to detect route-shaped queries)
        
    Returns:
        List of airport codes (valid ones, or all if route-shaped question)
    """
    if not codes:
        return []
    
    # Check if this is a route-shaped question or airport info question
    question_lower = question.lower()
    route_keywords = ["from", "to", "between", "route", "flights go", "go from"]
    airport_info_keywords = ["airport", "tell me about", "information about", "details about", "show me airport"]
    is_route_question = any(kw in question_lower for kw in route_keywords)
    is_airport_info_question = any(kw in question_lower for kw in airport_info_keywords)
    
    # For route questions with 2+ codes, preserve them even if unknown
    # This ensures the correct template is selected (best_route_by_airport_codes)
    # even if the airports don't exist in the dataset
    if is_route_question and len(codes) >= 2:
        # Still filter out obvious false positives (common English words)
        common_words = {"THE", "ARE", "FOR", "AND", "BUT", "NOT", "YOU", "ALL", "CAN", "HER", "WAS", "ONE", "OUR", "OUT", "DAY", "GET", "HAS", "HIM", "HIS", "HOW", "ITS", "MAY", "NEW", "NOW", "OLD", "SEE", "TWO", "WAY", "WHO", "BOY", "DID", "ITS", "LET", "PUT", "SAY", "SHE", "TOO", "USE"}
        filtered = [c for c in codes if c not in common_words]
        if len(filtered) >= 2:
            # Return all codes (even if unknown) for route questions
            # The template will return 0 rows if airports don't exist, which is correct
            return filtered
    
    # For airport info questions with 1 code, preserve it even if unknown
    # This ensures airport_basic_info is selected (returns 0 rows if airport doesn't exist)
    if is_airport_info_question and len(codes) == 1:
        common_words = {"THE", "ARE", "FOR", "AND", "BUT", "NOT", "YOU", "ALL", "CAN", "HER", "WAS", "ONE", "OUR", "OUT", "DAY", "GET", "HAS", "HIM", "HIS", "HOW", "ITS", "MAY", "NEW", "NOW", "OLD", "SEE", "TWO", "WAY", "WHO", "BOY", "DID", "ITS", "LET", "PUT", "SAY", "SHE", "TOO", "USE"}
        filtered = [c for c in codes if c not in common_words]
        if len(filtered) == 1:
            # Return the code (even if unknown) for airport info questions
            # The template will return 0 rows if airport doesn't exist, which is correct
            return filtered
    
    # For non-route questions, filter to only valid codes
    try:
        # Query Neo4j for valid airport codes
        query = "MATCH (a:Airport) WHERE a.station_code IN $codes RETURN a.station_code AS code"
        results = _neo4j_client.run_query(query, {"codes": list(set(codes))})
        valid_codes = {row["code"] for row in results}
        return [c for c in codes if c in valid_codes]
    except Exception as e:
        # If query fails, return original codes (better than filtering everything)
        print(f"[WARNING] Could not validate airport codes: {e}")
        return codes


def _template_summary(template: QueryTemplate | None) -> dict | None:
    if template is None:
        return None
    return {
        "id": template.id,
        "description": template.description,
        "intent": template.intent.value,
        "required_entity_types": [t.value for t in template.required_entity_types],
    }


# Templates that allow semantic expansion in "both" mode (exploratory/analytics queries)
# These are multi-row result sets where semantic can add useful context
SEMANTIC_EXPAND_ALLOWLIST = {
    "journey_patterns",
    "journey_leg_patterns",
    "analyze_passenger_journeys",
    "popular_routes_from_airport",
    "general_flights_from_city",
    # Note: low_satisfaction_journeys, high_satisfaction_journeys, high_delay_journeys
    # are NOT in allowlist - they return specific filtered results, semantic would add noise
}

# Maximum total rows to return (cap for semantic expansion)
MAX_TOTAL_ROWS = 20


def _deduplicate_rows(baseline_rows: List[Dict[str, Any]], semantic_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Deduplicate rows from baseline and semantic results.
    
    CRITICAL: Baseline rows are ALWAYS included (never dropped).
    Semantic rows are only added if they don't duplicate baseline rows.
    
    Deduplication keys (in priority order):
    1. _node_id (from semantic results)
    2. journey_id or feedback_ID
    3. (flight_number, origin_code, dest_code) tuple
    4. flight_number alone
    5. airport_code (for airport info queries)
    
    Returns combined list with duplicates removed (baseline rows take priority).
    """
    # CRITICAL: Always include ALL baseline rows first (they're the source of truth)
    result = list(baseline_rows)
    seen = set()
    
    # Build dedup keys for baseline rows
    def get_dedup_key(row: Dict[str, Any]) -> tuple | None:
        """Extract deduplication key from a row."""
        # Try _node_id first
        if "_node_id" in row:
            return ("node_id", row["_node_id"])
        # Try journey_id or feedback_ID
        elif "journey_id" in row:
            return ("journey_id", row["journey_id"])
        elif "feedback_ID" in row:
            return ("journey_id", row["feedback_ID"])
        # Try (flight_number, origin_code, dest_code) tuple
        elif "flight_number" in row and "origin_code" in row and "dest_code" in row:
            return ("route", str(row["flight_number"]), str(row.get("origin_code", "")), str(row.get("dest_code", "")))
        # Try flight_number alone
        elif "flight_number" in row:
            return ("flight", str(row["flight_number"]))
        # Try airport_code (for airport info)
        elif "airport_code" in row:
            return ("airport", str(row["airport_code"]))
        return None
    
    # Mark all baseline rows as seen (so semantic duplicates are filtered)
    for row in baseline_rows:
        dedup_key = get_dedup_key(row)
        if dedup_key:
            seen.add(dedup_key)
    
    # Then, add semantic rows that aren't duplicates of baseline
    for row in semantic_rows:
        dedup_key = get_dedup_key(row)
        if dedup_key is None or dedup_key not in seen:
            result.append(row)
            if dedup_key:
                seen.add(dedup_key)
    
    # Assertion: baseline rows must never be dropped
    assert len(result) >= len(baseline_rows), f"Deduplication bug: lost {len(baseline_rows) - len(result)} baseline rows!"
    
    return result


def process_query(
    question: str,
    retrieval_method: str = "baseline",
    llm_model: Optional[LLMModel] = None,
    use_llm: bool = False,
    debug: bool = False,
    force_intent: Optional[str] = None
) -> Dict[str, Any]:
    """
    End–to–end Graph-RAG pipeline with baseline and semantic retrieval:

    1. Classify intent.
    2. Extract entities.
    3. Select a Cypher template + params.
    4. Run baseline Neo4j retrieval (if enabled).
    5. Run semantic similarity search (if enabled).

    Args:
        question: User's question
        retrieval_method: One of "baseline", "semantic", or "both"
        debug: If True, print detailed debug trace of pipeline decisions
        
    Returns:
        Dictionary containing intent, entities, retrieval results, and messages
    """
    # 1) Extract entities first (needed for entity-based intent override)
    entities: List[Entity] = _entity_extractor.extract(question)
    
    # Normalize entities once
    for entity in entities:
        if entity.type == EntityType.FLIGHT_NUMBER:
            entity.text = str(entity.text)  # Ensure string
        elif entity.type == EntityType.AIRPORT_CODE:
            entity.text = entity.text.upper()  # Ensure uppercase
    
    # Filter valid airport codes (remove false positives like "THE", "ARE", etc.)
    # For route-shaped questions, preserve unknown codes so correct template is selected
    airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
    if airport_codes:
        valid_codes = _filter_valid_airport_codes(airport_codes, question=question)
        # Remove invalid airport code entities (but keep route-shaped unknown codes)
        entities = [e for e in entities if e.type != EntityType.AIRPORT_CODE or e.text in valid_codes]
        if debug and len(airport_codes) != len(valid_codes):
            print(f"[DEBUG] Filtered airport codes: {airport_codes} -> {valid_codes}")
    
    # Build entity map for debug output
    entity_map = {}
    for entity in entities:
        if entity.type not in entity_map:
            entity_map[entity.type] = []
        entity_map[entity.type].append(entity)
    
    # 2) Intent classification (with entity-based overrides)
    # Allow UI to force intent for disambiguation
    if force_intent:
        try:
            forced_intent = Intent(force_intent)
            intent_result = IntentResult(
                intent=forced_intent,
                confidence=0.95,  # High confidence for user-selected intent
                matched_keywords=["user_selected"]
            )
        except (ValueError, AttributeError):
            # Invalid intent, fall back to classification
            intent_result = _intent_clf.classify(question, entities=entities)
    else:
        intent_result = _intent_clf.classify(question, entities=entities)

    # 3) Template + params (for baseline)
    template, params = _baseline_retriever.select_template(
        intent_result.intent,
        entities,
        question=question
    )
    
    # 3a) Validate flight number if present (reject invalid inputs like 0, negative, or non-numeric)
    if "flight_number" in params:
        flight_num_str = str(params["flight_number"]).strip()
        # Validate format: 1-5 digits, positive integer
        import re
        if not re.match(r'^[1-9]\d{0,4}$', flight_num_str):
            # Invalid flight number format
            return {
                "intent": intent_result.intent.value if intent_result.intent else "UNKNOWN",
                "intent_confidence": intent_result.confidence,
                "entities": [{"type": e.type.value, "text": e.text} for e in entities],
                "template": _template_summary(template),
                "params": params,
                "num_rows": 0,
                "num_baseline_rows": 0,
                "num_semantic_rows": 0,
                "rows": [],
                "baseline_rows": [],
                "semantic_rows": [],
                "message": f"Invalid flight number: {params['flight_number']}. Flight numbers must be 1-5 digit positive integers (e.g., 42, 2411).",
                "error": {
                    "code": "INVALID_FLIGHT_NUMBER",
                    "message": "Flight number must be a 1-5 digit positive integer."
                }
            }
        try:
            flight_num_int = int(flight_num_str)
            if flight_num_int <= 0:
                # Invalid flight number - return error response
                return {
                    "intent": intent_result.intent.value if intent_result.intent else "UNKNOWN",
                    "intent_confidence": intent_result.confidence,
                    "entities": [{"type": e.type.value, "text": e.text} for e in entities],
                    "template": _template_summary(template),
                    "params": params,
                    "num_rows": 0,
                    "num_baseline_rows": 0,
                    "num_semantic_rows": 0,
                    "rows": [],
                    "baseline_rows": [],
                    "semantic_rows": [],
                    "message": f"Invalid flight number: {params['flight_number']}. Flight numbers must be positive integers.",
                    "error": {
                        "code": "INVALID_FLIGHT_NUMBER",
                        "message": "Flight number must be a positive integer."
                    }
                }
        except (ValueError, TypeError):
            # If flight_number can't be converted to int, that's also invalid
            return {
                "intent": intent_result.intent.value if intent_result.intent else "UNKNOWN",
                "intent_confidence": intent_result.confidence,
                "entities": [{"type": e.type.value, "text": e.text} for e in entities],
                "template": _template_summary(template),
                "params": params,
                "num_rows": 0,
                "num_baseline_rows": 0,
                "num_semantic_rows": 0,
                "rows": [],
                "baseline_rows": [],
                "semantic_rows": [],
                "message": f"Invalid flight number format: {params['flight_number']}. Flight numbers must be 1-5 digit positive integers.",
                "error": {
                    "code": "INVALID_FLIGHT_NUMBER",
                    "message": "Flight number must be a valid positive integer."
                }
            }
    
    # 3b) Validate airport codes if present (must be exactly 3 uppercase letters)
    airport_codes_in_params = []
    for key in ["origin_code", "dest_code", "airport_code"]:
        if key in params:
            code = str(params[key]).strip().upper()
            import re
            if not re.match(r'^[A-Z]{3}$', code):
                return {
                    "intent": intent_result.intent.value if intent_result.intent else "UNKNOWN",
                    "intent_confidence": intent_result.confidence,
                    "entities": [{"type": e.type.value, "text": e.text} for e in entities],
                    "template": _template_summary(template),
                    "params": params,
                    "num_rows": 0,
                    "num_baseline_rows": 0,
                    "num_semantic_rows": 0,
                    "rows": [],
                    "baseline_rows": [],
                    "semantic_rows": [],
                    "message": f"Invalid airport code: {code}. Airport codes must be exactly 3 letters (e.g., LAX, IAX). Try 'LAX to IAX' instead.",
                    "error": {
                        "code": "INVALID_AIRPORT_CODE",
                        "message": f"Airport code '{code}' is invalid. Must be exactly 3 uppercase letters."
                    }
                }
            airport_codes_in_params.append(code)
    
    # Debug trace output (ALWAYS print template selection for the 3 key questions)
    should_debug = debug or any(
        keyword in question.lower() 
        for keyword in ["operational insights", "most connections", "leg patterns"]
    )
    
    if should_debug:
        print("\n" + "=" * 70)
        print("=== DEBUG TRACE ===")
        print(f"Question: {question}")
        print(f"Entities: {[(e.type.value, e.text) for e in entities]}")
        print(f"Entity Map: {[(k.value, [e.text for e in v]) for k, v in entity_map.items()]}")
        print(f"Intent: {intent_result.intent.value} (confidence: {intent_result.confidence:.2f})")
        print(f"Matched keywords: {intent_result.matched_keywords}")
        print(f"[DEBUG] selected_template={template.id if template else None}, intent={intent_result.intent.value}, entities={[(k.value, [e.text for e in v]) for k, v in entity_map.items()]}")
        print(f"Template: {template.id if template else None}")
        print(f"Params: {params}")
        if template:
            print(f"\nCypher query (first 200 chars):")
            print(template.cypher[:200] + "..." if len(template.cypher) > 200 else template.cypher)
        print("=" * 70 + "\n")

    # 4) Baseline retrieval
    baseline_rows: List[Dict[str, Any]] = []
    message: str | None = None
    executed_cypher: str | None = None  # Initialize Cypher query for display
    
    if retrieval_method in ["baseline", "both"]:
        # Validation: Reject UNKNOWN intent and missing required entities
        if intent_result.intent == Intent.UNKNOWN:
            message = "I couldn't understand this query. Please try rephrasing with specific flight numbers, airport codes, or clearer intent."
        elif template is None:
            # No template selected - check if this is a city mapping failure
            # (cities were provided but couldn't be mapped to airport codes)
            if intent_result.intent == Intent.BEST_ROUTE:
                # Check if we have city entities that failed to map
                city_entities = [e for e in entities if e.type == EntityType.CITY]
                if len(city_entities) >= 2:
                    # This is a city-based route query - check if params contain mapping info
                    if params and "origin_city" in params and "dest_city" in params:
                        origin_city = params.get("origin_city", "")
                        dest_city = params.get("dest_city", "")
                        origin_code = params.get("origin_code_mapped")
                        dest_code = params.get("dest_code_mapped")
                        
                        if not origin_code and not dest_code:
                            message = f"**Route Not Available**\n\nThe cities '{origin_city.title()}' and '{dest_city.title()}' are not available in the current dataset. The knowledge graph doesn't contain route information for these cities.\n\n**Suggestions:**\n- Try using airport codes instead (e.g., 'LAX to IAX')\n- Check if the cities are spelled correctly\n- Query for routes between airports that exist in the dataset"
                        elif not origin_code:
                            message = f"**Route Not Available**\n\nThe origin city '{origin_city.title()}' is not available in the current dataset. The knowledge graph doesn't contain route information for this city.\n\n**Suggestions:**\n- Try using airport codes instead (e.g., 'LAX to IAX')\n- Check if the city name is spelled correctly"
                        elif not dest_code:
                            message = f"**Route Not Available**\n\nThe destination city '{dest_city.title()}' is not available in the current dataset. The knowledge graph doesn't contain route information for this city.\n\n**Suggestions:**\n- Try using airport codes instead (e.g., 'LAX to IAX')\n- Check if the city name is spelled correctly"
                        else:
                            message = f"**Route Not Found**\n\nNo flights found from {origin_city.title()} ({origin_code}) to {dest_city.title()} ({dest_code}) in the current dataset. This route may not be serviced or may not exist in the knowledge graph.\n\n**Suggestions:**\n- Try a different route\n- Check if the airport codes are correct"
                    else:
                        message = "Route queries require two airport codes or city names. Please specify origin and destination (e.g., 'from LAX to IAX' or 'from Cairo to London')."
                elif len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) < 2:
                    message = "Route queries require two airport codes. Please specify origin and destination (e.g., 'from LAX to IAX')."
                else:
                    message = "Could not find a suitable query template for this route request."
            elif intent_result.intent == Intent.FLIGHT_STATUS:
                if not any(e.type == EntityType.FLIGHT_NUMBER for e in entities):
                    message = "Flight status queries require a flight number. Please specify a flight number (e.g., 'flight 2411')."
                else:
                    message = "Could not find a suitable query template for this flight status request."
            elif intent_result.intent == Intent.AIRPORT_INFO:
                if not any(e.type in [EntityType.AIRPORT_CODE, EntityType.CITY] for e in entities):
                    message = "Airport information queries require an airport code or city name. Please specify an airport (e.g., 'LAX' or 'Los Angeles')."
                else:
                    message = "Could not find a suitable query template for this airport information request."
            else:
                message = "Could not process this query. Please check that you've provided the required information."
            executed_cypher = None
        elif template is not None:
            # Build the actual Cypher query with parameters substituted for display
            executed_cypher = template.cypher
            merged_params = {**(template.default_params or {}), **(params or {})}
            # Replace $param with actual values for display (simple substitution)
            import re
            for param_name, param_value in merged_params.items():
                if param_value is not None:
                    # Replace $param_name with actual value (string representation)
                    if isinstance(param_value, str):
                        executed_cypher = executed_cypher.replace(f"${param_name}", f"'{param_value}'")
                    else:
                        executed_cypher = executed_cypher.replace(f"${param_name}", str(param_value))
            
            try:
                # Use BaselineRetriever helper to merge default params and avoid ParameterMissing errors
                baseline_rows = _baseline_retriever.run_template(template, params)
                # Tag baseline rows with retrieval source
                for row in baseline_rows:
                    row["_retrieval_source"] = "baseline"
                if debug:
                    print(f"[DEBUG] Template '{template.id}' executed successfully, returned {len(baseline_rows)} rows")
            except Exception as e:
                print(f"[Cypher ERROR] template={template.id} params={params} error={e}")
                if debug:
                    import traceback
                    traceback.print_exc()
                baseline_rows = []
                message = f"Error executing query: {str(e)}"
            
            # Tag baseline rows with retrieval source
            for row in baseline_rows:
                row["_retrieval_source"] = "baseline"
            
            # Provide friendly message when no results found
            if len(baseline_rows) == 0 and message is None:
                # Generate context-aware messages based on intent and entities
                if intent_result.intent == Intent.BEST_ROUTE:
                    # Check if this was a city-based query that got mapped to airport codes
                    city_entities = [e for e in entities if e.type == EntityType.CITY]
                    if len(city_entities) >= 2:
                        # This was originally a city query - provide city-specific message
                        origin_city = city_entities[0].text
                        dest_city = city_entities[1].text
                        # Check if params contain airport codes (from mapping)
                        if params and "origin_code" in params and "dest_code" in params:
                            origin_code = params.get("origin_code")
                            dest_code = params.get("dest_code")
                            message = f"**Route Not Found**\n\nNo flights found from {origin_city.title()} ({origin_code}) to {dest_city.title()} ({dest_code}) in the current dataset. These airports may not exist in the knowledge graph, or this route may not be serviced.\n\n**Suggestions:**\n- Try a different route\n- Check if the airport codes ({origin_code}, {dest_code}) are correct\n- Query for routes between airports that exist in the dataset"
                        else:
                            message = f"**Route Not Found**\n\nNo flights found from {origin_city.title()} to {dest_city.title()} in the current dataset. This route may not be available in the knowledge graph.\n\n**Suggestions:**\n- Try using airport codes instead (e.g., 'LAX to IAX')\n- Check if the cities are spelled correctly"
                    elif len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) >= 2:
                        airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
                        message = f"**Route Not Found**\n\nNo flights found from {airport_codes[0]} to {airport_codes[1]} in the current dataset. These airports may not exist in the knowledge graph, or this route may not be serviced.\n\n**Suggestions:**\n- Try a different route\n- Check if the airport codes are correct\n- Query for routes between airports that exist in the dataset"
                    else:
                        message = "No route information found for this query. Please specify origin and destination (e.g., 'from LAX to IAX' or 'from Cairo to London')."
                elif intent_result.intent == Intent.FLIGHT_STATUS:
                    if any(e.type == EntityType.FLIGHT_NUMBER for e in entities):
                        flight_num = next((e.text for e in entities if e.type == EntityType.FLIGHT_NUMBER), None)
                        if flight_num:
                            message = f"Flight {flight_num} not found in the dataset. Please check the flight number and try again."
                    elif len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) >= 2:
                        airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
                        message = f"No flights found from {airport_codes[0]} to {airport_codes[1]}. These airports may not exist in the dataset."
                    else:
                        message = "No flight information found for this query."
                elif intent_result.intent == Intent.AIRPORT_INFO:
                    if any(e.type == EntityType.AIRPORT_CODE for e in entities):
                        airport_code = next((e.text for e in entities if e.type == EntityType.AIRPORT_CODE), None)
                        if airport_code:
                            message = f"Airport {airport_code} not found in the dataset. Please check the airport code and try again."
                    else:
                        message = "No airport information found for this query."
                elif intent_result.intent == Intent.BEST_ROUTE:
                    if len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) >= 2:
                        airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
                        message = f"No routes found from {airport_codes[0]} to {airport_codes[1]} in this dataset. "
                        message += f"These airport codes may not exist in the knowledge graph. "
                        message += f"Try using city names instead (e.g., 'Cairo to London' instead of 'CAI to LHR')."
                    else:
                        message = "No route information found for this query."
                elif intent_result.intent == Intent.PASSENGER_SATISFACTION:
                    if any(e.type == EntityType.FLIGHT_NUMBER for e in entities):
                        flight_num = next((e.text for e in entities if e.type == EntityType.FLIGHT_NUMBER), None)
                        if flight_num:
                            message = f"No satisfaction data found for flight {flight_num}. This flight may not exist or have no journey records."
                    else:
                        message = "No satisfaction data found for this query."
                elif intent_result.intent == Intent.DELAY_CAUSES:
                    if len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) >= 2:
                        airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
                        message = f"No delay data found for flights from {airport_codes[0]} to {airport_codes[1]}. This route may not exist in the dataset."
                    else:
                        message = "No delay information found for this query."
                else:
                    message = "No matching records found in the dataset for this query."
            
            # Check for "safe" template results that indicate "not found"
            if len(baseline_rows) > 0:
                first_row = baseline_rows[0]
                # Check for safe_flight_status_by_route flags
                if "origin_found" in first_row and "dest_found" in first_row:
                    if not first_row.get("origin_found", False) or not first_row.get("dest_found", False):
                        origin_code = first_row.get("origin_code", "?")
                        dest_code = first_row.get("dest_code", "?")
                        direct_flights = first_row.get("direct_flights", 0)
                        if direct_flights == 0:
                            message = f"No flights found from {origin_code} to {dest_code} in this dataset. "
                            if not first_row.get("origin_found", False):
                                message += f"Airport code {origin_code} not found in the knowledge graph. "
                            if not first_row.get("dest_found", False):
                                message += f"Airport code {dest_code} not found in the knowledge graph. "
                            message += "Try using city names instead (e.g., 'Cairo to London' instead of 'CAI to LHR')."

    # 5) Semantic retrieval (intent-aware with structured fallback)
    semantic_rows: List[Dict[str, Any]] = []
    
    # Initialize semantic gating flags so they are always defined
    has_flight_number = any(e.type == EntityType.FLIGHT_NUMBER for e in entities)
    has_airport_codes = len([e for e in entities if e.type == EntityType.AIRPORT_CODE]) >= 2
    strict_lookup = False  # default; may be updated below for valid structured queries
    # Gating flags for semantic so they're always defined before use
    should_gate_semantic = False
    gate_reason: Optional[str] = None
    
    if retrieval_method in ["semantic", "both"]:
        # CRITICAL: Pre-flight validation gate - skip semantic if inputs are invalid
        # This prevents semantic hallucination for invalid queries like "from invalid to code"
        has_invalid_inputs = False
        invalid_reason = None
        
        # Check for invalid airport codes in params
        if "origin_code" in params or "dest_code" in params:
            import re
            for param_key in ["origin_code", "dest_code"]:
                if param_key in params:
                    code = str(params[param_key]).strip().upper()
                    # Must be exactly 3 uppercase letters
                    if not re.match(r'^[A-Z]{3}$', code):
                        has_invalid_inputs = True
                        invalid_reason = f"Invalid airport code format: {code}. Must be exactly 3 letters (e.g., LAX, IAX)."
                        break
        
        # Check for invalid flight numbers
        if "flight_number" in params:
            flight_num_str = str(params["flight_number"]).strip()
            import re
            if not re.match(r'^[1-9]\d{0,4}$', flight_num_str):
                has_invalid_inputs = True
                invalid_reason = f"Invalid flight number: {flight_num_str}. Must be 1-5 digit positive integer."
        
        # CRITICAL: If template is None OR we have invalid inputs, skip semantic entirely
        # This prevents semantic from returning random results for invalid queries
        if template is None:
            # No template selected - skip semantic to avoid hallucination
            semantic_rows = []
            if message is None:
                # Generate helpful message based on intent
                if intent_result.intent == Intent.BEST_ROUTE:
                    message = "Route queries require valid 3-letter airport codes (e.g., LAX to IAX) or city names (e.g., Cairo to London)."
                elif intent_result.intent == Intent.FLIGHT_STATUS:
                    message = "Flight status queries require a valid flight number (e.g., flight 42)."
                else:
                    message = "Could not process this query. Please provide valid airport codes, flight numbers, or rephrase your question."
        elif has_invalid_inputs:
            # Template exists but params are invalid - skip semantic
            semantic_rows = []
            if message is None:
                message = invalid_reason or "Invalid input parameters. Please provide valid airport codes or flight numbers."
        else:
            # Inputs are valid and template exists, proceed with semantic retrieval logic
            # Structured fallback: If entities are present, use baseline even in semantic mode
            # Define strict_lookup: queries with hard constraints (entities) that require exact matches
            strict_lookup = any(k in (params or {}) for k in ("flight_number", "airport_code", "origin_code", "dest_code"))
        
        if has_flight_number and intent_result.intent == Intent.FLIGHT_STATUS:
            # For flight status queries with flight number, use baseline as fallback
            if retrieval_method == "semantic":
                # Run baseline query as structured fallback
                if template is not None:
                    semantic_rows = _baseline_retriever.run_template(template, params)
                    for row in semantic_rows:
                        row["_retrieval_source"] = "baseline_fallback"
                    # If baseline fallback returned 0, don't use semantic (structured query needs exact match)
                    # Returning random journeys for "flight 99999" would be misleading
                    if len(semantic_rows) == 0:
                        semantic_rows = []  # Return empty - flight not found
                else:
                    semantic_rows = []  # No template, return empty
            else:
                # "both" mode: only skip semantic if baseline actually returned something
                if len(baseline_rows) == 0:
                    # Baseline returned 0 - for structured FLIGHT_STATUS queries, don't use semantic fallback
                    # as it would return misleading random journeys
                    semantic_rows = []
                else:
                    # Baseline found results, skip semantic for FLIGHT_STATUS
                    semantic_rows = []
        elif has_airport_codes and intent_result.intent in [Intent.FLIGHT_STATUS, Intent.BEST_ROUTE, Intent.DELAY_CAUSES]:
            # For route queries with airport codes, use baseline as fallback
            # CRITICAL: Never use semantic for route queries (would return misleading random routes)
            if retrieval_method == "semantic":
                if template is not None:
                    semantic_rows = _baseline_retriever.client.run_query(template.cypher, params)
                    for row in semantic_rows:
                        row["_retrieval_source"] = "baseline_fallback"
                    # If baseline fallback returned 0, don't use semantic (structured query needs exact match)
                    if len(semantic_rows) == 0:
                        semantic_rows = []  # Return empty - route not found
                else:
                    semantic_rows = []  # No template, return empty
            else:
                # "both" mode: for route queries, never use semantic (baseline is the source of truth)
                # This prevents semantic from adding misleading random routes when baseline returns 0
                semantic_rows = []
        elif intent_result.intent == Intent.FLIGHT_STATUS:
            # FLIGHT_STATUS without entities: skip semantic
            semantic_rows = []
        else:
            # Intent-aware semantic retrieval with strict entity gating
            # Only use pure semantic for GENERAL_KG_QUERY (exploratory queries)
            # For other intents with entities, prefer structured lookup
            # If no template was selected, we already decided to skip semantic above
            if template is None:
                semantic_rows = []
            else:
                # Strict entity gating: check if strict identifiers exist before semantic retrieval
                if has_flight_number:
                    # Check if flight number exists
                    flight_num = next((e.text for e in entities if e.type == EntityType.FLIGHT_NUMBER), None)
                    if flight_num:
                        check_query = "MATCH (f:Flight {flight_number: $flight_number}) RETURN 1 AS exists LIMIT 1"
                        check_result = _baseline_retriever.client.run_query(check_query, {"flight_number": flight_num})
                        if not check_result:
                            should_gate_semantic = True
                            gate_reason = f"Flight {flight_num} not found"
                
                if not should_gate_semantic and has_airport_codes:
                    # Check if airport codes exist
                    airport_codes_list = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
                    if airport_codes_list:
                        check_query = "MATCH (a:Airport) WHERE a.station_code IN $codes RETURN count(a) AS count"
                        check_result = _baseline_retriever.client.run_query(check_query, {"codes": airport_codes_list})
                        found_count = check_result[0].get("count", 0) if check_result else 0
                        if found_count < len(airport_codes_list):
                            should_gate_semantic = True
                            gate_reason = f"Airport(s) {airport_codes_list} not found"
                
                # Single airport code for AIRPORT_INFO
                if not should_gate_semantic and intent_result.intent == Intent.AIRPORT_INFO:
                    single_airport = next((e.text for e in entities if e.type == EntityType.AIRPORT_CODE), None)
                    if single_airport:
                        check_query = "MATCH (a:Airport {station_code: $code}) RETURN 1 AS exists LIMIT 1"
                        check_result = _baseline_retriever.client.run_query(check_query, {"code": single_airport})
                        if not check_result:
                            should_gate_semantic = True
                            gate_reason = f"Airport {single_airport} not found"
                    
                if should_gate_semantic:
                    # Strict identifier doesn't exist - return empty (no random semantic results)
                    if debug:
                        print(f"[DEBUG] Semantic gated: {gate_reason}")
                    semantic_rows = []
                else:
                    # Check if template is non-expandable (should never use semantic)
                    non_expandable_templates_set = {
                        "low_satisfaction_journeys",
                        "high_satisfaction_journeys",
                        "high_delay_journeys",
                        "high_delay_low_satisfaction_journeys",  # Combined query - don't expand
                        "average_delays_by_route",
                        "early_arrival_journeys",  # Early-arrival / negative-delay journeys: specific filtered set, don't expand
                    }
                    is_non_expandable = template and template.id in non_expandable_templates_set
                    
                    use_pure_semantic = (
                        not is_non_expandable and  # Never use semantic for non-expandable templates
                        (intent_result.intent == Intent.GENERAL_KG_QUERY or
                         (intent_result.intent in [Intent.PASSENGER_SATISFACTION, Intent.DELAY_CAUSES] and 
                          not has_flight_number and not has_airport_codes))
                    )
                    
                    if use_pure_semantic:
                        # Use semantic retrieval for exploratory queries (lower threshold for broader results)
                        try:
                            semantic_rows = semantic_retrieve(
                                client=_semantic_client,
                                embedding_service=_embedding_service,
                                question=question,
                                top_k=5,
                                min_score=0.3  # Lower threshold for exploratory queries
                            )
                        except Exception as e:
                            print(f"Error in semantic retrieval: {e}")
                            semantic_rows = []
                    else:
                        # For structured intents (PASSENGER_SATISFACTION, DELAY_CAUSES, BEST_ROUTE) with entities
                        if retrieval_method == "semantic":
                            # Semantic-only mode: use baseline fallback for structured queries
                            if template is not None:
                                semantic_rows = _baseline_retriever.run_template(template, params)
                                for row in semantic_rows:
                                    row["_retrieval_source"] = "baseline_fallback"
                                # If baseline fallback returned 0, don't use semantic (strict identifiers need exact match)
                                if len(semantic_rows) == 0:
                                    semantic_rows = []  # Return empty - strict identifier not found
                            else:
                                # No template, return empty for structured queries
                                semantic_rows = []
                        elif retrieval_method == "both":
                            # Both mode: Hybrid policy
                            # Policy A (strict lookups): Never expand when hard constraints (entities) are present,
                            #   EXCEPT for templates explicitly in the semantic expand allowlist.
                            # Policy B (exploratory): Allow expansion only for allowlisted templates, with top-up cap.
                            
                            if len(baseline_rows) > 0:
                                # Baseline has results
                                if strict_lookup and not (template and template.id in SEMANTIC_EXPAND_ALLOWLIST):
                                    # Hard constraints present → never use semantic (baseline is source of truth),
                                    # unless this template is explicitly allowlisted.
                                    semantic_rows = []
                                elif template and template.id in SEMANTIC_EXPAND_ALLOWLIST:
                                    # Exploratory template in allowlist → allow semantic expansion (top-up to cap)
                                    try:
                                        # Calculate how many semantic rows we can add (top-up to MAX_TOTAL_ROWS)
                                        remaining_slots = max(0, MAX_TOTAL_ROWS - len(baseline_rows))
                                        if remaining_slots > 0:
                                            additional_semantic = semantic_retrieve(
                                                client=_semantic_client,
                                                embedding_service=_embedding_service,
                                                question=question,
                                                top_k=remaining_slots,  # Only fetch what we need
                                                min_score=0.4
                                            )
                                            semantic_rows = additional_semantic
                                        else:
                                            # Already at or above cap, no semantic needed
                                            semantic_rows = []
                                    except Exception as e:
                                        semantic_rows = []
                                else:
                                    # Non-allowlisted template with baseline results → disable semantic
                                    semantic_rows = []
                            elif len(baseline_rows) == 0 and not strict_lookup:
                                # Baseline empty AND not strict lookup → use semantic as fallback
                                try:
                                    semantic_rows = semantic_retrieve(
                                        client=_semantic_client,
                                        embedding_service=_embedding_service,
                                        question=question,
                                        top_k=MAX_TOTAL_ROWS,  # Use cap for fallback too
                                        min_score=0.4  # Moderate threshold for fallback
                                    )
                                    # Mark as "related examples" since baseline found nothing
                                    for row in semantic_rows:
                                        row["_is_related_example"] = True
                                except Exception as e:
                                    print(f"Error in semantic retrieval: {e}")
                                    semantic_rows = []
                            else:
                                # Baseline empty AND strict lookup → no semantic (would be misleading)
                                semantic_rows = []
    
    # Tag semantic rows with retrieval source (if not already tagged)
    for row in semantic_rows:
        row.setdefault("_retrieval_source", "semantic")
    
    # Semantic gating: Final check to disable semantic for specific template types
    # This runs AFTER semantic retrieval to ensure we don't add noise
    aggregate_templates = {
        "operational_insights",
        "journey_statistics",
        "overall_airline_performance",
        "airport_basic_info",  # Single airport info
        "airport_info_by_city",  # Single airport by city
    }
    
    # Non-allowlisted templates that should never use semantic when baseline has results
    # These return specific filtered results, semantic would add noise
    non_expandable_templates = {
        "low_satisfaction_journeys",
        "high_satisfaction_journeys",
        "high_delay_journeys",
        "high_delay_low_satisfaction_journeys",  # Combined query - don't expand
        "average_delays_by_route",
        "early_arrival_journeys",  # Early-arrival / negative-delay journeys: specific filtered set, don't expand
    }
    
    if template:
        if template.id in aggregate_templates:
            # For aggregate templates, disable semantic (they return single-row summaries)
            if retrieval_method == "both":
                semantic_rows = []  # Don't add semantic noise to aggregate results
            elif retrieval_method == "semantic":
                # Semantic-only mode: use baseline for aggregate templates
                semantic_rows = _baseline_retriever.client.run_query(template.cypher, params)
                for row in semantic_rows:
                    row["_retrieval_source"] = "baseline_fallback"
        elif template.id in non_expandable_templates and retrieval_method == "both":
            # For non-expandable templates, disable semantic when baseline has results
            # (These templates return specific filtered results, semantic would add noise)
            if len(baseline_rows) > 0:
                semantic_rows = []  # Disable semantic expansion for filtered result templates

    # Determine which rows to return based on retrieval method
    if retrieval_method == "baseline":
        rows = baseline_rows
    elif retrieval_method == "semantic":
        rows = semantic_rows
    else:  # "both"
        # Combine results with deduplication
        rows = _deduplicate_rows(baseline_rows, semantic_rows)
        
        # Apply top-up cap: limit total rows to MAX_TOTAL_ROWS
        # Baseline rows are always included, semantic rows are capped to fill remaining slots
        baseline_count = len(baseline_rows)
        if len(rows) > MAX_TOTAL_ROWS:
            # Separate baseline and semantic rows from deduplicated result
            baseline_in_result = [r for r in rows if r.get("_retrieval_source") != "semantic"]
            semantic_in_result = [r for r in rows if r.get("_retrieval_source") == "semantic"]
            
            # Ensure we have all baseline rows (safety check)
            if len(baseline_in_result) < baseline_count:
                # This shouldn't happen due to deduplication logic, but be safe
                baseline_in_result = baseline_rows[:MAX_TOTAL_ROWS]
                semantic_in_result = []
            else:
                # Calculate how many semantic rows we can keep
                semantic_to_keep = max(0, MAX_TOTAL_ROWS - len(baseline_in_result))
                if len(semantic_in_result) > semantic_to_keep:
                    semantic_in_result = semantic_in_result[:semantic_to_keep]
            
            # Rebuild: baseline + capped semantic
            rows = baseline_in_result + semantic_in_result
        
        # Assertion: baseline rows must never be dropped in "both" mode
        if len(baseline_rows) > 0:
            baseline_in_final = len([r for r in rows if r.get("_retrieval_source") != "semantic"])
            assert baseline_in_final >= len(baseline_rows), (
                f"BUG: Baseline rows dropped! "
                f"Baseline: {len(baseline_rows)}, In result: {baseline_in_final}, Total: {len(rows)}"
            )
        
        # Assertion: total rows should not exceed cap (unless baseline alone exceeds it)
        if len(baseline_rows) <= MAX_TOTAL_ROWS:
            assert len(rows) <= MAX_TOTAL_ROWS, (
                f"BUG: Total rows exceed cap! "
                f"Baseline: {len(baseline_rows)}, Semantic: {len(semantic_rows)}, Total: {len(rows)}, Cap: {MAX_TOTAL_ROWS}"
            )

    # 6) Entity faithfulness validation (for route queries)
    # If query has explicit airport codes, ensure returned rows match them
    if retrieval_method == "both" and len(rows) > 0:
        route_airport_codes = [e.text for e in entities if e.type == EntityType.AIRPORT_CODE]
        if len(route_airport_codes) >= 2:
            origin_code = route_airport_codes[0]
            dest_code = route_airport_codes[1]
            # Validate that semantic rows (if any) match the route
            # Baseline rows are already validated by the Cypher query
            filtered_rows = []
            for row in rows:
                if row.get("_retrieval_source") == "semantic":
                    # For semantic rows in route queries, they should be filtered or removed
                    # If they don't match the route, they're misleading
                    row_origin = row.get("origin_code") or row.get("origin")
                    row_dest = row.get("dest_code") or row.get("destination")
                    # If semantic row has route info and it doesn't match, it's a false positive
                    if row_origin and row_dest:
                        if row_origin != origin_code or row_dest != dest_code:
                            # This is a semantic false positive - skip it
                            if debug:
                                print(f"[DEBUG] Removed semantic false positive: {row_origin}->{row_dest} (expected {origin_code}->{dest_code})")
                            continue  # Skip this row
                filtered_rows.append(row)
            rows = filtered_rows
    
    # 7) LLM generation (if enabled)
    llm_response = None
    if use_llm and llm_model:
        # Short-circuit: Don't call LLM when no rows found (use deterministic message)
        if len(rows) == 0:
            # Use the message we already generated, or create a generic one
            if message:
                llm_response = {
                    "text": message
                }
            else:
                # Fallback deterministic message
                if intent_result.intent == Intent.BEST_ROUTE:
                    # Check if this was a city-based query that couldn't be mapped
                    if template is None and params:
                        origin_city = params.get("origin_city", "")
                        dest_city = params.get("dest_city", "")
                        origin_code = params.get("origin_code_mapped")
                        dest_code = params.get("dest_code_mapped")
                        
                        if origin_city and dest_city:
                            if not origin_code and not dest_code:
                                llm_response = {
                                    "text": f"**Route Not Available**\n\n"
                                    f"Sorry, the cities '{origin_city.title()}' and '{dest_city.title()}' are not available in the current dataset. "
                                    f"The knowledge graph doesn't contain route information for these cities.\n\n"
                                    f"**Suggestions:**\n"
                                    f"- Try using airport codes instead (e.g., 'LAX to IAX')\n"
                                    f"- Check if the cities are spelled correctly\n"
                                    f"- Query for routes between airports that exist in the dataset"
                                }
                            elif not origin_code:
                                llm_response = {
                                    "text": f"**Route Not Available**\n\n"
                                    f"Sorry, the origin city '{origin_city.title()}' is not available in the current dataset. "
                                    f"The knowledge graph doesn't contain route information for this city.\n\n"
                                    f"**Suggestions:**\n"
                                    f"- Try using airport codes instead (e.g., 'LAX to IAX')\n"
                                    f"- Check if the city name is spelled correctly"
                                }
                            elif not dest_code:
                                llm_response = {
                                    "text": f"**Route Not Available**\n\n"
                                    f"Sorry, the destination city '{dest_city.title()}' is not available in the current dataset. "
                                    f"The knowledge graph doesn't contain route information for this city.\n\n"
                                    f"**Suggestions:**\n"
                                    f"- Try using airport codes instead (e.g., 'LAX to IAX')\n"
                                    f"- Check if the city name is spelled correctly"
                                }
                            else:
                                # Both mapped but route doesn't exist
                                llm_response = {
                                    "text": f"**Route Not Found**\n\n"
                                    f"No flights found from {origin_city.title()} ({origin_code}) to {dest_city.title()} ({dest_code}) in the current dataset. "
                                    f"This route may not be serviced or may not exist in the knowledge graph.\n\n"
                                    f"**Suggestions:**\n"
                                    f"- Try a different route\n"
                                    f"- Check if the airport codes are correct"
                                }
                        else:
                            llm_response = {
                                "text": "No flights found for this route in the current dataset. Please try another route or confirm the airport codes exist."
                            }
                    else:
                        llm_response = {
                            "text": "No flights found for this route in the current dataset. Please try another route or confirm the airport codes exist."
                        }
                elif intent_result.intent == Intent.FLIGHT_STATUS:
                    llm_response = {
                        "text": "No flight information found for this query in the current dataset. Please check the flight number and try again."
                    }
                else:
                    llm_response = {
                        "text": "No records found for this query in the current dataset."
                    }
        else:
            # We have rows, proceed with LLM generation with automatic fallback
            llm_response = None
            models_to_try = [llm_model]
            
            # If we have multiple models available, add them as fallbacks
            available_models = get_available_models()
            if available_models:
                # Smart fallback order:
                # 1. Same provider, different model (e.g., DeepSeek -> Mistral on OpenRouter)
                # 2. Different provider, preferred models (OpenAI GPT-4o Mini, GPT-3.5)
                # 3. Other providers as last resort
                same_provider_models = [m for m in available_models if m.provider == llm_model.provider and m != llm_model]
                openai_models = [m for m in available_models if m.provider == "openai"]
                other_provider_models = [m for m in available_models if m.provider not in (llm_model.provider, "openai")]
                
                # Prioritize: same provider first, then OpenAI, then others
                models_to_try.extend(same_provider_models)
                models_to_try.extend(openai_models)
                models_to_try.extend(other_provider_models)
            
            # Try each model until one succeeds (limit to 5 attempts)
            last_error = None
            for i, model_attempt in enumerate(models_to_try[:5]):
                try:
                    # Build prompt with context (only once, reuse for all attempts)
                    if i == 0:
                        # CRITICAL: Assert that if we have rows, they're passed to the prompt
                        if len(rows) > 0 and len(baseline_rows) == 0:
                            if debug:
                                print(f"[DEBUG] WARNING: total_rows={len(rows)} but baseline_rows is empty!")
                        if len(baseline_rows) > 0 and debug:
                            print(f"[DEBUG] Building prompt with {len(baseline_rows)} baseline rows, first row keys: {list(baseline_rows[0].keys())[:5]}")
                        
                        system_prompt, user_prompt = build_prompt(
                            question=question,
                            baseline_rows=baseline_rows,
                            semantic_rows=semantic_rows,
                            intent=intent_result.intent.value,
                            total_rows=len(rows),
                            num_baseline_rows=len(baseline_rows),
                            template_id=template.id if template else None
                        )
                    
                    # Generate LLM response
                    llm_client = LLMClient(model_attempt)
                    llm_response = llm_client.generate(
                        prompt=user_prompt,
                        system_prompt=system_prompt,
                        temperature=0.7,
                        max_tokens=300  # Reduced from 500 for more concise responses
                    )
                    
                    # Check if response has an error
                    if llm_response.get("error"):
                        # This model failed, try next one
                        last_error = llm_response.get("error")
                        error_str = str(last_error).lower()
                        if debug:
                            print(f"[DEBUG] Model {model_attempt.display_name} failed: {last_error}, trying next model...")
                        # If it's a rate limit, definitely try next model
                        if "429" in str(last_error) or "rate limit" in error_str:
                            continue
                        # For other errors, also try next model
                        continue
                    
                    # Success! Now check for grounding consistency and empty responses
                    llm_text = llm_response.get("text", "").strip()
                    
                    # Check if response is too short or empty (likely a truncated/bad response)
                    if len(llm_text) < 20:
                        # Response is suspiciously short - might be truncated or error
                        if debug:
                            print(f"[DEBUG] LLM response too short ({len(llm_text)} chars), treating as failed")
                        last_error = "Response too short or empty"
                        continue  # Try next model
                    
                    llm_text_lower = llm_text.lower()
                    
                    # CRITICAL: Grounding guard - detect contradictions
                    no_results_patterns = [
                        "no records found", "not found", "0 results", "no data found",
                        "no information found", "no flights found", "no routes found",
                        "cannot find", "does not exist", "empty", "no matching"
                    ]
                    has_no_results_claim = any(pattern in llm_text_lower for pattern in no_results_patterns)
                    
                    if len(rows) > 0 and has_no_results_claim:
                        # LLM contradicted the data - override with deterministic response
                        if debug:
                            print(f"[DEBUG] GROUNDING GUARD: LLM said 'no results' but we have {len(rows)} rows. Overriding response.")
                        
                        # Generate deterministic response based on template and rows
                        if template:
                            template_id = template.id
                            if template_id == "best_route_by_airport_codes":
                                origin = params.get("origin_code", "?")
                                dest = params.get("dest_code", "?")
                                llm_response["text"] = f"Found {len(rows)} flight(s) from {origin} to {dest}:\n\n"
                                for i, row in enumerate(rows[:10], 1):
                                    flight_num = row.get("flight_number", "?")
                                    aircraft = row.get("aircraft_type", "?")
                                    llm_response["text"] += f"{i}. Flight {flight_num} ({aircraft})\n"
                            elif template_id == "best_route_by_city":
                                # Special handling for city-based routes (data limitation)
                                origin_city = params.get("origin_city", "origin")
                                dest_city = params.get("dest_city", "destination")
                                llm_response["text"] = f"**Route Analysis: {origin_city.title()} to {dest_city.title()}**\n\n"
                                llm_response["text"] += f"The dataset contains {len(rows)} journey(s) that may serve this route. "
                                llm_response["text"] += "Note: The dataset doesn't include explicit city-to-city route mapping, "
                                llm_response["text"] += "so these are sample journeys from the knowledge graph:\n\n"
                                for i, row in enumerate(rows[:5], 1):
                                    journey_id = row.get("journey_id", "?")
                                    legs = row.get("number_of_legs", "?")
                                    delay = row.get("arrival_delay_minutes", "?")
                                    satisfaction = row.get("food_satisfaction_score", "?")
                                    llm_response["text"] += f"{i}. Journey {journey_id}: {legs} leg(s), "
                                    llm_response["text"] += f"delay: {delay} min, satisfaction: {satisfaction}/5\n"
                            elif template_id in ["low_satisfaction_journeys", "high_satisfaction_journeys", "high_delay_journeys"]:
                                template_name = template_id.replace("_", " ").title()
                                llm_response["text"] = f"Found {len(rows)} {template_name}:\n\n"
                                for i, row in enumerate(rows[:10], 1):
                                    journey_id = row.get("journey_id") or row.get("feedback_ID", "?")
                                    if "satisfaction" in template_id:
                                        score = row.get("food_satisfaction_score", "?")
                                        llm_response["text"] += f"{i}. Journey {journey_id} - Satisfaction: {score}\n"
                                    elif "delay" in template_id:
                                        delay = row.get("arrival_delay_minutes", "?")
                                        llm_response["text"] += f"{i}. Journey {journey_id} - Delay: {delay} minutes\n"
                            else:
                                # Generic fallback - but make it more informative
                                llm_response["text"] = f"**Query Results:**\n\n"
                                llm_response["text"] += f"Found {len(rows)} result(s) in the knowledge graph:\n\n"
                                for i, row in enumerate(rows[:5], 1):
                                    # Show key fields in a readable format
                                    key_fields = {k: v for k, v in list(row.items())[:4] if not k.startswith("_")}
                                    llm_response["text"] += f"**Result {i}:**\n"
                                    for key, value in key_fields.items():
                                        llm_response["text"] += f"  - {key.replace('_', ' ').title()}: {value}\n"
                                    llm_response["text"] += "\n"
                        else:
                            # No template, generic response
                            llm_response["text"] = f"Found {len(rows)} result(s) in the dataset."
                        
                        llm_response["grounding_override"] = True
                        llm_response["original_llm_text"] = llm_response.get("text", "")
                    
                    # Track model usage
                    if model_attempt != llm_model:
                        if debug:
                            print(f"[DEBUG] Primary model {llm_model.display_name} failed, successfully used fallback: {model_attempt.display_name}")
                        # Update the model info in response
                        llm_response["fallback_model"] = model_attempt.display_name
                        llm_response["fallback_used"] = True
                        llm_response["original_model"] = llm_model.display_name
                    else:
                        llm_response["fallback_used"] = False
                    
                    # Add explicit model tracking
                    llm_response["model_requested"] = llm_model.display_name
                    llm_response["model_used"] = model_attempt.display_name
                    if llm_response.get("error"):
                        llm_response["fallback_reason"] = str(llm_response.get("error"))
                    
                    break
                    
                except Exception as e:
                    # This model failed, try next one
                    last_error = str(e)
                    if debug:
                        print(f"[DEBUG] Model {model_attempt.display_name} raised exception: {e}, trying next model...")
                    # Continue to next model unless this is the last one
                    if i == len(models_to_try[:5]) - 1:
                        # Last model failed, we'll set error below
                        pass
                    continue
            
            # If all models failed and we don't have a response yet, use intelligent fallback
            if not llm_response or llm_response.get("error") or (llm_response.get("text", "").strip() == ""):
                # Generate intelligent fallback based on template and data
                if template and len(rows) > 0:
                    template_id = template.id
                    if template_id == "best_route_by_city":
                        origin_city = params.get("origin_city", "origin") if params else "origin"
                        dest_city = params.get("dest_city", "destination") if params else "destination"
                        llm_response = {
                            "text": f"**Route Analysis: {origin_city.title()} to {dest_city.title()}**\n\n"
                            f"The knowledge graph contains {len(rows)} journey record(s) that may be relevant to this route. "
                            f"Note: The dataset doesn't include explicit city-to-city route mapping, so these are sample journeys:\n\n"
                        }
                        for i, row in enumerate(rows[:5], 1):
                            journey_id = row.get("journey_id", "?")
                            legs = row.get("number_of_legs", "?")
                            delay = row.get("arrival_delay_minutes", "?")
                            satisfaction = row.get("food_satisfaction_score", "?")
                            llm_response["text"] += f"{i}. **Journey {journey_id}**: {legs} leg(s), "
                            if delay and delay != "?":
                                delay_str = f"{delay} min" if delay >= 0 else f"{abs(delay)} min early"
                                llm_response["text"] += f"arrival: {delay_str}, "
                            if satisfaction and satisfaction != "?":
                                llm_response["text"] += f"satisfaction: {satisfaction}/5\n"
                            else:
                                llm_response["text"] += "\n"
                        llm_response["grounding_override"] = True
                    elif template_id == "best_route_by_airport_codes":
                        origin = params.get("origin_code", "?") if params else "?"
                        dest = params.get("dest_code", "?") if params else "?"
                        llm_response = {
                            "text": f"**Route: {origin} to {dest}**\n\n"
                            f"Found {len(rows)} flight(s) operating on this route:\n\n"
                        }
                        for i, row in enumerate(rows[:10], 1):
                            flight_num = row.get("flight_number", "?")
                            aircraft = row.get("aircraft_type", "?")
                            llm_response["text"] += f"{i}. Flight {flight_num} ({aircraft})\n"
                        llm_response["grounding_override"] = True
                    else:
                        # Generic intelligent fallback
                        llm_response = {
                            "text": f"**Query Results**\n\n"
                            f"Found {len(rows)} result(s) in the knowledge graph:\n\n"
                        }
                        for i, row in enumerate(rows[:5], 1):
                            key_fields = {k: v for k, v in list(row.items())[:4] if not k.startswith("_")}
                            llm_response["text"] += f"**Result {i}:**\n"
                            for key, value in key_fields.items():
                                llm_response["text"] += f"  - {key.replace('_', ' ').title()}: {value}\n"
                            llm_response["text"] += "\n"
                        llm_response["grounding_override"] = True
                else:
                    # No template or no rows - use error message
                    llm_response = {
                        "text": f"Error generating LLM response: All available models failed. Last error: {last_error or 'Unknown error'}. Please check your API keys and try again.",
                        "error": last_error or "All models failed",
                        "models_attempted": len(models_to_try[:5])
                    }

    return {
        "question": question,
        "intent": intent_result.intent.value,
        "intent_confidence": intent_result.confidence,
        "matched_keywords": intent_result.matched_keywords,
        "entities": [
            {
                "type": e.type.value,
                "text": e.text,
                "start": e.start,
                "end": e.end,
            }
            for e in entities
        ],
        "template": _template_summary(template),
        "params": params,
        "executed_cypher": executed_cypher if 'executed_cypher' in locals() and executed_cypher else None,
        "retrieval_method": retrieval_method,
        "num_rows": len(rows),
        "rows": rows,
        "baseline_rows": baseline_rows,
        "semantic_rows": semantic_rows,
        "num_baseline_rows": len(baseline_rows),
        "num_semantic_rows": len(semantic_rows),
        "message": message,
        "llm_response": llm_response,
        "llm_model": llm_model.display_name if llm_model else None,
    }


if __name__ == "__main__":
    # Test with debug trace
    test_questions = [
        "What flights go from CAI to LHR?",
        "What is airport IAX?",
        "What is the status of flight 2411?",
    ]
    
    for q in test_questions:
        print(f"\n{'='*70}")
        result = process_query(q, retrieval_method="baseline", debug=True)
        print(f"Result: {len(result.get('baseline_rows', []))} rows")
        if result.get('message'):
            print(f"Message: {result['message']}")
        print()
