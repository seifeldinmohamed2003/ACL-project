-- Neo4j Performance Indexes
-- Run these in Neo4j Browser or via cypher-shell to improve query performance

-- Flight number index (most common lookup)
CREATE INDEX flight_number_index IF NOT EXISTS
FOR (f:Flight) ON (f.flight_number);

-- Airport station code index (route queries)
CREATE INDEX airport_station_code_index IF NOT EXISTS
FOR (a:Airport) ON (a.station_code);

-- Journey delay index (for delay filtering)
CREATE INDEX journey_delay_index IF NOT EXISTS
FOR (j:Journey) ON (j.arrival_delay_minutes);

-- Journey satisfaction index (for satisfaction filtering)
CREATE INDEX journey_satisfaction_index IF NOT EXISTS
FOR (j:Journey) ON (j.food_satisfaction_score);

-- Composite index for common Journey filters
CREATE INDEX journey_delay_satisfaction_index IF NOT EXISTS
FOR (j:Journey) ON (j.arrival_delay_minutes, j.food_satisfaction_score);

-- Verify indexes were created
SHOW INDEXES;
