# System Architecture - Airline Graph-RAG

## Overview

The Airline Graph-RAG system is an end-to-end pipeline that combines Knowledge Graph retrieval with Large Language Models to answer questions about airline data.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER INTERFACE                          │
│                        (Streamlit UI)                           │
│  - Question Input                                               │
│  - Retrieval Method Selection (Baseline/Semantic/Both)         │
│  - LLM Model Selection                                          │
│  - Results Display                                              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    INPUT PREPROCESSING                          │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐ │
│  │ Intent           │  │ Entity          │  │ Input        │ │
│  │ Classification   │→ │ Extraction      │→ │ Embedding    │ │
│  │ (Rule-based)     │  │ (NER)           │  │ (Optional)   │ │
│  └──────────────────┘  └──────────────────┘  └──────────────┘ │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    GRAPH RETRIEVAL LAYER                        │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │              BASELINE RETRIEVAL                          │ │
│  │  - Intent + Entities → Template Selection                │ │
│  │  - Parameterize Cypher Query                             │ │
│  │  - Execute in Neo4j                                      │ │
│  │  - Return Structured Results                             │ │
│  └──────────────────────────────────────────────────────────┘ │
│                             │                                   │
│                             ▼                                   │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │           SEMANTIC RETRIEVAL                              │ │
│  │  - Embed User Question                                    │ │
│  │  - Vector Similarity Search in Neo4j                      │ │
│  │  - Return Top-K Similar Nodes                             │ │
│  └──────────────────────────────────────────────────────────┘ │
│                             │                                   │
│                             ▼                                   │
│                    COMBINE RESULTS                              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                        LLM LAYER                                │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐ │
│  │ Prompt           │  │ LLM              │  │ Response     │ │
│  │ Builder          │→ │ Generation       │→ │ Processing   │ │
│  │ (Context +       │  │ (OpenAI/         │  │ (Format +    │ │
│  │  Persona + Task) │  │  OpenRouter/     │  │  Display)    │ │
│  │                  │  │  HuggingFace)     │  │              │ │
│  └──────────────────┘  └──────────────────┘  └──────────────┘ │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      KNOWLEDGE GRAPH                            │
│                        (Neo4j)                                  │
│  - Flight Nodes (flight_number, fleet_type_description)         │
│  - Airport Nodes (station_code)                                 │
│  - Passenger Nodes (record_locator, loyalty_program_level)      │
│  - Journey Nodes (feedback_ID, passenger_class, delays, etc.)   │
│  - Vector Index (journey_embeddings)                            │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Input Preprocessing

#### Intent Classifier
- **File:** `backend/preprocessing/intent_classifier.py`
- **Method:** Rule-based keyword matching
- **Intents:** FLIGHT_STATUS, BEST_ROUTE, AIRLINE_INFO, AIRPORT_INFO, PASSENGER_SATISFACTION, DELAY_CAUSES, GENERAL_KG_QUERY
- **Output:** `IntentResult` with intent and confidence score

#### Entity Extractor
- **File:** `backend/preprocessing/entity_extractor.py`
- **Method:** Rule-based NER with regex patterns
- **Entities:** FLIGHT_NUMBER, AIRPORT_CODE, CITY, AIRLINE
- **Output:** List of `Entity` objects with type, text, position

#### Input Embedding (for Semantic Retrieval)
- **File:** `backend/preprocessing/embeddings.py`
- **Model:** SentenceTransformer (`all-MiniLM-L6-v2`)
- **Dimensions:** 384
- **Usage:** Embed user question for vector similarity search

### 2. Graph Retrieval Layer

#### Baseline Retrieval
- **File:** `backend/retrieval/baseline_queries.py`
- **Components:**
  - `QueryTemplate`: Dataclass with Cypher query and metadata
  - `BASELINE_TEMPLATES`: Dictionary of 12 query templates
  - `BaselineRetriever`: Selects template and executes query
- **Process:**
  1. Match intent and entities to template
  2. Parameterize Cypher query
  3. Execute in Neo4j
  4. Return structured results

#### Semantic Retrieval
- **File:** `backend/retrieval/embedding_retrieval.py`
- **Components:**
  - `create_text_representation()`: Converts node to text
  - `generate_and_store_embeddings()`: Creates embeddings for nodes
  - `create_vector_index()`: Creates Neo4j vector index
  - `semantic_retrieve()`: Performs similarity search
- **Process:**
  1. Embed user question
  2. Vector similarity search in Neo4j
  3. Return top-K similar nodes with scores

### 3. LLM Layer

#### Prompt Builder
- **File:** `backend/llm/prompt_builder.py`
- **Components:**
  - `format_context()`: Formats retrieval results
  - `build_prompt()`: Creates structured prompt
- **Structure:**
  - **Context:** Baseline + Semantic results
  - **Persona:** "You are a helpful airline information assistant..."
  - **Task:** Instructions to use only provided context

#### Model Client
- **File:** `backend/llm/model_client.py`
- **Providers:** OpenAI, HuggingFace, OpenRouter
- **Models:** 10+ models available
- **Features:**
  - Unified interface for all providers
  - Error handling and fallbacks
  - Token usage tracking
  - Response time measurement

### 4. Pipeline Orchestration

- **File:** `backend/pipeline.py`
- **Function:** `process_query()`
- **Process:**
  1. Intent classification
  2. Entity extraction
  3. Baseline retrieval (if enabled)
  4. Semantic retrieval (if enabled)
  5. Combine results
  6. LLM generation (if enabled)
  7. Return complete result

### 5. User Interface

- **File:** `ui/app.py`
- **Framework:** Streamlit
- **Features:**
  - Question input
  - Retrieval method selection
  - LLM model selection
  - Results display (baseline, semantic, LLM answer)
  - Token usage and response time
  - Error handling with helpful messages

## Data Flow

```
User Question
    ↓
Intent Classification → Intent (FLIGHT_STATUS, etc.)
    ↓
Entity Extraction → Entities (flight_number: 2411, etc.)
    ↓
┌─────────────────────────────────────┐
│   BASELINE RETRIEVAL               │
│   Template Selection               │
│   Cypher Query Execution           │
│   → baseline_rows                  │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│   SEMANTIC RETRIEVAL                │
│   Question Embedding                │
│   Vector Similarity Search          │
│   → semantic_rows                   │
└─────────────────────────────────────┘
    ↓
Combine Results → Combined Context
    ↓
┌─────────────────────────────────────┐
│   LLM GENERATION                    │
│   Build Prompt (Context+Persona+Task)│
│   Generate Answer                   │
│   → llm_response                    │
└─────────────────────────────────────┘
    ↓
Display Results in UI
```

## Technology Stack

- **Database:** Neo4j (Knowledge Graph)
- **Embeddings:** SentenceTransformer (all-MiniLM-L6-v2)
- **LLM Providers:** OpenAI, OpenRouter, HuggingFace
- **UI Framework:** Streamlit
- **Language:** Python 3.13
- **Key Libraries:**
  - `neo4j` - Neo4j driver
  - `sentence-transformers` - Embeddings
  - `openai` - OpenAI API
  - `huggingface_hub` - HuggingFace API
  - `streamlit` - UI framework

## File Structure

```
airline_graph_rag/
├── backend/
│   ├── config.py              # Configuration (API keys, Neo4j settings)
│   ├── neo4j_client.py        # Neo4j connection and query execution
│   ├── pipeline.py            # Main orchestration pipeline
│   ├── preprocessing/
│   │   ├── intent_classifier.py    # Intent classification
│   │   ├── entity_extractor.py     # Entity extraction
│   │   └── embeddings.py           # Embedding generation
│   ├── retrieval/
│   │   ├── baseline_queries.py     # Cypher query templates
│   │   └── embedding_retrieval.py  # Semantic retrieval
│   └── llm/
│       ├── model_client.py          # LLM client (multi-provider)
│       └── prompt_builder.py        # Structured prompt creation
├── ui/
│   └── app.py                 # Streamlit UI
└── tests/                     # Test scripts
```

## Key Design Decisions

1. **Modular Architecture:** Each component is independent and testable
2. **Multiple Retrieval Methods:** Baseline (exact) + Semantic (similarity)
3. **Multi-Provider LLM Support:** OpenAI, OpenRouter, HuggingFace
4. **Structured Prompts:** Context + Persona + Task for better grounding
5. **Error Handling:** Graceful degradation with helpful error messages
6. **Free Model Support:** OpenRouter free models for no-cost testing

## Integration Points

1. **Neo4j Connection:** `Neo4jClient` handles all database interactions
2. **Embedding Service:** Singleton `EmbeddingService` for consistency
3. **LLM Client:** Factory pattern for different providers
4. **Pipeline:** Central orchestration point

## Performance Considerations

- **Embedding Generation:** Batch processing for efficiency
- **Vector Index:** Neo4j vector index for fast similarity search
- **Caching:** Embeddings stored in Neo4j (no regeneration needed)
- **Timeout Handling:** 10-second timeout for LLM API calls

## Scalability

- **Horizontal:** Can add more Neo4j instances
- **Vertical:** Can scale embedding generation with batch size
- **LLM:** Multiple providers allow load distribution
