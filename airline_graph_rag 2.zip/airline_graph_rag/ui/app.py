import sys
import os
from pathlib import Path

# CRITICAL: Set environment variables BEFORE any other imports
os.environ["STREAMLIT_SERVER_FILE_WATCHER_TYPE"] = "none"
os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["PYTHONWARNINGS"] = "ignore"

import warnings
warnings.filterwarnings("ignore")
warnings.simplefilter("ignore")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import streamlit as st
import html
import re
from backend.pipeline import process_query
from backend.neo4j_client import Neo4jClient
from backend.llm.model_client import LLMModel, get_available_models


def is_ambiguous_route_query(query: str) -> bool:
    """
    Detect if a query is ambiguous (route-like but unclear intent).
    
    Examples:
    - "I want to travel from cairo to london" -> ambiguous
    - "I want to go from cairo to london" -> ambiguous
    - "What is the best route from cairo to london" -> clear (BEST_ROUTE)
    - "What is the status of flights from cairo to london" -> clear (FLIGHT_STATUS)
    """
    query_lower = query.lower().strip()
    
    # Route-like patterns (user wants to travel/go/fly between places)
    ambiguous_patterns = [
        r"i\s+want\s+to\s+(travel|go|fly)\s+from",
        r"want\s+to\s+(travel|go|fly)\s+from",
        r"travel\s+from\s+\w+\s+to\s+\w+",
        r"go\s+from\s+\w+\s+to\s+\w+",
        r"fly\s+from\s+\w+\s+to\s+\w+",
        r"from\s+\w+\s+to\s+\w+",  # Simple "from X to Y" without clear intent
    ]
    
    has_ambiguous_pattern = any(re.search(pattern, query_lower) for pattern in ambiguous_patterns)
    
    # Clear intent keywords that make it unambiguous
    clear_intent_keywords = [
        "best route", "cheapest", "shortest", "fastest", "optimal route",
        "flight status", "status of", "track flight", "is flight",
        "what flights", "show flights", "find flights", "which flights",
        "routes between", "flights between"
    ]
    
    has_clear_intent = any(keyword in query_lower for keyword in clear_intent_keywords)
    
    # Ambiguous if has route pattern but no clear intent keywords
    return has_ambiguous_pattern and not has_clear_intent


def extract_kg_structure(cypher_query: str, params: dict) -> dict:
    """
    Extract nodes and relationships from a Cypher query string.
    
    Returns:
        dict with 'nodes' and 'relationships' lists
    """
    if not cypher_query:
        return {"nodes": [], "relationships": []}
    
    nodes = set()
    relationships = set()
    
    # Extract node labels: MATCH (f:Flight), (a:Airport), etc.
    node_pattern = r'\([^:]*:([A-Za-z][A-Za-z0-9_]*)\)'
    node_matches = re.findall(node_pattern, cypher_query)
    nodes.update(node_matches)
    
    # Extract relationship types: -[:ON]->, -[:DEPARTS_FROM]->, etc.
    rel_pattern = r'-\[:([A-Za-z][A-Za-z0-9_]*)\]->'
    rel_matches = re.findall(rel_pattern, cypher_query)
    relationships.update(rel_matches)
    
    # Also check for bidirectional relationships: <-[:REL]->
    rel_pattern_bidir = r'<-\[:([A-Za-z][A-Za-z0-9_]*)\]->'
    rel_matches_bidir = re.findall(rel_pattern_bidir, cypher_query)
    relationships.update(rel_matches_bidir)
    
    # Count actual instances from params and results
    node_counts = {}
    if params:
        if "flight_number" in params:
            node_counts["Flight"] = 1
        if "airport_code" in params:
            node_counts["Airport"] = 1
        if "origin_code" in params and "dest_code" in params:
            node_counts["Airport"] = 2
    
    return {
        "nodes": sorted(list(nodes)),
        "relationships": sorted(list(relationships)),
        "node_counts": node_counts
    }

# ============================================================================
# Professional UI Styling
# ============================================================================

st.set_page_config(
    page_title="Airline Operations Intelligence",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for professional design
st.markdown("""
<style>
    /* Main container styling */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    
    /* Header styling */
    .main-header {
        border-bottom: 2px solid #1f77b4;
        padding-bottom: 1rem;
        margin-bottom: 2rem;
    }
    
    /* Card-like containers */
    .result-card {
        background-color: #f8f9fa;
        border-left: 4px solid #1f77b4;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    
    /* Answer display */
    .answer-container {
        background-color: #ffffff;
        padding: 1.5rem;
        border-radius: 0.5rem;
        border: 1px solid #e0e0e0;
        margin: 1rem 0;
        line-height: 1.6;
        white-space: pre-wrap;
        word-wrap: break-word;
    }
    
    /* Metric cards */
    .metric-container {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 0.5rem;
        color: white;
        text-align: center;
    }
    
    /* Hide Streamlit default elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Professional typography */
    h1 {
        color: #1f77b4;
        font-weight: 600;
    }
    
    h2 {
        color: #2c3e50;
        font-weight: 500;
        margin-top: 1.5rem;
    }
    
    h3 {
        color: #34495e;
        font-weight: 500;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# Header Section
# ============================================================================

st.markdown("""
<div class="main-header">
    <h1>✈️ Airline Operations Intelligence Platform</h1>
    <p style="color: #7f8c8d; font-size: 1.1em;">Knowledge Graph-Powered Analytics & Insights</p>
</div>
""", unsafe_allow_html=True)

# ============================================================================
# Configuration Panel
# ============================================================================

with st.container():
    st.markdown("### Configuration")
    
    col1, col2, col3 = st.columns([2, 2, 2])
    
    with col1:
        retrieval_method = st.selectbox(
            "Retrieval Method",
            ["Baseline only", "Semantic only", "Both"],
            index=2,
            help="Select retrieval strategy: Baseline (Cypher queries), Semantic (vector similarity), or Both"
        )
        method_map = {
            "Baseline only": "baseline",
            "Semantic only": "semantic",
            "Both": "both"
        }
    
    with col2:
        use_llm = st.checkbox(
            "Enable AI Analysis",
            value=True,
            help="Generate intelligent insights using Large Language Models"
        )
    
    with col3:
        llm_model = None
        if use_llm:
            available_models = get_available_models()
            if available_models:
                # Prioritize OpenRouter and OpenAI (skip HuggingFace if others available)
                openrouter_models = [m for m in available_models if m.provider == "openrouter"]
                openai_models = [m for m in available_models if m.provider == "openai"]
                huggingface_models = [m for m in available_models if m.provider == "huggingface"]
                
                # Order: OpenRouter first, then OpenAI, then HuggingFace as last resort
                sorted_models = openrouter_models + openai_models + huggingface_models
                
                model_options = {model.display_name: model for model in sorted_models}
                model_names = list(model_options.keys())
                
                default_index = 0
                # Prefer OpenRouter free models first, then OpenAI
                if any("DeepSeek" in name or "Mistral Devstral" in name or "Amazon Nova" in name for name in model_names):
                    # Find first OpenRouter free model
                    for i, name in enumerate(model_names):
                        if "DeepSeek" in name or "Mistral Devstral" in name or "Amazon Nova" in name:
                            default_index = i
                            break
                elif "OpenAI GPT-4o Mini" in model_names:
                    default_index = model_names.index("OpenAI GPT-4o Mini")
                elif "OpenAI GPT-3.5 Turbo" in model_names:
                    default_index = model_names.index("OpenAI GPT-3.5 Turbo")
                
                selected_model_name = st.selectbox(
                    "AI Model",
                    options=model_names,
                    index=default_index,
                    help="Select AI model for analysis"
                )
                llm_model = model_options[selected_model_name]
            else:
                st.warning("No AI models available")
                use_llm = False

# ============================================================================
# Query Input Section
# ============================================================================

st.markdown("---")
st.markdown("### Query Interface")

# Example queries as buttons
st.markdown("**Quick Queries:**")
example_cols = st.columns(4)
with example_cols[0]:
    if st.button("📊 Flight Status", use_container_width=True):
        st.session_state.query = "What is the status of flight 2411?"
with example_cols[1]:
    if st.button("🗺️ Best Route", use_container_width=True):
        st.session_state.query = "What is the best route between Cairo and London?"
with example_cols[2]:
    if st.button("📈 Airline Info", use_container_width=True):
        st.session_state.query = "Tell me about EgyptAir"
with example_cols[3]:
    if st.button("😊 Satisfaction", use_container_width=True):
        st.session_state.query = "What are journeys with high food satisfaction?"

user_query = st.text_input(
    "Enter your query",
    value=st.session_state.get("query", ""),
    placeholder="e.g., What is the status of flight 2411?",
    label_visibility="collapsed"
)

query_button = st.button("🔍 Analyze", type="primary", use_container_width=True)

# ============================================================================
# Task Disambiguation (for ambiguous queries)
# ============================================================================

# Check if we need disambiguation
needs_disambiguation = False
if user_query.strip() and is_ambiguous_route_query(user_query):
    # Check if user already selected an intent
    if "disambiguated_intent" not in st.session_state or st.session_state.get("last_query") != user_query:
        needs_disambiguation = True
        st.session_state.last_query = user_query

if needs_disambiguation:
    st.info("💡 **It looks like you want to find a route. Please confirm the task:**")
    
    disamb_cols = st.columns(2)
    with disamb_cols[0]:
        if st.button("🔘 Best Route", use_container_width=True, type="primary"):
            st.session_state.disambiguated_intent = "BEST_ROUTE"
            st.session_state.query = user_query
            st.rerun()
    with disamb_cols[1]:
        if st.button("🔘 Flight Status", use_container_width=True):
            st.session_state.disambiguated_intent = "FLIGHT_STATUS"
            st.session_state.query = user_query
            st.rerun()
    
    st.markdown("---")

# ============================================================================
# Results Section
# ============================================================================

if (query_button or st.session_state.get("query")) and not needs_disambiguation:
    if not user_query.strip():
        st.warning("⚠️ Please enter a query to analyze.")
    else:
        # Clear disambiguation state if query changed
        if st.session_state.get("last_query") != user_query:
            st.session_state.pop("disambiguated_intent", None)
            st.session_state.pop("last_query", None)
        # Process query (technical details hidden)
        # Use disambiguated intent if user selected one
        force_intent = None
        if st.session_state.get("last_query") == user_query and st.session_state.get("disambiguated_intent"):
            force_intent = st.session_state.get("disambiguated_intent")
            # Clear disambiguation state after use (will be reset if query changes)
        
        with st.spinner("Processing query and retrieving data..."):
            result = process_query(
                user_query, 
                retrieval_method=method_map[retrieval_method],
                llm_model=llm_model,
                use_llm=use_llm,
                force_intent=force_intent
            )
            
            # Show a note if intent was disambiguated
            if force_intent:
                st.success(f"✓ Processing as **{force_intent.replace('_', ' ').title()}** task")
        
        # Store technical details in session state (hidden from UI)
        st.session_state.technical_details = {
            "intent": result.get('intent'),
            "intent_confidence": result.get('intent_confidence'),
            "entities": result.get("entities"),
            "template": result.get("template"),
            "params": result.get("params"),
            "baseline_rows": result.get("baseline_rows"),
            "semantic_rows": result.get("semantic_rows")
        }
        
        # Show helpful message for FLIGHT_STATUS with semantic-only
        if result.get('intent') == "FLIGHT_STATUS" and retrieval_method == "Semantic only":
            st.warning("""
            ⚠️ **Semantic-only retrieval is not suitable for exact flight number queries.**
            
            **Reason:** Flight nodes don't have embeddings (only Journey nodes do). 
            Semantic search works best for fuzzy questions about journeys, delays, and satisfaction.
            
            **Recommendation:** Use **"Baseline only"** or **"Both"** for flight status queries.
            """)
        
        # ========================================================================
        # Metrics Dashboard
        # ========================================================================
        
        st.markdown("---")
        st.markdown("### Analysis Results")
        
        # Metrics row
        metric_cols = st.columns(4)
        
        with metric_cols[0]:
            st.metric(
                "Retrieved Records",
                result.get('num_rows', 0),
                help="Total records retrieved from knowledge graph"
            )
        
        with metric_cols[1]:
            baseline_count = result.get('num_baseline_rows', 0)
            st.metric(
                "Structured Queries",
                baseline_count,
                help="Results from structured Cypher queries"
            )
        
        with metric_cols[2]:
            semantic_count = result.get('num_semantic_rows', 0)
            st.metric(
                "Semantic Matches",
                semantic_count,
                help="Results from semantic similarity search"
            )
        
        with metric_cols[3]:
            if use_llm and result.get("llm_response"):
                llm_resp = result.get("llm_response")
                if "error" not in llm_resp:
                    st.metric(
                        "AI Analysis",
                        "✓ Complete",
                        help="AI analysis completed successfully"
                    )
                else:
                    st.metric(
                        "AI Analysis",
                        "✗ Error",
                        help="AI analysis encountered an error"
                    )
            else:
                st.metric(
                    "AI Analysis",
                    "—",
                    help="AI analysis not enabled"
                )
        
        # ========================================================================
        # AI-Generated Insights (Main Content)
        # ========================================================================
        
        if use_llm and result.get("llm_response"):
            llm_resp = result.get("llm_response")
            
            if "error" in llm_resp:
                st.error("**AI Analysis Error**")
                error_msg = llm_resp.get('text', 'Unknown error')
                st.error(error_msg)
                
                # Compact error handling
                if "quota" in error_msg.lower() or "429" in error_msg:
                    with st.expander("💡 Solution: API Quota Exceeded"):
                        st.markdown("""
                        - Wait 5-10 minutes for rate limits to reset
                        - Or use OpenRouter free models (already configured)
                        - Check usage at https://platform.openai.com/usage
                        """)
            else:
                # Success - Display AI insights prominently
                st.markdown("---")
                st.markdown("### 🤖 AI-Generated Insights")
                
                model_name = result.get("llm_model", "Unknown Model")
                st.caption(f"**Model:** {model_name}")
                
                answer_text = llm_resp.get("text", "")
                if answer_text and answer_text.strip():
                    # Professional display using Streamlit's native markdown
                    # This is more reliable than HTML rendering
                    st.markdown("---")
                    st.markdown("**Answer:**")
                    # Use st.markdown for proper text rendering
                    st.markdown(answer_text)
                else:
                    st.warning("⚠️ AI response is empty")
                    # Debug: show what we got
                    with st.expander("🔍 Debug: Show raw response"):
                        st.json(llm_resp)
                        st.write("Response keys:", list(llm_resp.keys()))
                        st.write("Text value:", repr(answer_text))
                        st.write("Text length:", len(answer_text) if answer_text else 0)
                
                    # Performance metrics (compact, at bottom)
                    st.markdown("---")
                    if "usage" in llm_resp and llm_resp["usage"]:
                        usage = llm_resp["usage"]
                        perf_cols = st.columns(4)
                        with perf_cols[0]:
                            st.metric("Prompt Tokens", usage.get('prompt_tokens', 'N/A'))
                        with perf_cols[1]:
                            st.metric("Completion Tokens", usage.get('completion_tokens', 'N/A'))
                        with perf_cols[2]:
                            st.metric("Total Tokens", usage.get('total_tokens', 'N/A'))
                        with perf_cols[3]:
                            if "response_time" in llm_resp:
                                st.metric("Response Time", f"{llm_resp['response_time']:.2f}s")
        
        # ========================================================================
        # Data Preview (Collapsible)
        # ========================================================================
        
        if result.get('num_rows', 0) > 0:
            with st.expander("📊 View Retrieved Data", expanded=False):
                # ====================================================================
                # Knowledge Graph Context (Nodes & Relationships)
                # ====================================================================
                if result.get("executed_cypher") or result.get("baseline_rows"):
                    st.markdown("**🔍 Knowledge Graph Context**")
                    kg_info_cols = st.columns(2)
                    
                    with kg_info_cols[0]:
                        st.markdown("**Nodes Retrieved:**")
                        nodes_found = []
                        relationships_found = []
                        
                        # Extract from Cypher query if available
                        if result.get("executed_cypher"):
                            kg_structure = extract_kg_structure(result.get("executed_cypher"), result.get("params", {}))
                            nodes_found = kg_structure["nodes"]
                            relationships_found = kg_structure["relationships"]
                        
                        # Also infer from data if available
                        if result.get("baseline_rows"):
                            for row in result.get("baseline_rows", [])[:1]:  # Check first row
                                if "flight_number" in row and "Flight" not in nodes_found:
                                    nodes_found.append("Flight")
                                if "airport_code" in row or "origin_code" in row or "dest_code" in row:
                                    if "Airport" not in nodes_found:
                                        nodes_found.append("Airport")
                                if "journey_id" in row or "journey_count" in row:
                                    if "Journey" not in nodes_found:
                                        nodes_found.append("Journey")
                        
                        # Count instances
                        if result.get("baseline_rows"):
                            baseline_count = len(result.get("baseline_rows", []))
                            if "Flight" in nodes_found:
                                unique_flights = len(set(r.get("flight_number") for r in result.get("baseline_rows", []) if r.get("flight_number")))
                                st.markdown(f"  • **Flight**: {unique_flights} node(s)")
                            if "Airport" in nodes_found:
                                airports = set()
                                for r in result.get("baseline_rows", []):
                                    if r.get("airport_code"):
                                        airports.add(r.get("airport_code"))
                                    if r.get("origin_code"):
                                        airports.add(r.get("origin_code"))
                                    if r.get("dest_code"):
                                        airports.add(r.get("dest_code"))
                                if airports:
                                    st.markdown(f"  • **Airport**: {len(airports)} node(s) ({', '.join(sorted(airports)[:5])}{'...' if len(airports) > 5 else ''})")
                            if "Journey" in nodes_found:
                                journey_count = result.get("baseline_rows", [{}])[0].get("journey_count", baseline_count)
                                st.markdown(f"  • **Journey**: {journey_count} node(s)")
                        else:
                            # Fallback: just list node types
                            for node_type in sorted(set(nodes_found)):
                                st.markdown(f"  • **{node_type}**")
                        
                        if not nodes_found:
                            st.info("No nodes identified")
                    
                    with kg_info_cols[1]:
                        st.markdown("**Relationships Retrieved:**")
                        if relationships_found:
                            for rel in relationships_found:
                                # Format relationship nicely
                                rel_display = rel.replace("_", " ").title()
                                st.markdown(f"  • **{rel}**")
                        else:
                            # Infer from common patterns
                            if result.get("baseline_rows"):
                                inferred_rels = []
                                for row in result.get("baseline_rows", [])[:1]:
                                    if "flight_number" in row and ("journey_count" in row or "avg_delay_minutes" in row):
                                        inferred_rels.append("ON")
                                    if "origin_code" in row and "dest_code" in row:
                                        inferred_rels.append("DEPARTS_FROM")
                                        inferred_rels.append("ARRIVES_AT")
                                    if "airport_code" in row and ("departing_flights" in row or "arriving_flights" in row):
                                        inferred_rels.append("DEPARTS_FROM")
                                        inferred_rels.append("ARRIVES_AT")
                                
                                for rel in sorted(set(inferred_rels)):
                                    st.markdown(f"  • **{rel}**")
                            else:
                                st.info("No relationships identified")
                    
                    st.markdown("---")
                
                # ====================================================================
                # Data Tables
                # ====================================================================
                if retrieval_method == "Both":
                    tab1, tab2 = st.tabs(["Structured Query Results", "Semantic Search Results"])
                    with tab1:
                        if result.get("baseline_rows"):
                            st.dataframe(result["baseline_rows"], use_container_width=True)
                        else:
                            st.info("No structured query results")
                    with tab2:
                        if result.get("semantic_rows"):
                            # Remove embeddings for display
                            semantic_display = []
                            for row in result.get("semantic_rows", []):
                                clean_row = {k: v for k, v in row.items() if k != "embedding"}
                                semantic_display.append(clean_row)
                            st.dataframe(semantic_display, use_container_width=True)
                        else:
                            st.info("No semantic search results")
                else:
                    if result.get("rows"):
                        st.dataframe(result["rows"], use_container_width=True)
        
        # ========================================================================
        # Cypher Query Display
        # ========================================================================
        
        if result.get("executed_cypher"):
            with st.expander("📝 Cypher Query Executed", expanded=False):
                st.markdown("**Executed Query:**")
                st.code(result.get("executed_cypher"), language="cypher")
                if result.get("params"):
                    st.markdown("**Parameters:**")
                    st.json(result.get("params", {}))
        
        # ========================================================================
        # Graph Visualization
        # ========================================================================
        
        if result.get('num_rows', 0) > 0 and result.get("baseline_rows"):
            try:
                import networkx as nx
                import plotly.graph_objects as go
                
                # Build graph from retrieved data
                G = nx.Graph()
                node_labels = {}
                node_types = {}
                
                # Extract nodes and relationships from baseline rows
                for row in result.get("baseline_rows", [])[:20]:  # Limit to 20 for performance
                    # Add nodes based on available fields
                    if "flight_number" in row:
                        flight_id = f"Flight_{row['flight_number']}"
                        G.add_node(flight_id, type="Flight")
                        node_labels[flight_id] = f"Flight {row['flight_number']}"
                        node_types[flight_id] = "Flight"
                    
                    if "airport_code" in row or "origin_code" in row or "dest_code" in row:
                        for code_field in ["airport_code", "origin_code", "dest_code"]:
                            if code_field in row and row[code_field]:
                                airport_id = f"Airport_{row[code_field]}"
                                G.add_node(airport_id, type="Airport")
                                node_labels[airport_id] = row[code_field]
                                node_types[airport_id] = "Airport"
                        
                        # Add relationships
                        if "origin_code" in row and "dest_code" in row:
                            origin_id = f"Airport_{row['origin_code']}"
                            dest_id = f"Airport_{row['dest_code']}"
                            if origin_id in G and dest_id in G:
                                G.add_edge(origin_id, dest_id, type="ROUTE")
                    
                    if "journey_id" in row:
                        journey_id = f"Journey_{row['journey_id']}"
                        G.add_node(journey_id, type="Journey")
                        node_labels[journey_id] = row['journey_id'][:10] + "..."
                        node_types[journey_id] = "Journey"
                
                if len(G.nodes()) > 0:
                    with st.expander("🕸️ Graph Visualization", expanded=False):
                        # Use spring layout for positioning
                        pos = nx.spring_layout(G, k=1, iterations=50)
                        
                        # Create edge traces
                        edge_x = []
                        edge_y = []
                        for edge in G.edges():
                            x0, y0 = pos[edge[0]]
                            x1, y1 = pos[edge[1]]
                            edge_x.extend([x0, x1, None])
                            edge_y.extend([y0, y1, None])
                        
                        edge_trace = go.Scatter(
                            x=edge_x, y=edge_y,
                            line=dict(width=2, color='#888'),
                            hoverinfo='none',
                            mode='lines'
                        )
                        
                        # Create node traces by type
                        node_traces = []
                        color_map = {
                            "Flight": "#FF6B6B",
                            "Airport": "#4ECDC4",
                            "Journey": "#95E1D3"
                        }
                        
                        for node_type in ["Flight", "Airport", "Journey"]:
                            node_x = []
                            node_y = []
                            node_text = []
                            node_colors = []
                            
                            for node in G.nodes():
                                if node_types.get(node) == node_type:
                                    x, y = pos[node]
                                    node_x.append(x)
                                    node_y.append(y)
                                    node_text.append(node_labels.get(node, node))
                                    node_colors.append(color_map.get(node_type, "#888"))
                            
                            if node_x:
                                node_trace = go.Scatter(
                                    x=node_x, y=node_y,
                                    mode='markers+text',
                                    name=node_type,
                                    marker=dict(
                                        size=20,
                                        color=node_colors,
                                        line=dict(width=2, color='white')
                                    ),
                                    text=node_text,
                                    textposition="middle center",
                                    textfont=dict(size=10, color='white'),
                                    hoverinfo='text'
                                )
                                node_traces.append(node_trace)
                        
                        # Create figure
                        fig = go.Figure(
                            data=[edge_trace] + node_traces,
                            layout=go.Layout(
                                title='Retrieved Knowledge Graph Subgraph',
                                titlefont_size=16,
                                showlegend=True,
                                hovermode='closest',
                                margin=dict(b=20, l=5, r=5, t=40),
                                annotations=[
                                    dict(
                                        text="Nodes represent entities (Flights, Airports, Journeys) retrieved from the knowledge graph",
                                        showarrow=False,
                                        xref="paper", yref="paper",
                                        x=0.005, y=-0.002,
                                        xanchor="left", yanchor="bottom",
                                        font=dict(color="#888", size=10)
                                    )
                                ],
                                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                                plot_bgcolor='white'
                            )
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
            except ImportError:
                # NetworkX or Plotly not installed - skip visualization
                pass
            except Exception as e:
                # Graph visualization failed - skip silently
                if st.session_state.get("debug", False):
                    st.warning(f"Graph visualization failed: {e}")
        
        # ========================================================================
        # Technical Details (Hidden by default - only for debugging)
        # ========================================================================
        
        with st.expander("🔧 Technical Details (Debug)", expanded=False):
            tech_cols = st.columns(2)
            
            with tech_cols[0]:
                st.markdown("**Intent Classification**")
                st.json({
                    "intent": result.get('intent'),
                    "confidence": f"{result.get('intent_confidence', 0):.2f}",
                    "entities": result.get("entities", [])
                })
            
            with tech_cols[1]:
                st.markdown("**Query Template**")
                if result.get("template"):
                    st.json(result["template"])
                    st.markdown("**Parameters:**")
                    st.json(result.get("params", {}))
                else:
                    st.info("No template matched")
        
        # ========================================================================
        # No Results Handling
        # ========================================================================
        
        if result.get('num_rows', 0) == 0:
            st.info("""
            ℹ️ **No data found** for this query. 
            
            This could mean:
            - The query doesn't match any data in the knowledge graph
            - The flight number or entity doesn't exist in the dataset
            - Try rephrasing your query or checking the data availability
            """)

# ============================================================================
# Footer / Help Section
# ============================================================================

st.markdown("---")
with st.expander("ℹ️ About This Platform", expanded=False):
    st.markdown("""
    **Airline Operations Intelligence Platform**
    
    This platform provides intelligent analysis of airline operations data using:
    - **Knowledge Graph (Neo4j)**: Structured data storage and retrieval
    - **Baseline Retrieval**: Structured Cypher queries for exact matches
    - **Semantic Retrieval**: Vector similarity search for contextual matches
    - **AI Analysis**: Large Language Models for generating insights
    
    **Data Sources:**
    - Flight information (flight numbers, aircraft types)
    - Journey data (delays, satisfaction scores, passenger feedback)
    - Performance metrics and operational insights
    """)

# ============================================================================
# Neo4j Connection Test (Hidden)
# ============================================================================

if st.sidebar.button("🔌 Test Database Connection"):
    with st.sidebar:
        client = Neo4jClient()
        try:
            rows = client.run_query("MATCH (n) RETURN labels(n) as labels, count(*) as count")
            st.success("✓ Database Connected")
            st.json(rows)
        except Exception as e:
            st.error(f"✗ Connection Error: {e}")
        finally:
            client.close()
