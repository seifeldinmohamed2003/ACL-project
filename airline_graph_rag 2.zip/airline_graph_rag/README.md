# Airline GraphRAG System

A Knowledge Graph-powered RAG (Retrieval-Augmented Generation) system for airline operations analysis, built with Neo4j and Large Language Models.

## Overview

This system provides intelligent analysis of airline operations data using:
- **Knowledge Graph (Neo4j)**: Structured data storage and retrieval
- **Baseline Retrieval**: 16 structured Cypher query templates
- **Semantic Retrieval**: Vector similarity search using embeddings
- **AI Analysis**: Multiple LLM providers (OpenAI, OpenRouter) for generating insights

## Features

- **16 Query Templates**: Covering flight search, route analysis, delay queries, and passenger satisfaction
- **Dual Retrieval**: Baseline (Cypher) + Semantic (vector similarity)
- **Multiple LLM Support**: OpenAI GPT-4o Mini, DeepSeek, Mistral, and more
- **Airline Company Perspective**: Operational insights focused on delays, satisfaction, and performance
- **Professional UI**: Clean Streamlit interface for querying and analysis

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment

Create a `.env` file with:

```env
# Neo4j
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your_password

# LLM APIs (at least one required)
OPENAI_API_KEY=sk-...
OPENROUTER_API_KEY=sk-or-...
```

### 3. Generate Embeddings

```bash
python -m backend.retrieval.embedding_retrieval
```

### 4. Run the Application

```bash
streamlit run ui/app.py
# or
python run_streamlit.py
```

## Project Structure

```
airline_graph_rag/
├── backend/
│   ├── pipeline.py              # Main processing pipeline
│   ├── neo4j_client.py           # Neo4j connection
│   ├── preprocessing/
│   │   ├── intent_classifier.py  # Intent classification
│   │   ├── entity_extractor.py   # Entity extraction
│   │   └── embeddings.py         # Embedding service
│   ├── retrieval/
│   │   ├── baseline_queries.py   # 16 Cypher query templates
│   │   └── embedding_retrieval.py # Semantic retrieval
│   └── llm/
│       ├── model_client.py       # LLM client (OpenAI, OpenRouter)
│       └── prompt_builder.py     # Prompt construction
├── ui/
│   └── app.py                    # Streamlit UI
├── tests/
│   └── test_semantic_retrieval.py
├── requirements.txt
└── README.md
```

## Query Templates

The system includes **16 query templates** covering:

- **Flight Search** (4 templates): By number, route, city
- **Route Analysis** (3 templates): Best routes, popular routes
- **Delay Queries** (3 templates): High delays, route delays, delay causes
- **Passenger Satisfaction** (3 templates): Satisfaction metrics, poorly rated flights
- **Other** (3 templates): Airline info, airport info

## Documentation

- `SYSTEM_ARCHITECTURE.md`: System design and architecture
- `FINAL_REQUIREMENTS_CHECKLIST.md`: Milestone 3 requirements status
- `llm_comparison_results.json`: LLM model comparison results

## Requirements

- Python 3.8+
- Neo4j 5.x+
- API keys for at least one LLM provider (OpenAI or OpenRouter)

## License

Academic project for Milestone 3.
