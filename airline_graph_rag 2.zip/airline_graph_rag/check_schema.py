#!/usr/bin/env python3
"""
Quick schema check script to verify Neo4j properties and relationships.
Run: python check_schema.py
"""

import sys
sys.path.insert(0, '.')

from backend.neo4j_client import Neo4jClient

client = Neo4jClient()

print("="*80)
print("SCHEMA CHECK")
print("="*80)

# Check Journey properties
print("\n1. Journey node properties:")
try:
    result = client.run_query("MATCH (j:Journey) RETURN keys(j) AS props LIMIT 1")
    if result:
        print(f"   Properties: {result[0].get('props', [])}")
    else:
        print("   No Journey nodes found")
except Exception as e:
    print(f"   Error: {e}")

# Check if number_of_legs exists
print("\n2. Journey nodes with number_of_legs:")
try:
    result = client.run_query("""
        MATCH (j:Journey)
        RETURN count(j) AS total, count(j.number_of_legs) AS with_legs
    """)
    if result:
        print(f"   Total journeys: {result[0].get('total', 0)}")
        print(f"   With number_of_legs: {result[0].get('with_legs', 0)}")
except Exception as e:
    print(f"   Error: {e}")

# Check Flight relationships
print("\n3. Flight -> Airport relationships:")
try:
    result = client.run_query("""
        MATCH (:Flight)-[r:DEPARTS_FROM]->(:Airport) 
        RETURN count(r) AS f_to_a
    """)
    if result:
        print(f"   Flight -> Airport (DEPARTS_FROM): {result[0].get('f_to_a', 0)}")
except Exception as e:
    print(f"   Error: {e}")

try:
    result = client.run_query("""
        MATCH (:Airport)-[r:DEPARTS_FROM]->(:Flight) 
        RETURN count(r) AS a_to_f
    """)
    if result and result[0].get('a_to_f', 0) > 0:
        print(f"   Airport -> Flight (DEPARTS_FROM): {result[0].get('a_to_f', 0)}")
except Exception as e:
    pass

# Check percentileCont support
print("\n4. Testing percentileCont function:")
try:
    result = client.run_query("""
        MATCH (j:Journey)
        WHERE j.arrival_delay_minutes IS NOT NULL
        RETURN percentileCont(j.arrival_delay_minutes, 0.9) AS p90
        LIMIT 1
    """)
    if result:
        print(f"   ✅ percentileCont works: {result[0].get('p90', 'N/A')}")
    else:
        print("   ⚠️  percentileCont returned no results")
except Exception as e:
    print(f"   ❌ percentileCont error: {e}")

# Check Airport codes
print("\n5. Sample airport codes:")
try:
    result = client.run_query("""
        MATCH (a:Airport)
        RETURN a.station_code AS code
        LIMIT 10
    """)
    if result:
        codes = [row.get('code') for row in result]
        print(f"   Sample codes: {codes}")
except Exception as e:
    print(f"   Error: {e}")

print("\n" + "="*80)
print("DONE")
print("="*80)
